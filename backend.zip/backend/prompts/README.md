# Agent Prompts for Policy 360

This folder contains detailed markdown prompts for the AI agents needed to build a Policy 360-style research system.

## Suggested agent stack

1. Orchestrator Agent
2. Policy Intake Agent
3. Retrieval / Research Agent
4. Document Parser / Extractor Agent
5. Causal Chain Agent
6. Impact Analysis Agent
7. Comparator / Benchmarking Agent
8. Forecast / Scenario Agent
9. Traceability Agent
10. Report Writer Agent
11. QA / Reviewer Agent

## Usage

Each numbered file is a conceptual role spec — written as a ready-to-use prompt template you can paste into an LLM-powered workflow, agent framework, or orchestration layer.

## runtime/

The actual prompt text the running pipeline sends to the model (`app/agents.py`) lives in `runtime/` as plain `.txt` templates, one per implemented stage, plus `system_prefix.txt` for the shared system prompt and `chat.txt` for the per-job chat agent. No prompt text lives in the `.py` files.

The nine implemented stages and their dependencies:

| Stage | Prompt | Reads | Notes |
|---|---|---|---|
| Intake | `intake.txt` | `$policy` | |
| Research | `research.txt` | `$intake` | **has tools** — public-web search + fetch |
| Causality | `causality.txt` | `$intake` `$research` | |
| Impact | `impact.txt` | `$intake` `$research` | |
| Comparators | `comparators.txt` | `$intake` `$research` | global benchmarking + related policies |
| Forecast | `forecast.txt` | `$intake` `$research` `$causality` `$impact` `$comparators` | |
| Stakeholders | `stakeholders.txt` | `$intake` `$research` `$causality` `$impact` `$forecast` | |
| Alternatives | `alternatives.txt` | `$intake` `$research` `$causality` `$impact` `$comparators` `$forecast` | |
| Red-team | `redteam.txt` | `$intake` `$research` `$causality` `$impact` `$forecast` `$stakeholders` `$alternatives` | attacks the seams the other stages exposed |

`$name` placeholders are `string.Template` substitutions filled at request time from the named upstream stage's output. The **Reads** column is not documentation to keep in sync by hand: it is `Stage.needs` in `app/agents.py`, and `_validate_stages()` fails at import if a prompt reads a placeholder its stage doesn't declare, declares one it doesn't read, or depends on a stage that runs later.

## Single owner per finding

Each of these is produced by exactly one stage. They were previously generated
in two or more places, which cost tokens and let the copies contradict each
other — if you add an ask to a prompt, check it isn't already owned here.

| Finding | Owner | Everyone else |
|---|---|---|
| Prior / predecessor policies | Causality (`prior_attempts`) | Comparators is told not to list them; the report maps them into `relatedPolicies.predecessor` |
| Evidence gaps & conflicts | Research (`evidence_gaps`, `conflicting_evidence`) | Impact references them to justify a weaker score instead of re-listing (its `data_gaps` field is gone — nothing rendered it) |
| Impact rating per dimension | Impact (`impact_bars`, 0-100) | The traffic-light colour is **derived** from the score in `_assemble_report()`, not generated |
| Stakeholder positions | Stakeholders | Red-team uses a named opposed stakeholder as an objection's angle rather than inventing a critic |
| Critique of the status quo | Red-team (`objections`) | Alternatives keeps "retain current policy" as a baseline but leaves the case against it to Red-team |

The shared instructions — no length or item caps, name uncertainty explicitly,
build on upstream output rather than re-deriving it, answer with one JSON
object — live in `system_prefix.txt` and are prepended to every call. Don't
repeat them in individual prompts; that cost was being paid nine times a run.

Relative to the 11-agent stack above: Comparator is stage 5 here; Orchestrator is the loop in `run_pipeline()`; Report Writer is replaced by deterministic assembly in `_assemble_report()`; Document Parser, Traceability and QA/Reviewer are not implemented. Stakeholders, Alternatives and Red-team are runtime additions with no doc above.
