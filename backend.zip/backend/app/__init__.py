"""Policy 360 backend package.

Silences two known-harmless warnings emitted by our LangChain/LangGraph
stack on import — a pydantic v1-compat notice (irrelevant, we don't use
pydantic v1) and a LangGraph checkpoint default-value deprecation notice
(irrelevant, we don't configure that param).

Ordering matters here, in two opposite directions:

- The pydantic warning fires *during* `langchain_core._api.deprecation`'s own
  top-level import (it imports `pydantic.v1` itself) — our ignore rule for it
  must be registered *before* that import happens, or it's too late.
- `langchain_core._api.deprecation` also registers its own
  `warnings.filterwarnings("default", category=LangChainPendingDeprecationWarning)`
  as a side effect of being imported, and `filterwarnings` prepends by
  default — so whichever filter is added *last* wins. Our ignore rule for
  that category must be registered *after* importing it, so ours ends up on
  top by the time the rest of the app imports langgraph and the warning
  would otherwise fire.
"""
import warnings

warnings.filterwarnings(
    "ignore",
    message=r"Core Pydantic V1 functionality isn't compatible with Python 3\.14 or greater",
)

import langchain_core._api.deprecation as _lc_deprecation  # noqa: E402, F401

warnings.filterwarnings(
    "ignore",
    category=_lc_deprecation.LangChainPendingDeprecationWarning,
)
