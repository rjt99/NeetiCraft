"""Per-job chat agent — "talk to this run's folder".

A `deepagents.create_deep_agent` whose filesystem backend is rooted at a
single job directory (jobs/<job_id>/), so its `ls` / `read_file` / `glob` /
`grep` tools see that run's state, log, per-stage outputs and report — and
nothing else on the host.

Retrieval here is plain filesystem browsing: the agent decides which files
to open. No embeddings, no vector store, no RAG — that comes later.
"""
from string import Template
from typing import Any

from deepagents import FilesystemPermission, create_deep_agent
from deepagents.backends import FilesystemBackend

from .agents import build_model
from .config import read_prompt
from .job_store import job_dir

# Two independent guards, because one is not enough:
#   - virtual_mode=True anchors every path at the job folder and blocks
#     traversal ("..", "~", absolute host paths), so one job's chat can
#     never read another job's folder — let alone the rest of the disk.
#   - these permissions make the mount read-only, so a prompt-injected
#     instruction sitting in a stage output can't get the agent to rewrite
#     or delete the artifacts it is describing.
_PERMISSIONS = [
    FilesystemPermission(operations=["read"], paths=["/**"], mode="allow"),
    FilesystemPermission(operations=["write"], paths=["/**"], mode="deny"),
]


def _system_prompt(job_id: str) -> str:
    return Template(read_prompt("chat.txt")).safe_substitute(job_id=job_id)


def build_job_chat_agent(job_id: str):
    """Build a chat agent scoped to jobs/<job_id>/.

    Deliberately not cached: the folder's contents change while a run is in
    flight, and an agent is cheap to construct next to the model call it
    wraps.
    """
    backend = FilesystemBackend(root_dir=job_dir(job_id), virtual_mode=True)
    return create_deep_agent(
        model=build_model(),
        backend=backend,
        permissions=_PERMISSIONS,
        system_prompt=_system_prompt(job_id),
    )


async def answer(job_id: str, message: str, history: list[dict[str, str]]) -> str:
    """Run one chat turn against the job folder and return the reply text."""
    agent = build_job_chat_agent(job_id)
    messages: list[dict[str, Any]] = [
        {"role": turn["role"], "content": turn["content"]} for turn in history
    ]
    messages.append({"role": "user", "content": message})

    result = await agent.ainvoke({"messages": messages})
    replies = result.get("messages", []) if isinstance(result, dict) else []
    if not replies:
        return ""
    content = getattr(replies[-1], "content", "")
    # Content can arrive as a list of content blocks on some providers.
    if isinstance(content, list):
        return "".join(
            block.get("text", "") if isinstance(block, dict) else str(block)
            for block in content
        )
    return str(content)
