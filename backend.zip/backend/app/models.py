"""ORM models: users, login history, user-categorised workflows, and jobs."""
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(256), nullable=False)
    role: Mapped[str] = mapped_column(String(32), default="analyst")  # admin / analyst
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    logins: Mapped[list["LoginEvent"]] = relationship(back_populates="user", cascade="all, delete-orphan")
    workflows: Mapped[list["Workflow"]] = relationship(back_populates="user", cascade="all, delete-orphan")


class LoginEvent(Base):
    """One row per successful login — keeps full login-time history."""

    __tablename__ = "login_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True, nullable=False)
    logged_in_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    client: Mapped[str | None] = mapped_column(String(256), nullable=True)  # user-agent / ip note

    user: Mapped["User"] = relationship(back_populates="logins")


class Workflow(Base):
    """User-categorised workflows (analysis runs, saved pipelines) — populated later."""

    __tablename__ = "workflows"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    category: Mapped[str] = mapped_column(String(64), index=True, nullable=False)  # e.g. Energy, Agriculture
    status: Mapped[str] = mapped_column(String(32), default="draft")  # draft / running / completed
    payload: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON blob for workflow config/results
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    user: Mapped["User"] = relationship(back_populates="workflows")


class Job(Base):
    """A single pipeline run. Only lightweight, queryable fields live here —
    everything else (per-stage outputs, logs, state snapshots, the final
    report, any retrieved raw documents) lives on disk under jobs/<job_id>/,
    see app/job_store.py."""

    __tablename__ = "jobs"

    job_id: Mapped[str] = mapped_column(String(64), primary_key=True)  # "Job-<HH-MM> <DD-MM-YYYY>"
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, nullable=True)
    policy_query: Mapped[str] = mapped_column(String(256), nullable=False)  # raw user input
    policy_name: Mapped[str | None] = mapped_column(String(256), nullable=True)  # resolved after intake
    category: Mapped[str | None] = mapped_column(String(64), nullable=True)
    status: Mapped[str] = mapped_column(String(32), default="queued")  # queued/running/completed/failed
    current_stage: Mapped[str | None] = mapped_column(String(64), nullable=True)
    folder_path: Mapped[str] = mapped_column(String(512), nullable=False)  # relative to backend/
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    user: Mapped[Optional["User"]] = relationship()
