"""File-system storage for job artifacts.

Split of responsibility:
  - SQLite (models.Job) holds the small, queryable facts about a job —
    id, status, current stage, timestamps, error message.
  - Disk, under jobs/<job_id>/, holds everything else: the running state
    snapshot, per-stage agent outputs, logs, any raw retrieved documents,
    and the final assembled report.

Job id format: "Job-<HH-MM> <DD-MM-YYYY>" in local server time, e.g.
"Job-14-32 03-08-2026". Colon is swapped for a dash because job ids double
as folder names and Windows filesystems reject ':' in paths. If two jobs
are created in the same minute, a "-2", "-3", ... suffix is appended.
"""
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import BACKEND_ROOT, JOB_LOG_FILE, JOB_STATE_FILE, JOB_SUBDIRS, JOBS_ROOT
from .database import SessionLocal
from .models import Job

JOBS_ROOT.mkdir(parents=True, exist_ok=True)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def job_dir(job_id: str) -> Path:
    return JOBS_ROOT / job_id


def _write_json(path: Path, data: Any) -> None:
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _read_json(path: Path) -> Any | None:
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


# ---------- creation ----------

def _generate_job_id(now: datetime) -> str:
    return f"Job-{now:%H-%M %d-%m-%Y}"


def create_job(policy_query: str, user_id: int | None = None) -> Job:
    """Create the DB row and the on-disk folder skeleton for a new job."""
    now = datetime.now()
    base_id = _generate_job_id(now)
    job_id = base_id
    suffix = 1
    while job_dir(job_id).exists():
        suffix += 1
        job_id = f"{base_id}-{suffix}"

    d = job_dir(job_id)
    for sub in JOB_SUBDIRS:
        (d / sub).mkdir(parents=True, exist_ok=True)
    _write_json(d / JOB_STATE_FILE, {
        "job_id": job_id,
        "policy_query": policy_query,
        "status": "queued",
        "current_stage": None,
        "stages_completed": [],
        "created_at": _now_iso(),
        "updated_at": _now_iso(),
    })

    with SessionLocal() as db:
        job = Job(
            job_id=job_id,
            user_id=user_id,
            policy_query=policy_query,
            status="queued",
            folder_path=str(d.relative_to(BACKEND_ROOT)).replace("\\", "/"),
        )
        db.add(job)
        db.commit()
        db.refresh(job)
        db.expunge(job)
    return job


# ---------- DB-side updates (small, queryable fields) ----------

def update_job(job_id: str, **fields: Any) -> None:
    """Set only the given fields on the job row, e.g.
    update_job(job_id, status="failed", error_message="...")."""
    if not fields:
        return
    with SessionLocal() as db:
        job = db.get(Job, job_id)
        if job is None:
            return
        for key, value in fields.items():
            setattr(job, key, value)
        db.commit()


# ---------- disk-side state / outputs / logs / report ----------

def write_state(job_id: str, updates: dict) -> None:
    path = job_dir(job_id) / JOB_STATE_FILE
    state = _read_json(path) or {}
    state.update(updates)
    state["updated_at"] = _now_iso()
    _write_json(path, state)


def read_state(job_id: str) -> dict | None:
    return _read_json(job_dir(job_id) / JOB_STATE_FILE)


def save_stage_output(job_id: str, stage: str, data: dict) -> None:
    _write_json(job_dir(job_id) / "outputs" / f"{stage.lower()}.json", data)
    state = read_state(job_id) or {}
    completed = state.get("stages_completed", [])
    if stage not in completed:
        completed.append(stage)
    write_state(job_id, {"stages_completed": completed})


def read_stage_output(job_id: str, stage: str) -> dict | None:
    return _read_json(job_dir(job_id) / "outputs" / f"{stage.lower()}.json")


def append_log(job_id: str, stage: str, message: str) -> None:
    """Append one line to the job's single log file, tagged with its stage."""
    path = job_dir(job_id) / JOB_LOG_FILE
    with path.open("a", encoding="utf-8") as f:
        f.write(f"[{_now_iso()}] [{stage}] {message}\n")


def read_log(job_id: str) -> str:
    path = job_dir(job_id) / JOB_LOG_FILE
    return path.read_text(encoding="utf-8") if path.exists() else ""


def save_raw(job_id: str, filename: str, content: bytes | str) -> None:
    """Persist a raw retrieved document (source text, API response, etc.)."""
    path = job_dir(job_id) / "raw" / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(content, bytes):
        path.write_bytes(content)
    else:
        path.write_text(content, encoding="utf-8")


def save_report(job_id: str, report: dict) -> None:
    _write_json(job_dir(job_id) / "report" / "report.json", report)


def read_report(job_id: str) -> dict | None:
    return _read_json(job_dir(job_id) / "report" / "report.json")


def list_files(job_id: str) -> list[str]:
    d = job_dir(job_id)
    if not d.exists():
        return []
    return sorted(
        str(p.relative_to(d)).replace("\\", "/")
        for p in d.rglob("*")
        if p.is_file()
    )
