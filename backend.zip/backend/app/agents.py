"""LangChain-backed agent pipeline for Policy 360.

Nine agents run in dependency order, each a `langchain.agents.create_agent`
chat agent pointed at OpenRouter's OpenAI-compatible API and streamed
token-by-token via `agent.astream(..., stream_mode="messages")`.

Every stage declares the upstream outputs it consumes (`Stage.needs`), and
that declaration is the single source of truth: it drives which context is
substituted into the prompt, and it is validated at import time so a stage
can never be ordered before something it depends on. The resulting DAG is

    Intake -> Research -> { Causality, Impact, Comparators }
                       -> Forecast -> { Stakeholders, Alternatives, Red-team }

Braced groups are mutually independent and could run concurrently; they are
executed serially here because the free-tier OpenRouter models the project
defaults to rate-limit hard on parallel requests.

Only the Research stage carries tools (public-web search and page fetch, see
app/websearch.py) — it is the retrieval stage, and every later stage reasons
over the evidence it returns rather than searching again.

Streamed tokens are buffered into display "lines" (on a newline, or after
STREAM_LINE_FLUSH_CHARS characters) and pushed to the UI as SSE `stream`
events, each pre-formatted as "[HH:MM] - <text>" in 24-hour local time.
"""
import asyncio
import json
import random
import re
import time
from dataclasses import dataclass, field
from datetime import date, datetime
from functools import lru_cache
from string import Template
from typing import Any, AsyncGenerator

from langchain.agents import create_agent
from langchain_openai import ChatOpenAI

from . import job_store
from .config import (
    AGENT_MAX_TOKENS,
    AGENT_TEMPERATURE,
    OPENROUTER_BASE_URL,
    OPENROUTER_MODEL,
    OPENROUTER_TIMEOUT_SECONDS,
    STREAM_LINE_FLUSH_CHARS,
    openrouter_api_key,
    read_prompt,
    resolve_model_entry,
)
from .websearch import RESEARCH_TOOLS, start_retrieval_ledger, verify_citations


@dataclass(frozen=True)
class Stage:
    """One pipeline step. `key` is the stage's identity everywhere it is
    persisted or referenced: the context key later stages read, the `$key`
    placeholder their prompts use, and outputs/<key>.json on disk. `name` is
    only ever a human-facing label."""

    name: str
    key: str
    summary: str
    prompt_file: str
    needs: tuple[str, ...] = field(default=())
    uses_tools: bool = False


# The prompt text itself lives in prompts/runtime/*.txt, not here — this is
# just the wiring. Templates use `string.Template` ($policy/$intake/...)
# rather than str.format(), since the JSON-schema instructions are full of
# literal {braces} that would collide with format-style placeholders.
_STAGES: tuple[Stage, ...] = (
    Stage("Intake", "intake", "Policy parsed and scope defined", "intake.txt"),
    Stage(
        "Research", "research", "Public sources gathered and cited", "research.txt",
        needs=("intake",), uses_tools=True,
    ),
    Stage("Causality", "causality", "Origin chain reconstructed", "causality.txt",
          needs=("intake", "research")),
    Stage("Impact", "impact", "Economic and social effects mapped", "impact.txt",
          needs=("intake", "research")),
    Stage("Comparators", "comparators", "Global analogs benchmarked", "comparators.txt",
          needs=("intake", "research")),
    Stage("Forecast", "forecast", "Scenarios and triggers generated", "forecast.txt",
          needs=("intake", "research", "causality", "impact", "comparators")),
    Stage("Stakeholders", "stakeholders", "Stakeholder landscape mapped", "stakeholders.txt",
          needs=("intake", "research", "causality", "impact", "forecast")),
    Stage("Alternatives", "alternatives", "Policy options weighed", "alternatives.txt",
          needs=("intake", "research", "causality", "impact", "comparators", "forecast")),
    Stage("Red-team", "redteam", "Objections stress-tested", "redteam.txt",
          needs=("intake", "research", "causality", "impact", "forecast",
                 "stakeholders", "alternatives")),
)


def _validate_stages() -> None:
    """Fail loudly at import on the three ways this wiring can silently rot:
    a stage ordered before something it needs, a prompt reading context the
    stage never declared (it would substitute nothing and the model would
    confidently answer from an empty brief), or a declared input no prompt
    actually uses (dead weight in every request). All three are cheap to keep
    correct and expensive to discover in a finished report."""
    produced: set[str] = set()
    for stage in _STAGES:
        missing = [key for key in stage.needs if key not in produced]
        if missing:
            raise RuntimeError(
                f"Stage {stage.name!r} needs {missing}, which no earlier stage produces"
            )

        declared = {"policy", *stage.needs}
        used = set(_prompt_template(stage.prompt_file).get_identifiers())
        if undeclared := sorted(used - declared):
            raise RuntimeError(
                f"{stage.prompt_file} reads {undeclared} which {stage.name!r} does not declare in needs"
            )
        if unused := sorted(declared - used - {"policy"}):
            raise RuntimeError(
                f"{stage.name!r} declares {unused} but {stage.prompt_file} never uses it"
            )

        produced.add(stage.key)


@lru_cache(maxsize=None)
def _prompt_template(filename: str) -> Template:
    return Template(read_prompt(filename))


_validate_stages()  # after _prompt_template — the check reads the templates


@lru_cache(maxsize=None)
def _system_prefix() -> str:
    return read_prompt("system_prefix.txt")


def _stage_prompt(stage: Stage, policy: str, ctx: dict[str, Any]) -> str:
    """Substitute exactly the upstream outputs this stage declared — nothing
    more, so a prompt can never quietly depend on context it didn't ask for."""
    substitutions = {"policy": policy}
    for key in stage.needs:
        substitutions[key] = json.dumps(ctx.get(key, {}), ensure_ascii=False)
    return _prompt_template(stage.prompt_file).safe_substitute(substitutions)


_THINK_BLOCK_RE = re.compile(r"<think>.*?</think>", re.DOTALL | re.IGNORECASE)


def _iter_json_candidates(text: str):
    """Yield successive balanced {...} substrings, one per '{' found, tracking
    brace depth while ignoring braces inside string literals. A model may
    ramble with brace-balanced but non-JSON chatter before the real object
    (e.g. 'note {not json} here: {"a": 1}') — brace-balance alone can't tell
    those apart, so _parse_json tries each candidate in turn until one
    actually parses. A greedy `\\{.*\\}` regex has neither of these
    properties: it can't skip a bad leading candidate, and it overshoots
    past the real object into trailing chatter."""
    pos = 0
    while True:
        start = text.find("{", pos)
        if start == -1:
            return

        depth = 0
        in_string = False
        escape = False
        end = None
        for i in range(start, len(text)):
            ch = text[i]
            if in_string:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == '"':
                    in_string = False
            elif ch == '"':
                in_string = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    end = i + 1
                    break

        if end is None:
            yield text[start:]  # unbalanced/truncated tail — let json.loads raise on it
            return
        yield text[start:end]
        pos = start + 1  # keep looking — this candidate might not be valid JSON


def _parse_json(text: str) -> dict[str, Any]:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
    text = _THINK_BLOCK_RE.sub("", text).strip()  # reasoning models often wrap chain-of-thought in <think>

    last_error: json.JSONDecodeError | None = None
    for candidate in _iter_json_candidates(text):
        try:
            return json.loads(candidate)
        except json.JSONDecodeError as exc:
            last_error = exc
    raise last_error or json.JSONDecodeError("No JSON object found in output", text, 0)


def _sse(payload: dict) -> str:
    return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"


def _stream_line(text: str) -> str:
    """Prefix a chunk of streamed agent output with a 24-hour [HH:MM] timestamp."""
    return f"[{datetime.now():%H:%M}] - {text}"


def build_model(model_name: str | None = None) -> ChatOpenAI:
    """An OpenRouter chat model — used by the pipeline stages here and by the
    per-job chat agent in app/chat_agent.py. `model_name` overrides the default
    OpenRouter model for a per-run model choice."""
    return ChatOpenAI(
        model=model_name or OPENROUTER_MODEL,
        api_key=openrouter_api_key(),
        base_url=OPENROUTER_BASE_URL,
        temperature=AGENT_TEMPERATURE,
        timeout=OPENROUTER_TIMEOUT_SECONDS,
        max_tokens=AGENT_MAX_TOKENS,
        streaming=True,
        stream_usage=True,  # ask for a usage chunk so token counts are available post-stream
        default_headers={"HTTP-Referer": "http://localhost:5173", "X-Title": "Policy 360"},
    )


def _build_pipeline_model(model_id: str | None):
    """Resolve a selectable model id to (model, provider). OpenRouter models
    stream token-by-token; the Claude Code model is synchronous, so its whole
    answer arrives as one block (see _run_agent_stage)."""
    entry = resolve_model_entry(model_id)
    provider = entry.get("provider", "openrouter")
    if provider == "claude":
        from .claude_util import create_claude_model
        return create_claude_model(model_name=entry["id"]), provider
    return build_model(entry["id"]), provider


_IMPACT_DIMENSIONS = ("economic", "environmental", "political", "social")


def _traffic_light(bars: dict[str, Any]) -> dict[str, str]:
    """Derive each dimension's traffic-light colour from its 0-100 score.

    Previously the model was asked for both. Two encodings of one judgment can
    disagree — a green light beside a 22/100 bar — and the colour carries no
    information the score doesn't, so it's computed here instead of generated.
    """
    states = {}
    for dimension in _IMPACT_DIMENSIONS:
        try:
            value = int(bars[dimension])
        except (KeyError, TypeError, ValueError):
            continue  # no score means no colour — the UI shows a neutral bar
        states[dimension] = (
            "performing" if value >= 67 else "mixed" if value >= 34 else "underperforming"
        )
    return states


def _assemble_report(policy: str, ctx: dict[str, Any]) -> dict[str, Any]:
    """Fold every stage's structured output into the single report the UI
    consumes. Each agent produces far more than a headline number, so this
    surfaces the full retrospective / evaluative / predictive picture rather
    than a lossy summary — missing keys degrade to sensible empties so a
    partial or older run still renders."""
    intake = ctx.get("intake", {})
    research = ctx.get("research", {})
    causality = ctx.get("causality", {})
    impact = ctx.get("impact", {})
    comparators = ctx.get("comparators", {})
    forecast = ctx.get("forecast", {})
    stakeholders = ctx.get("stakeholders", {})
    alternatives = ctx.get("alternatives", {})
    redteam = ctx.get("redteam", {})
    bars = impact.get("impact_bars", {})
    return {
        "policy": {
            "name": intake.get("name", policy),
            "category": intake.get("category", "Other"),
            "ministry": intake.get("ministry", "—"),
            "documentReference": intake.get("documentReference"),
            "firstEnacted": intake.get("firstEnacted"),
            "lastAmended": intake.get("lastAmended"),
            "status": intake.get("status", "Active"),
            "analysisDate": date.today().isoformat(),
            "depth": "Standard",
            "horizon": "5yr",
            "healthScore": impact.get("health_score", 0),
            "healthLabel": impact.get("health_label", "—"),
            "summary": intake.get("summary", ""),
            "coreObjectives": intake.get("coreObjectives", []),
            "keyProvisions": intake.get("keyProvisions", []),
            "administeringBodies": intake.get("administeringBodies", []),
            "enforcementMechanism": intake.get("enforcementMechanism", ""),
        },
        # ----- Retrospective: what caused this -----
        "causeFlow": causality.get("cause_flow", []),
        "timeline": causality.get("timeline", []),
        "causalStory": {
            "surfaceRationale": causality.get("surface_rationale", ""),
            "deeperCauseChain": causality.get("deeper_cause_chain", ""),
            "triggerEvents": causality.get("trigger_events", []),
            "politicalContext": causality.get("political_context", ""),
            "stakeholderPressures": causality.get("stakeholder_pressures", []),
            "priorAttempts": causality.get("prior_attempts", []),
            "confidence": causality.get("confidence_level", ""),
        },
        # ----- Evaluative: where it sits today -----
        "impactBars": [
            {"label": "Economic", "value": bars.get("economic", 0)},
            {"label": "Environmental", "value": bars.get("environmental", 0)},
            {"label": "Political", "value": bars.get("political", 0)},
            {"label": "Social", "value": bars.get("social", 0)},
        ],
        "impactDetail": {
            "economic": impact.get("economic_impact", ""),
            "environmental": impact.get("environmental_impact", ""),
            "political": impact.get("political_impact", ""),
            "social": impact.get("social_impact", ""),
        },
        "trafficLight": _traffic_light(bars),
        "impactReasons": impact.get("impact_reasons", {}),
        "healthBreakdown": impact.get("health_breakdown", []),
        "curvePosition": forecast.get("curvePosition", {}),
        "comparators": comparators.get("comparators", []),
        "comparatorSynthesis": comparators.get("comparatorSynthesis", ""),
        "structuralFactors": forecast.get("structuralFactors", {}),
        # ----- Predictive: what follows -----
        "projection": forecast.get("projection", {}),
        "scenarios": forecast.get("scenarios", {}),
        "watchlist": forecast.get("watchlist", []),
        "assumptions": forecast.get("assumptionsRegister", []),
        # Predecessors come from Causality's prior_attempts — it already had to
        # work out what came before and why it fell short, so Comparators no
        # longer duplicates that judgment.
        "relatedPolicies": {
            **comparators.get("relatedPolicies", {}),
            "predecessor": causality.get("prior_attempts", []),
        },
        # ----- Deliberative: consultation (stakes, options, scrutiny) -----
        "stakeholderMap": {
            "stakeholders": stakeholders.get("stakeholders", []),
            "consensus": stakeholders.get("consensus", ""),
            "flashpoints": stakeholders.get("flashpoints", []),
            "summary": stakeholders.get("summary", ""),
        },
        "alternatives": {
            "options": alternatives.get("alternatives", []),
            "recommendedOption": alternatives.get("recommendedOption", ""),
            "recommendation": alternatives.get("recommendation", ""),
        },
        "redTeam": {
            "objections": redteam.get("objections", []),
            "weakestPoint": redteam.get("weakestPoint", ""),
            "robustness": redteam.get("robustness", ""),
            "verdict": redteam.get("verdict", ""),
        },
        # ----- Evidence base -----
        "keyFacts": research.get("key_facts", []),
        "sources": research.get("sources", []),
        "conflictingEvidence": research.get("conflicting_evidence", []),
        "evidenceGaps": research.get("evidence_gaps", []),
    }


# Transient upstream failures — rate limits, connection drops, 5xx — are
# routine on free-tier models and say nothing about the request. Retrying
# beats discarding every stage completed so far. Matched by class name so
# this doesn't hard-depend on the openai package's exception hierarchy.
_TRANSIENT_ERRORS = frozenset({
    "RateLimitError", "APIConnectionError", "APITimeoutError", "APIError",
    "InternalServerError", "ServiceUnavailableError",
    "ConnectError", "ConnectTimeout", "ReadTimeout", "RemoteProtocolError",
})
TRANSIENT_BACKOFF_SECONDS = (15, 45, 90)
MAX_JSON_REPAIRS = 1


def _is_transient(exc: BaseException) -> bool:
    return type(exc).__name__ in _TRANSIENT_ERRORS


JSON_REPAIR_SUFFIX = (
    "\n\nIMPORTANT: your previous answer could not be parsed as JSON. Reply with the "
    "JSON object described above and nothing else — no reasoning, no preamble, no code "
    "fences. If you are running out of room, shorten the prose fields rather than "
    "leaving the JSON unterminated."
)


async def _run_agent_stage(
    agent, stage: "Stage", prompt: str, job_id: str, streaming: bool = True,
) -> AsyncGenerator[Any, None]:
    """Run one agent turn, yielding SSE lines as we go, then a final
    ('__done__', parsed_json, token_count) sentinel tuple.

    Streaming models (OpenRouter) emit token deltas live via the "messages"
    stream. The Claude Code model is synchronous and can't stream, so for it we
    run the turn in a worker thread and surface its whole result and usage as a
    single log block. Either way the "values" stream/state is the source of
    truth for token usage.

    Transient errors (429s, timeouts) are handled one level up in run_pipeline,
    which re-runs this whole stage after a backoff — nothing is emitted before
    the call succeeds, so re-running can't duplicate output.
    """
    buffer = ""
    final_state: dict[str, Any] = {}

    if streaming:
        async for mode, payload in agent.astream(
            {"messages": [{"role": "user", "content": prompt}]},
            stream_mode=["messages", "values"],
        ):
            if mode == "values":
                final_state = payload
                continue

            message_chunk, _metadata = payload
            token = message_chunk.content
            if not token:
                continue
            buffer += token

            while "\n" in buffer:
                line, buffer = buffer.split("\n", 1)
                if line.strip():
                    yield _sse({"type": "stream", "agent": stage.name, "line": _stream_line(line)})
            if len(buffer) >= STREAM_LINE_FLUSH_CHARS:
                yield _sse({"type": "stream", "agent": stage.name, "line": _stream_line(buffer)})
                buffer = ""
    else:
        # Synchronous model (Claude Code): run off the event loop so the stream
        # response stays responsive, then replay its output as log lines.
        final_state = await asyncio.to_thread(
            agent.invoke, {"messages": [{"role": "user", "content": prompt}]}
        )
        latest = (final_state.get("messages") or [])
        content_now = latest[-1].content if latest else ""
        for line in str(content_now).splitlines():
            if line.strip():
                yield _sse({"type": "stream", "agent": stage.name, "line": _stream_line(line)})

    messages = final_state.get("messages", [])
    final_message = messages[-1] if messages else None

    # A tool-using stage (Research) makes several model calls per turn, each
    # with its own usage — sum them all, or the reported cost is only the
    # final call after the searches.
    usage_totals = [
        int((getattr(m, "usage_metadata", None) or {}).get("total_tokens", 0)) for m in messages
    ]
    tokens = sum(usage_totals)
    usage = getattr(final_message, "usage_metadata", None) or {}

    # Fold the token count into the same logline as the tail of the content —
    # usage only becomes known once the stream ends, so it rides the last line
    # rather than spawning a separate one.
    tail = buffer.strip()
    if tail or tokens:
        text = f"{tail}  ·  {tokens} tokens" if tokens else tail
        yield _sse({"type": "stream", "agent": stage.name, "line": _stream_line(text)})

    content = final_message.content if final_message is not None else ""
    tool_calls = sum(1 for m in messages if getattr(m, "type", "") == "tool")
    job_store.append_log(
        job_id, stage.name,
        f"received {len(content)} chars over {len(messages)} messages "
        f"({tool_calls} tool results) — final usage_metadata: {json.dumps(usage, ensure_ascii=False)}",
    )

    try:
        parsed = _parse_json(content)
    except json.JSONDecodeError:
        raw_filename = f"{stage.key}_unparsed.txt"
        job_store.save_raw(job_id, raw_filename, content)
        job_store.append_log(
            job_id, stage.name, f"JSON parse failed — raw output saved to raw/{raw_filename}",
        )
        raise

    yield ("__done__", parsed, tokens)


async def run_pipeline(
    policy: str, user_id: int, job_id: str, model_id: str | None = None,
) -> AsyncGenerator[str, None]:
    """Yield SSE events for each agent step, then the assembled report.

    Every stage's structured output, a log line, and a state snapshot are
    written to jobs/<job_id>/ on disk as they complete (see job_store.py);
    the job's status/current_stage in SQLite is kept in sync alongside.

    Resumable: any stage whose output is already on disk (from an earlier run
    of this same job) is replayed from cache and skipped, so a retry picks up
    at the stage that failed rather than starting over. `model_id` selects the
    model for this run.
    """
    # Clear any prior failure so a resumed job reads as running again.
    job_store.update_job(job_id, status="running", error_message=None)
    job_store.write_state(job_id, {"status": "running", "error_message": None})
    yield _sse({"type": "job_created", "job_id": job_id})

    stage_model, provider = _build_pipeline_model(model_id)

    if provider == "openrouter" and not openrouter_api_key():
        message = "OPENROUTER_API_KEY is not set on the server."
        job_store.update_job(job_id, status="failed", error_message=message)
        job_store.write_state(job_id, {"status": "failed", "error_message": message})
        yield _sse({"type": "error", "message": message})
        return

    streaming = provider != "claude"
    # Two agents: the retrieval stage gets the public-web tools, every other
    # stage reasons over what Research already returned.
    plain_agent = create_agent(stage_model, tools=[], system_prompt=_system_prefix())
    research_agent = create_agent(stage_model, tools=RESEARCH_TOOLS, system_prompt=_system_prefix())

    ctx: dict[str, Any] = {}

    for stage in _STAGES:
        # Resume: if this stage already produced output on a previous run of
        # this job, replay it from cache and move on to the next.
        cached = job_store.read_stage_output(job_id, stage.key)
        if cached is not None:
            ctx[stage.key] = cached
            job_store.append_log(job_id, stage.name, "loaded from previous run (cached)")
            yield _sse({"type": "step_start", "agent": stage.name})
            yield _sse({
                "type": "step_done",
                "agent": stage.name,
                "summary": f"{stage.summary} (cached)",
                "seconds": 0,
                "tokens": 0,
                "result": cached,
            })
            continue

        job_store.update_job(job_id, current_stage=stage.name)
        job_store.write_state(job_id, {"current_stage": stage.name})
        job_store.append_log(job_id, stage.name, f"started (inputs: {', '.join(stage.needs) or 'policy query'})")
        yield _sse({"type": "step_start", "agent": stage.name})
        started = time.monotonic()

        agent = research_agent if stage.uses_tools else plain_agent
        prompt = _stage_prompt(stage, policy, ctx)
        result: dict[str, Any] | None = None
        tokens = 0
        failure = ""
        # Ledger of what the tools actually served this stage, used below to
        # throw out any citation the model invented rather than retrieved.
        retrieved = start_retrieval_ledger() if stage.uses_tools else set()

        # Two independent retry budgets, because the two failure modes need
        # different handling. A malformed answer is the model's fault and is
        # retried once with a repair instruction; a rate limit or dropped
        # connection is the upstream's fault, says nothing about the request,
        # and is retried after a backoff. Either way, throwing away every
        # stage completed so far is the worst possible response.
        json_repairs = 0
        transient_retries = 0
        while True:
            attempt_prompt = prompt + (JSON_REPAIR_SUFFIX if json_repairs else "")
            try:
                async for item in _run_agent_stage(agent, stage, attempt_prompt, job_id, streaming):
                    if isinstance(item, tuple) and item[0] == "__done__":
                        _, result, stage_tokens = item
                        tokens += stage_tokens
                    else:
                        yield item
                failure = ""
                break
            except json.JSONDecodeError:
                if json_repairs >= MAX_JSON_REPAIRS:
                    failure = (
                        f"{stage.name} agent failed: output was not valid JSON "
                        f"after {json_repairs + 1} attempts."
                    )
                    break
                json_repairs += 1
                note = "output was not valid JSON — retrying once with a repair instruction"
            except Exception as exc:  # OpenRouter/network/model errors of any shape
                if not _is_transient(exc) or transient_retries >= len(TRANSIENT_BACKOFF_SECONDS):
                    failure = f"{stage.name} agent failed: {type(exc).__name__}."
                    break
                # Jitter so a retry storm doesn't re-collide on the next window.
                delay = TRANSIENT_BACKOFF_SECONDS[transient_retries] + random.uniform(0, 5)
                transient_retries += 1
                note = f"{type(exc).__name__} from the model provider — retrying in {round(delay)}s"
                job_store.append_log(job_id, stage.name, note)
                yield _sse({"type": "stream", "agent": stage.name, "line": _stream_line(note)})
                await asyncio.sleep(delay)
                continue

            job_store.append_log(job_id, stage.name, note)
            yield _sse({"type": "stream", "agent": stage.name, "line": _stream_line(note)})

        if failure or result is None:
            message = failure or f"{stage.name} agent returned no result."
            job_store.append_log(job_id, stage.name, message)
            job_store.update_job(job_id, status="failed", error_message=message)
            job_store.write_state(job_id, {"status": "failed", "error_message": message})
            yield _sse({"type": "error", "message": message})
            return

        if stage.uses_tools:
            result, fabricated = verify_citations(result, retrieved)
            note = f"{len(retrieved)} pages retrieved"
            if fabricated:
                note += f"; dropped {len(fabricated)} unretrieved citation(s): {', '.join(fabricated)}"
            job_store.append_log(job_id, stage.name, note)
            yield _sse({"type": "stream", "agent": stage.name, "line": _stream_line(note)})

        ctx[stage.key] = result
        job_store.save_stage_output(job_id, stage.key, result)
        job_store.append_log(
            job_id, stage.name,
            f"completed in {round(time.monotonic() - started, 1)} sec, {tokens} tokens",
        )
        yield _sse({
            "type": "step_done",
            "agent": stage.name,
            "summary": stage.summary,
            "seconds": round(time.monotonic() - started, 1),
            "tokens": tokens,
            "result": result,
        })

    report = _assemble_report(policy, ctx)
    job_store.save_report(job_id, report)
    job_store.update_job(
        job_id,
        status="completed",
        current_stage=None,
        policy_name=report["policy"]["name"],
        category=report["policy"]["category"],
    )
    job_store.write_state(job_id, {"status": "completed", "current_stage": None})

    # Persist as a categorised workflow for this user (unchanged legacy path)
    try:
        from .database import SessionLocal
        from .models import Workflow

        with SessionLocal() as db:
            db.add(Workflow(
                user_id=user_id,
                name=report["policy"]["name"],
                category=report["policy"]["category"],
                status="completed",
                payload=json.dumps(report, ensure_ascii=False),
            ))
            db.commit()
    except Exception:
        pass  # persistence failure should not break the stream

    yield _sse({"type": "report", "report": report, "job_id": job_id})
