"""Policy 360 backend — FastAPI app with JWT auth over SQLite."""
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import chat_agent, job_store
from .agents import run_pipeline
from .auth import create_access_token, get_current_user, hash_password, verify_password
from .config import (
    CORS_ALLOW_ORIGINS,
    DEFAULT_ADMIN_PASSWORD,
    DEFAULT_ADMIN_USERNAME,
    OPENROUTER_MODEL,
    load_model_config,
)
from .data_config import LANDING_POLICIES
from .database import Base, SessionLocal, engine, get_db
from .models import Job, LoginEvent, User, Workflow, utcnow
from .schemas import (
    ChatRequest,
    ChatResponse,
    JobDetail,
    JobOut,
    LoginEventOut,
    LoginRequest,
    PolicyCardOut,
    TokenResponse,
    UserOut,
    WorkflowCreate,
    WorkflowOut,
)


def seed_default_admin() -> None:
    with SessionLocal() as db:
        exists = db.scalar(select(User).where(User.username == DEFAULT_ADMIN_USERNAME))
        if not exists:
            db.add(User(
                username=DEFAULT_ADMIN_USERNAME,
                password_hash=hash_password(DEFAULT_ADMIN_PASSWORD),
                role="admin",
            ))
            db.commit()


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    seed_default_admin()
    yield


app = FastAPI(title="Policy 360 API", version="0.2.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ALLOW_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/config")
def server_config():
    """Runtime settings the UI displays — the default model, so it's visible
    without reading the server config."""
    return {"model": load_model_config().get("default", OPENROUTER_MODEL)}


@app.get("/models")
def list_models():
    """The models a user can pick from on the home page (model_config.json)."""
    return load_model_config()


# ---------- Auth ----------

@app.post("/auth/login", response_model=TokenResponse)
def login(body: LoginRequest, request: Request, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.username == body.username))
    if user is None or not verify_password(body.password, user.password_hash):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect username or password")

    user.last_login_at = utcnow()
    db.add(LoginEvent(user_id=user.id, client=request.headers.get("user-agent")))
    db.commit()

    return TokenResponse(
        access_token=create_access_token(user),
        username=user.username,
        role=user.role,
    )


@app.get("/auth/me", response_model=UserOut)
def me(current: User = Depends(get_current_user)):
    return current


@app.get("/auth/logins", response_model=list[LoginEventOut])
def login_history(current: User = Depends(get_current_user), db: Session = Depends(get_db)):
    events = db.scalars(
        select(LoginEvent)
        .where(LoginEvent.user_id == current.id)
        .order_by(LoginEvent.logged_in_at.desc())
        .limit(50)
    )
    return list(events)


# ---------- Landing-page policy list ----------

@app.get("/policies", response_model=list[PolicyCardOut])
def list_landing_policies(current: User = Depends(get_current_user)):
    return LANDING_POLICIES


# ---------- Analysis (OpenRouter agent pipeline, SSE stream) ----------

class AnalysisRequest(BaseModel):
    policy: str
    model: str | None = None
    # When set, resume this existing job (reusing its completed stage outputs)
    # instead of creating a fresh one — powers "retry from the failed agent".
    job_id: str | None = None


@app.post("/analysis/stream")
async def analysis_stream(
    body: AnalysisRequest,
    current: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    policy = body.policy.strip()
    if not policy:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Policy query is empty")

    if body.job_id:
        job = _owned_job(body.job_id, current, db)  # 404s if not the caller's job
    else:
        job = job_store.create_job(policy, current.id)

    return StreamingResponse(
        run_pipeline(policy, current.id, job.job_id, body.model),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ---------- Jobs (SQLite metadata + on-disk artifacts under jobs/<job_id>/) ----------

def _owned_job(job_id: str, current: User, db: Session) -> Job:
    """Fetch a job, 404-ing if it doesn't exist *or* belongs to someone else —
    the same response either way, so job ids of other users aren't probeable."""
    job = db.get(Job, job_id)
    if job is None or job.user_id != current.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Job not found")
    return job


@app.get("/jobs", response_model=list[JobOut])
def list_jobs(current: User = Depends(get_current_user), db: Session = Depends(get_db)):
    stmt = select(Job).where(Job.user_id == current.id).order_by(Job.created_at.desc())
    return list(db.scalars(stmt))


@app.get("/jobs/{job_id}", response_model=JobDetail)
def get_job(job_id: str, current: User = Depends(get_current_user), db: Session = Depends(get_db)):
    job = _owned_job(job_id, current, db)
    return JobDetail(
        job=JobOut.model_validate(job),
        state=job_store.read_state(job_id),
        files=job_store.list_files(job_id),
    )


@app.get("/jobs/{job_id}/log")
def get_job_log(job_id: str, current: User = Depends(get_current_user), db: Session = Depends(get_db)):
    _owned_job(job_id, current, db)
    return {"log": job_store.read_log(job_id)}


@app.get("/jobs/{job_id}/outputs/{stage}")
def get_job_stage_output(
    job_id: str, stage: str,
    current: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _owned_job(job_id, current, db)
    data = job_store.read_stage_output(job_id, stage)
    if data is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Stage output not found")
    return data


@app.get("/jobs/{job_id}/report")
def get_job_report(job_id: str, current: User = Depends(get_current_user), db: Session = Depends(get_db)):
    _owned_job(job_id, current, db)
    report = job_store.read_report(job_id)
    if report is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Report not available yet")
    return report


# ---------- Chat over one job's folder (deepagents, filesystem-scoped) ----------

@app.post("/jobs/{job_id}/chat", response_model=ChatResponse)
async def chat_with_job(
    job_id: str,
    body: ChatRequest,
    current: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Answer a question about a job using only the files under jobs/<job_id>/.

    Ownership is checked here; the agent's filesystem backend is then rooted at
    that one folder, so the scope can't widen even if the model asks it to.
    """
    _owned_job(job_id, current, db)
    message = body.message.strip()
    if not message:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Message is empty")
    try:
        reply = await chat_agent.answer(
            job_id, message, [turn.model_dump() for turn in body.history],
        )
    except Exception as exc:  # model/network/tool errors of any shape
        raise HTTPException(
            status.HTTP_502_BAD_GATEWAY, f"Chat agent failed: {type(exc).__name__}",
        ) from exc
    return ChatResponse(reply=reply)


# ---------- Workflows (categorised, per-user) ----------

@app.get("/workflows", response_model=list[WorkflowOut])
def list_workflows(
    category: str | None = None,
    current: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    stmt = select(Workflow).where(Workflow.user_id == current.id)
    if category:
        stmt = stmt.where(Workflow.category == category)
    return list(db.scalars(stmt.order_by(Workflow.updated_at.desc())))


@app.post("/workflows", response_model=WorkflowOut, status_code=status.HTTP_201_CREATED)
def create_workflow(
    body: WorkflowCreate,
    current: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    wf = Workflow(user_id=current.id, name=body.name, category=body.category, payload=body.payload)
    db.add(wf)
    db.commit()
    db.refresh(wf)
    return wf
