import asyncio
import json
from typing import Any, List, Optional

from langchain.agents import create_agent
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage
from langchain_core.messages.ai import UsageMetadata
from langchain_core.outputs import ChatGeneration, ChatResult

from claude_code_agent import AgentConfig, run_agent


class ClaudeCodeChatModel(BaseChatModel):
    """LangChain chat model backed by the local Claude Code agent."""

    workdir: str = "."
    model: Optional[str] = None

    @property
    def _llm_type(self) -> str:
        return "claude-code-agent"

    @staticmethod
    def _to_prompt(messages: List[BaseMessage]) -> str:
        return "\n".join(f"{m.type}: {m.content}" for m in messages)

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[Any] = None,
        **kwargs: Any,
    ) -> ChatResult:
        prompt = self._to_prompt(messages)
        config = AgentConfig(
            workdir=self.workdir,
            model=self.model,
            permission_mode="bypassPermissions",
        )
        result = asyncio.run(run_agent(prompt, config))

        usage = result.usage or {}
        input_tokens = usage.get("input_tokens", 0)
        output_tokens = usage.get("output_tokens", 0)
        usage_metadata = UsageMetadata(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens,
            input_token_details={
                "cache_read": usage.get("cache_read_input_tokens", 0),
                "cache_creation": usage.get("cache_creation_input_tokens", 0),
            },
        )

        response_metadata = {
            "total_cost_usd": result.total_cost_usd,
            "usage": usage,
            "model_usage": result.model_usage,
            "num_turns": result.num_turns,
            "duration_ms": result.duration_ms,
            "stop_reason": result.stop_reason,
            "session_id": result.session_id,
        }

        print(f"\033[95m{result.result or ''}\033[0m")
        print("usage_metadata:", json.dumps(usage_metadata, indent=2, default=str))
        print("response_metadata:", json.dumps(response_metadata, indent=2, default=str))

        message = AIMessage(
            content=result.result or "",
            usage_metadata=usage_metadata,
            response_metadata=response_metadata,
        )
        return ChatResult(generations=[ChatGeneration(message=message)])

    def bind_tools(self, tools, **kwargs: Any) -> "ClaudeCodeChatModel":
        # Tool use is handled internally by the Claude Code agent, so tool
        # bindings from LangChain agent frameworks are accepted and ignored.
        return self


def create_claude_model(
    *,
    model_name: str = "claude-sonnet-5",
    workdir: str = ".",
) -> ClaudeCodeChatModel:
    """Initialize the Claude Code-backed chat model once for a given workspace."""
    return ClaudeCodeChatModel(workdir=workdir, model=model_name)


def call_llm(
    prompt: str,
    model_name: str = "claude-sonnet-5",
    workdir: str = ".",
) -> str:
    """Invoke the Claude-backed chat model directly, without an agent loop."""
    model = create_claude_model(model_name=model_name, workdir=workdir)
    response = model.invoke([HumanMessage(content=prompt)])
    return response.content


def call_agent(
    prompt: str,
    system_prompt: str = "You are a helpful assistant.",
    model_name: str = "claude-sonnet-5",
    workdir: str = ".",
) -> str:
    """Initialize a LangChain agent (create_agent) and invoke it."""
    model = create_claude_model(model_name=model_name, workdir=workdir)
    agent = create_agent(model=model, system_prompt=system_prompt)
    result = agent.invoke({"messages": [{"role": "user", "content": prompt}]})
    messages = result.get("messages", []) if isinstance(result, dict) else []
    if not messages:
        return ""
    last_message = messages[-1]
    return getattr(last_message, "content", str(last_message))


def main() -> None:
    llm_response = call_llm("What is the capital of France?")
    print("call_llm result:", llm_response)

    agent_response = call_agent("What is the capital of France?")
    print("call_agent result:", agent_response)


if __name__ == "__main__":
    main()
