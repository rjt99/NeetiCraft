"""Pydantic request/response schemas."""
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class LoginRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    username: str
    role: str


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    username: str
    role: str
    created_at: datetime
    last_login_at: datetime | None


class LoginEventOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    logged_in_at: datetime
    client: str | None


class WorkflowCreate(BaseModel):
    name: str
    category: str
    payload: str | None = None


class WorkflowOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    category: str
    status: str
    payload: str | None
    created_at: datetime
    updated_at: datetime


class JobOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    job_id: str
    policy_query: str
    policy_name: str | None
    category: str | None
    status: str
    current_stage: str | None
    folder_path: str
    error_message: str | None
    created_at: datetime
    updated_at: datetime


class JobDetail(BaseModel):
    job: JobOut
    state: dict | None
    files: list[str]


class ChatTurn(BaseModel):
    role: Literal["user", "assistant"]
    content: str


class ChatRequest(BaseModel):
    message: str
    # Prior turns, oldest first. The client owns the transcript — the server
    # keeps no chat state between requests.
    history: list[ChatTurn] = Field(default_factory=list)


class ChatResponse(BaseModel):
    reply: str


class PolicyCardOut(BaseModel):
    name: str
    category: str
    ministry: str
    enacted: int
    health: int
    stat: str
