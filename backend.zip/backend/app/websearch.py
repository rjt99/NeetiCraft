"""Public-web search and page-fetch tools for the Research agent.

Two tools are exposed to the model: `web_search` (query -> ranked results
with real URLs) and `fetch_page` (URL -> readable text). Everything they
touch must be on the **public** web, which is enforced here rather than
trusted to the prompt:

  - http/https only, on default ports, with no credentials in the URL;
  - every hostname is DNS-resolved and rejected if any address lands in a
    private, loopback, link-local, reserved or multicast range — so the
    agent can never be talked into reading this host's own services or
    anything else on the operator's network (SSRF guard);
  - redirects are followed manually so each hop is re-validated, not just
    the URL the model supplied;
  - known paywalled / login-walled domains are dropped from results and
    refused on fetch, since their content isn't publicly readable and
    quoting it would be citing something no reader can open.

Search provider is whichever is configured, in order of quality: Tavily,
Brave, then keyless DuckDuckGo as the zero-configuration default. A
provider outage degrades to an error string the model can read and work
around — it never breaks the pipeline.
"""
import asyncio
import ipaddress
import re
import socket
from contextvars import ContextVar
from html.parser import HTMLParser
from typing import Any
from urllib.parse import urlparse, urlunparse

import httpx
from langchain_core.tools import tool

from .config import (
    BLOCKED_DOMAINS,
    BRAVE_API_KEY,
    FETCH_MAX_BYTES,
    FETCH_MAX_CHARS,
    FETCH_TIMEOUT_SECONDS,
    HTTP_USER_AGENT,
    SEARCH_MAX_RESULTS,
    SEARCH_TIMEOUT_SECONDS,
    TAVILY_API_KEY,
)

_ALLOWED_SCHEMES = ("http", "https")
_ALLOWED_PORTS = {None, 80, 443}
_MAX_REDIRECTS = 3


# ---------- retrieval ledger ----------
#
# Models — small ones especially — will happily emit a plausible-looking URL
# they never opened. A fabricated citation is worse than no citation, since it
# looks checkable and isn't. So every URL the tools actually serve is recorded
# here, and verify_citations() below drops any the agent didn't get from them.

_retrieved: ContextVar[set[str] | None] = ContextVar("retrieved_urls", default=None)


def canonical_url(url: str) -> str:
    """Compare URLs on scheme+host+path+query, ignoring case, 'www.',
    trailing slashes and fragments — so a citation isn't rejected over
    cosmetic differences from what the tool returned."""
    p = urlparse(url.strip())
    host = (p.hostname or "").lower().removeprefix("www.")
    path = p.path.rstrip("/")
    return urlunparse((p.scheme.lower(), host, path, "", p.query, ""))


def start_retrieval_ledger() -> set[str]:
    """Begin recording retrieved URLs for one stage; returns the live set."""
    urls: set[str] = set()
    _retrieved.set(urls)
    return urls


def _record(url: str) -> None:
    ledger = _retrieved.get()
    if ledger is not None and url:
        ledger.add(canonical_url(url))


def verify_citations(result: Any, retrieved: set[str]) -> tuple[Any, list[str]]:
    """Strip URLs the tools never served from a research result.

    Returns the cleaned result and the list of dropped URLs. A dropped source
    keeps its title and is re-labelled as unretrieved rather than deleted —
    the claim may still be true, it just isn't a citation.
    """
    if not isinstance(result, dict):
        return result, []

    dropped: list[str] = []
    cleaned = []
    for source in result.get("sources") or []:
        if not isinstance(source, dict):
            cleaned.append({"title": str(source), "url": None})
            continue
        url = source.get("url")
        if url and canonical_url(str(url)) not in retrieved:
            dropped.append(str(url))
            source = {
                **source,
                "url": None,
                "supports": (
                    f"{source.get('supports', '')} "
                    "(citation URL removed — not among the pages actually retrieved)"
                ).strip(),
            }
        cleaned.append(source)

    if dropped:
        result = {**result, "sources": cleaned}
    return result, dropped


# ---------- public-web guards ----------

def _registrable(host: str) -> str:
    return host.lower().removeprefix("www.")


def _is_blocked_domain(host: str) -> bool:
    host = _registrable(host)
    return any(host == d or host.endswith("." + d) for d in BLOCKED_DOMAINS)


def _public_ip(host: str) -> bool:
    """True only if every address the host resolves to is publicly routable."""
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        return False
    for info in infos:
        try:
            ip = ipaddress.ip_address(info[4][0])
        except ValueError:
            return False
        if (
            ip.is_private
            or ip.is_loopback
            or ip.is_link_local
            or ip.is_reserved
            or ip.is_multicast
            or ip.is_unspecified
        ):
            return False
    return True


def check_public_url(url: str) -> str | None:
    """Return None if the URL is safe to fetch, else the reason it isn't."""
    parsed = urlparse(url)
    if parsed.scheme not in _ALLOWED_SCHEMES:
        return f"scheme {parsed.scheme!r} is not http/https"
    if parsed.username or parsed.password:
        return "URL carries credentials"
    host = parsed.hostname
    if not host:
        return "URL has no host"
    try:
        if parsed.port not in _ALLOWED_PORTS:
            return f"port {parsed.port} is not a public web port"
    except ValueError:
        return "URL has an invalid port"
    if host.endswith((".local", ".internal", ".localdomain")) or host == "localhost":
        return "host is an internal name"
    if _is_blocked_domain(host):
        return "domain is paywalled or login-walled, so it is not publicly readable"
    if not _public_ip(host):
        return "host does not resolve to a public address"
    return None


# ---------- search providers ----------

async def _search_tavily(query: str, max_results: int) -> list[dict]:
    async with httpx.AsyncClient(timeout=SEARCH_TIMEOUT_SECONDS) as client:
        res = await client.post(
            "https://api.tavily.com/search",
            json={
                "api_key": TAVILY_API_KEY,
                "query": query,
                "max_results": max_results,
                "search_depth": "advanced",
            },
        )
        res.raise_for_status()
        return [
            {"title": r.get("title", ""), "url": r.get("url", ""), "snippet": r.get("content", "")}
            for r in res.json().get("results", [])
        ]


async def _search_brave(query: str, max_results: int) -> list[dict]:
    async with httpx.AsyncClient(timeout=SEARCH_TIMEOUT_SECONDS) as client:
        res = await client.get(
            "https://api.search.brave.com/res/v1/web/search",
            params={"q": query, "count": max_results},
            headers={"X-Subscription-Token": BRAVE_API_KEY, "Accept": "application/json"},
        )
        res.raise_for_status()
        return [
            {
                "title": r.get("title", ""),
                "url": r.get("url", ""),
                "snippet": re.sub(r"<[^>]+>", "", r.get("description", "")),
            }
            for r in res.json().get("web", {}).get("results", [])
        ]


def _search_ddg_sync(query: str, max_results: int) -> list[dict]:
    from ddgs import DDGS

    return [
        {"title": r.get("title", ""), "url": r.get("href", ""), "snippet": r.get("body", "")}
        for r in DDGS().text(query, max_results=max_results)
    ]


async def _search_ddg(query: str, max_results: int) -> list[dict]:
    return await asyncio.to_thread(_search_ddg_sync, query, max_results)


def active_provider() -> str:
    if TAVILY_API_KEY:
        return "tavily"
    if BRAVE_API_KEY:
        return "brave"
    return "duckduckgo"


async def _run_search(query: str, max_results: int) -> list[dict]:
    provider = active_provider()
    if provider == "tavily":
        return await _search_tavily(query, max_results)
    if provider == "brave":
        return await _search_brave(query, max_results)
    return await _search_ddg(query, max_results)


# ---------- HTML -> text ----------

class _TextExtractor(HTMLParser):
    """Minimal readable-text extractor — stdlib only, no parser dependency."""

    # Only tags that never carry readable content. Notably *not* <form>:
    # ASP.NET sites (pib.gov.in and much of gov.in) wrap the whole page body
    # in one, so skipping it would strip the entire article.
    _SKIP = {"script", "style", "noscript", "svg", "head"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self._depth = 0

    def handle_starttag(self, tag, attrs):
        if tag in self._SKIP:
            self._depth += 1

    def handle_endtag(self, tag):
        if tag in self._SKIP and self._depth:
            self._depth -= 1

    def handle_data(self, data):
        if self._depth == 0 and data.strip():
            self.parts.append(data.strip())


def _html_to_text(html: str) -> str:
    parser = _TextExtractor()
    try:
        parser.feed(html)
    except Exception:  # malformed markup — keep whatever was parsed
        pass
    return re.sub(r"\n{3,}", "\n\n", "\n".join(parser.parts))


# ---------- tools ----------

@tool
async def web_search(query: str, max_results: int = SEARCH_MAX_RESULTS) -> str:
    """Search the public web and return ranked results with real URLs.

    Use specific, source-oriented queries ("PIB press release PLI electronics
    outlay 2023") rather than broad ones. Returns numbered results with title,
    URL and snippet; cite the URLs you actually used.
    """
    max_results = max(1, min(int(max_results), 10))
    try:
        results = await _run_search(query, max_results)
    except Exception as exc:
        return f"Search failed ({type(exc).__name__}). Continue without it and say so in evidence_gaps."

    kept = [r for r in results if r.get("url") and not _is_blocked_domain(urlparse(r["url"]).hostname or "")]
    if not kept:
        return f"No public results for {query!r}. Try a different phrasing or a named source."

    lines = [f"Results for {query!r} (provider: {active_provider()}):"]
    for i, r in enumerate(kept, 1):
        _record(r["url"])
        lines.append(f"{i}. {r['title']}\n   URL: {r['url']}\n   {r['snippet'][:400]}")
    return "\n".join(lines)


@tool
async def fetch_page(url: str) -> str:
    """Fetch one public web page and return its readable text.

    Use after web_search to read a promising result in full — a ministry
    release, a PRS brief, an annual report page. Only public pages work:
    private hosts and paywalled domains are refused.
    """
    seen = url
    async with httpx.AsyncClient(
        timeout=FETCH_TIMEOUT_SECONDS,
        follow_redirects=False,
        headers={"User-Agent": HTTP_USER_AGENT},
    ) as client:
        for _ in range(_MAX_REDIRECTS + 1):
            reason = check_public_url(seen)
            if reason:
                return f"Refused to fetch {seen}: {reason}."
            try:
                res = await client.get(seen)
            except Exception as exc:
                return f"Could not fetch {seen} ({type(exc).__name__})."

            if res.is_redirect and (location := res.headers.get("location")):
                seen = str(httpx.URL(seen).join(location))
                continue

            if res.status_code >= 400:
                return f"{seen} returned HTTP {res.status_code}."

            content_type = res.headers.get("content-type", "")
            if not content_type.startswith(("text/html", "text/plain", "application/xhtml")):
                return f"{seen} is {content_type or 'an unknown type'}, not a readable web page."
            if len(res.content) > FETCH_MAX_BYTES:
                return f"{seen} is too large to read ({len(res.content)} bytes)."

            text = _html_to_text(res.text) if "html" in content_type else res.text
            if len(text) > FETCH_MAX_CHARS:
                text = text[:FETCH_MAX_CHARS] + "\n…[truncated]"
            # Record both the URL asked for and the one finally served, so a
            # citation of either form counts as genuinely retrieved.
            _record(url)
            _record(seen)
            return f"Fetched {seen}\n\n{text}"

    return f"Too many redirects from {url}."


RESEARCH_TOOLS = [web_search, fetch_page]
