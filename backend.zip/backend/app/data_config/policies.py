"""Policies shown on the landing page after login (GET /policies).

Each entry is a starting point the user can click straight into an
analysis for, without typing a query — this is real seeded content the
backend owns and serves, not a frontend mock.
"""

LANDING_POLICIES: list[dict] = [
    {
        "name": "Ethanol Blending Programme",
        "category": "Energy",
        "ministry": "Petroleum & Natural Gas",
        "enacted": 2003,
        "health": 74,
        "stat": "15% average blend rate achieved in 2025",
    },
    {
        "name": "FAME II — Electric Vehicles",
        "category": "Industrial",
        "ministry": "Heavy Industries",
        "enacted": 2019,
        "health": 68,
        "stat": "1.6M+ EVs subsidised; charging infra still the constraint",
    },
    {
        "name": "National Green Hydrogen Mission",
        "category": "Energy",
        "ministry": "New & Renewable Energy",
        "enacted": 2023,
        "health": 61,
        "stat": "₹19,744 Cr outlay; 5 MMT annual production target by 2030",
    },
    {
        "name": "PLI Scheme — Electronics",
        "category": "Industrial",
        "ministry": "Electronics & IT",
        "enacted": 2020,
        "health": 79,
        "stat": "Mobile exports crossed $15B; component ecosystem lagging",
    },
    {
        "name": "Jal Jeevan Mission",
        "category": "Social",
        "ministry": "Jal Shakti",
        "enacted": 2019,
        "health": 72,
        "stat": "75%+ rural households with tap water connections",
    },
    {
        "name": "National Education Policy 2020",
        "category": "Social",
        "ministry": "Education",
        "enacted": 2020,
        "health": 58,
        "stat": "Phased rollout; state-level adoption highly uneven",
    },
]
