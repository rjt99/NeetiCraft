"""Static reference data for the backend — content that's config, not user data.

Currently just the landing-page policy list (see policies.py); as more
seeded/reference data sets show up they belong here rather than inline in
route handlers.
"""
from .policies import LANDING_POLICIES

__all__ = ["LANDING_POLICIES"]
