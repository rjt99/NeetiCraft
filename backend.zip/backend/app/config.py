"""Centralized configuration for the Policy 360 backend.

Every value that is environment-dependent or might reasonably change
between deployments — paths, external API settings, auth parameters,
CORS origins, defaults — is defined here. Other modules import from this
file rather than reading os.environ or hardcoding these values directly.
"""
import json
import os
from pathlib import Path


OPENROUTER_API_KEY = "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"
OPENROUTER_MODEL = "nvidia/nemotron-nano-9b-v2:free"
# OPENROUTER_MODEL = "inclusionai/ling-3.0-flash:free"


OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"  # langchain_openai.ChatOpenAI wants the base, not the full endpoint
OPENROUTER_TIMEOUT_SECONDS = 90
AGENT_TEMPERATURE = 0.4

# Reasoning-capable free models (e.g. nemotron-nano) spend a large chunk of
# their output budget on hidden "reasoning" tokens before the real answer,
# and the runtime prompts (prompts/runtime/*.txt) now ask for full prose per
# field with no length caps — leave generous room so neither the reasoning
# trace nor the richer JSON answer gets truncated.
AGENT_MAX_TOKENS = 8192

# Agent output streamed to the UI is flushed into "lines" (newline, or this many
# characters, whichever comes first) — see run_pipeline() in app/agents.py.
STREAM_LINE_FLUSH_CHARS = 48

# ---------- web research (app/websearch.py) ----------

# Search provider, best first. Both are optional: with neither key set the
# tools fall back to keyless DuckDuckGo, so research works out of the box.
TAVILY_API_KEY = os.environ.get("TAVILY_API_KEY", "")
BRAVE_API_KEY = os.environ.get("BRAVE_SEARCH_API_KEY", "")

SEARCH_MAX_RESULTS = 6
SEARCH_TIMEOUT_SECONDS = 20
FETCH_TIMEOUT_SECONDS = 20
FETCH_MAX_BYTES = 2_000_000
FETCH_MAX_CHARS = 12_000
HTTP_USER_AGENT = "Policy360Research/0.3 (public-web policy research agent)"

# Publicly *reachable* but not publicly *readable*: paywalls and login walls.
# Citing these would point a reader at something they cannot open, so they're
# dropped from results and refused on fetch.
BLOCKED_DOMAINS = frozenset({
    "wsj.com", "ft.com", "economist.com", "nytimes.com", "bloomberg.com",
    "washingtonpost.com", "thehindubusinessline.com", "livemint.com",
    "jstor.org", "sciencedirect.com", "springer.com", "tandfonline.com",
    "scribd.com", "academia.edu", "researchgate.net",
    "facebook.com", "instagram.com", "twitter.com", "x.com", "linkedin.com",
    "quora.com", "pinterest.com", "reddit.com",
})

# ---------- paths ----------

BACKEND_ROOT = Path(__file__).resolve().parent.parent
DB_PATH = BACKEND_ROOT / "policy360.db"
DATABASE_URL = f"sqlite:///{DB_PATH}"
JOBS_ROOT = BACKEND_ROOT / "jobs"

# job folder layout (see app/job_store.py)
JOB_STATE_FILE = "state.json"
JOB_LOG_FILE = "job.log"  # single log file per job — every stage appends here
JOB_SUBDIRS = ("raw", "outputs", "report")

# Prompt text lives on disk, not in .py source — see prompts/runtime/*.txt
# and read_prompt() below. app/agents.py loads and $-substitutes these.
PROMPTS_DIR = BACKEND_ROOT / "prompts"
RUNTIME_PROMPTS_DIR = PROMPTS_DIR / "runtime"

# ---------- auth ----------

SECRET_KEY = os.environ.get("POLICY360_SECRET", "dev-secret-change-me")
JWT_ALGORITHM = "HS256"
TOKEN_TTL_HOURS = 12
PBKDF2_ITERATIONS = 200_000

DEFAULT_ADMIN_USERNAME = "admin"
DEFAULT_ADMIN_PASSWORD = "admin"

# ---------- CORS ----------

CORS_ALLOW_ORIGINS = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
]


def openrouter_api_key() -> str:
    return OPENROUTER_API_KEY


def read_prompt(filename: str) -> str:
    """Read a runtime prompt template from prompts/runtime/<filename>."""
    return (RUNTIME_PROMPTS_DIR / filename).read_text(encoding="utf-8").strip()


# ---------- selectable models (model_config.json) ----------

MODEL_CONFIG_FILE = BACKEND_ROOT / "model_config.json"


def load_model_config() -> dict:
    """The list of models the user can pick from, plus the default id.
    Shape: {"default": str, "models": [{"id","label","provider","note"}, ...]}.
    Falls back to the built-in OpenRouter model if the file is missing."""
    try:
        data = json.loads(MODEL_CONFIG_FILE.read_text(encoding="utf-8"))
        if data.get("models"):
            return data
    except (OSError, ValueError):
        pass
    return {
        "default": OPENROUTER_MODEL,
        "models": [
            {"id": OPENROUTER_MODEL, "label": OPENROUTER_MODEL, "provider": "openrouter"},
        ],
    }


def resolve_model_entry(model_id: str | None) -> dict:
    """Look up a model entry by id, falling back to the configured default."""
    config = load_model_config()
    models = config["models"]
    if model_id:
        for entry in models:
            if entry["id"] == model_id:
                return entry
    default_id = config.get("default")
    for entry in models:
        if entry["id"] == default_id:
            return entry
    return models[0]
