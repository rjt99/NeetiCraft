# Policy 360 Backend

FastAPI + SQLite backend with JWT authentication.

## Run

```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

Default credentials (seeded on first start): **admin / admin**

SQLite database file: `backend/policy360.db` (created automatically).

## Endpoints

| Method | Path | Auth | Purpose |
|---|---|---|---|
| POST | /auth/login | — | Login, returns JWT; records login time |
| GET | /auth/me | Bearer | Current user profile |
| GET | /auth/logins | Bearer | Login-time history (last 50) |
| GET | /workflows?category= | Bearer | List user's categorised workflows |
| POST | /workflows | Bearer | Create a workflow (name, category, payload JSON) |
| GET | /health | — | Health check |
| GET | /config | — | Runtime settings shown in the UI (currently `{"model": ...}`) |

## Database tables

- `users` — username, password hash (PBKDF2), role, created_at, last_login_at
- `login_events` — one row per successful login (user, timestamp, client)
- `workflows` — per-user categorised workflows (name, category, status, payload) for later phases
- `jobs` — one row per pipeline run: `job_id`, `user_id`, `policy_query`, `policy_name`, `category`, `status` (queued/running/completed/failed), `current_stage`, `folder_path`, `error_message`, timestamps

Set `POLICY360_SECRET` env var in production; default is a dev secret.

## Job storage layer

Every pipeline run is a **job**. SQLite (`jobs` table) holds only the small,
queryable facts — id, status, current stage, error message, timestamps.
Everything else lives on disk under `backend/jobs/<job_id>/`:

```
jobs/
  Job-14-32 03-08-2026/
    state.json        # live snapshot: status, current_stage, stages_completed
    job.log            # single log file — every stage appends here, tagged "[STAGE] message"
    outputs/           # one .json per stage's structured result
    raw/                # raw retrieved documents (future retrieval agents)
    report/report.json  # final assembled report
```

`job_id` format is `Job-<HH-MM> <DD-MM-YYYY>` in local server time (colon
swapped for a dash — Windows folder names can't contain `:`). If two jobs
start in the same minute, a `-2`, `-3`, ... suffix is appended.

All read/write logic lives in `app/job_store.py`. `POST /analysis/stream`
creates a job up front and the pipeline (`app/agents.py`) writes to it as
each stage completes.

| Method | Path | Purpose |
|---|---|---|
| GET | /jobs | List the current user's jobs |
| GET | /jobs/{job_id} | Job metadata + live state.json + file listing |
| GET | /jobs/{job_id}/log | The job's single log file, as plain text |
| GET | /jobs/{job_id}/outputs/{stage} | A single stage's structured output |
| GET | /jobs/{job_id}/report | The final assembled report |
| POST | /jobs/{job_id}/chat | Ask a question about this job's folder (see below) |

## Job chat agent (deepagents, filesystem-scoped)

`POST /jobs/{job_id}/chat` with `{"message": "...", "history": [{"role": "user"|"assistant", "content": "..."}]}`
returns `{"reply": "..."}`.

`app/chat_agent.py` builds a `deepagents.create_deep_agent` whose
`FilesystemBackend` is rooted at `jobs/<job_id>/`, so its `ls` / `read_file` /
`glob` / `grep` tools see that one run's artifacts and nothing else on the
host. Two guards, deliberately independent:

- `virtual_mode=True` anchors every path at the job folder and blocks `..`,
  `~` and absolute host paths — one job's chat cannot reach another's.
- `FilesystemPermission` denies all write operations, so an injected
  instruction inside a stage output can't get the agent to modify artifacts.

Ownership is checked against the caller before the agent is built. Retrieval
is plain filesystem browsing — **no RAG / embeddings / vector store yet**.
The system prompt lives in `prompts/runtime/chat.txt`. The server keeps no
chat state; the client sends the prior turns with each request.

## Agent pipeline (OpenRouter)

`POST /analysis/stream` (Bearer auth, body `{"policy": "..."}`) runs nine agents
in dependency order, each an OpenRouter chat completion, and streams Server-Sent
Events. The DAG:

```
Intake → Research → ┬→ Causality  ─┐
                    ├→ Impact ─────┼→ Forecast → ┬→ Stakeholders
                    └→ Comparators ┘             ├→ Alternatives
                                                 └→ Red-team
```

Each stage declares the upstream outputs it consumes (`Stage.needs` in
`app/agents.py`); that declaration drives prompt substitution and is validated
at import against the prompt templates, so a stage can never read context it
didn't declare or run before a dependency. Braced groups are independent and
could run concurrently — they're serial here because free-tier OpenRouter
models rate-limit hard on parallel requests.

Only **Research** carries tools: public-web search and page fetch (see below).
Every later stage reasons over the evidence it returned.

A stage whose output doesn't parse as JSON is retried once with a repair
instruction before the run is failed; the unparsed text is kept in
`jobs/<job_id>/raw/<stage>_unparsed.txt`.

SSE events:

- `{"type": "step_start", "agent": ...}`
- `{"type": "step_done", "agent": ..., "seconds": ..., "tokens": ...}`
- `{"type": "report", "report": {...}}` — full report consumed by the UI
- `{"type": "error", "message": ...}`

Completed runs are saved to the `workflows` table (name, category, payload).

Model configuration lives in `app/config.py` (`OPENROUTER_API_KEY`,
`OPENROUTER_MODEL`) — it is **not** read from the environment today, and the key
is currently committed in that file. `GET /config` exposes the active model name
to the UI.

## Web research (public sources only)

The Research agent has two tools, defined in `app/websearch.py`:

| Tool | Purpose |
|---|---|
| `web_search(query, max_results)` | Public-web search, returns real URLs |
| `fetch_page(url)` | Fetches one public page and extracts readable text |

Search provider, best first — both optional, keyless DuckDuckGo is the default
so research works with no configuration:

```bash
export TAVILY_API_KEY=tvly-...        # optional, preferred
export BRAVE_SEARCH_API_KEY=...       # optional, second choice
```

"Public websites only" is enforced in code, not asked for in the prompt:

- http/https on default ports, no credentials in the URL;
- every hostname is DNS-resolved and refused if any address is private,
  loopback, link-local, reserved or multicast — an SSRF guard, so the agent
  cannot be steered into reading this host's own services or anything else on
  the operator's network;
- redirects are followed one hop at a time so each destination is re-validated;
- paywalled / login-walled domains (`BLOCKED_DOMAINS` in `config.py`) are
  dropped from results and refused on fetch, since citing them would point a
  reader at something they cannot open.

The Research stage returns structured citations — `{title, publisher, url,
date, supports}` — where `url: null` explicitly marks a fact stated from model
knowledge rather than retrieved, and the UI labels those as "not retrieved"
rather than presenting them as sources.
