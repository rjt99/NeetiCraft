export const AGENT_SEQUENCE = [
  'Intake',
  'Research',
  'Causality',
  'Impact',
  'Comparators',
  'Conflict',
  'Implementation',
  'Budget',
  'Forecast',
  'Stakeholders',
  'Alternatives',
  'Red-team',
]

/** Defines parallel dependency groups */
export const AGENT_TIERS = [
  { id: 'tier-0', name: 'Statutory Ingestion', agents: ['Intake'] },
  { id: 'tier-1', name: 'Empirical Evidence Retrieval', agents: ['Research'] },
  {
    id: 'tier-2',
    name: 'Multi-Perspective Core Analysis (Parallel Execution)',
    parallel: true,
    agents: ['Causality', 'Impact', 'Comparators', 'Conflict', 'Implementation', 'Budget'],
  },
  { id: 'tier-3', name: 'Predictive Horizon Modeling', agents: ['Forecast'] },
  { id: 'tier-4', name: 'Stakeholder Landscape Mapping', agents: ['Stakeholders'] },
  { id: 'tier-5', name: 'Reform Alternatives Evaluation', agents: ['Alternatives'] },
  { id: 'tier-6', name: 'Adversarial Red-Team Stress-Test', agents: ['Red-team'] },
]

export interface StepState {
  name: string
  status: 'pending' | 'running' | 'done'
  seconds?: number
  tokens?: number
}
