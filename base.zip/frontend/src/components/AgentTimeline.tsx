import { useEffect, useRef } from 'react'
import { AGENT_TIERS, type StepState } from '../types'
import { CheckIcon } from './icons'

interface AgentTimelineProps {
  steps: StepState[]
  selectedAgent: string | null
  onSelect: (name: string) => void
}

function AgentTimeline({ steps, selectedAgent, onSelect }: AgentTimelineProps) {
  // Find running agents (could be multiple if parallel!)
  const runningAgents = steps.filter((step) => step.status === 'running').map((s) => s.name)
  const activeRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (runningAgents.length > 0) {
      activeRef.current?.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' })
    }
  }, [runningAgents])

  let globalStepCounter = 1

  return (
    <div className="agent-timeline">
      {AGENT_TIERS.map((tier) => {
        const isTierParallel = Boolean(tier.parallel && tier.agents.length > 1)
        const tierHasRunning = tier.agents.some((a) => runningAgents.includes(a))

        return (
          <div
            className={`timeline-tier-group ${isTierParallel ? 'parallel-tier' : ''} ${
              tierHasRunning ? 'has-running' : ''
            }`}
            key={tier.id}
            ref={tierHasRunning ? activeRef : undefined}
          >
            {isTierParallel && (
              <div className="parallel-tier-header">
                <span className="parallel-badge">⚡ PARALLEL TIER</span>
                <span className="parallel-name">{tier.name}</span>
              </div>
            )}
            <div className="tier-agents-row">
              {tier.agents.map((name) => {
                const step = steps.find((s) => s.name === name) ?? { name, status: 'pending' }
                const stepNum = globalStepCounter++

                return (
                  <div className="agent-timeline-item" key={step.name}>
                    <div className={`agent-dot ${step.status}`}>
                      <span className="agent-dot-num">{stepNum}</span>
                      {step.status === 'done' && (
                        <span className="agent-dot-tick" aria-label="done">
                          <CheckIcon />
                        </span>
                      )}
                    </div>
                    <button
                      type="button"
                      className={`pipeline-node ${step.status} ${
                        selectedAgent === step.name ? 'selected' : ''
                      }`}
                      disabled={step.status !== 'done'}
                      onClick={() => onSelect(step.name)}
                    >
                      <strong>{step.name}</strong>
                      {step.status === 'done' ? (
                        <span>
                          {step.seconds} sec • {step.tokens} tokens
                        </span>
                      ) : step.status === 'running' ? (
                        <span className="loading-bubbles" aria-label="Processing">
                          <i />
                          <i />
                          <i />
                        </span>
                      ) : (
                        <span>Pending</span>
                      )}
                    </button>
                  </div>
                )
              })}
            </div>
          </div>
        )
      })}
    </div>
  )
}

export default AgentTimeline
