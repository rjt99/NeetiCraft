import { useEffect, useRef, useState } from 'react'
import { ChevronIcon } from './icons'

export type StreamKind = 'llm' | 'tool_start' | 'tool_done' | 'system'

export interface StreamEntry {
  agent: string
  line: string
  kind?: StreamKind
  tool?: string
  input?: string
  result_summary?: string
}

interface SharedStreamBoxProps {
  lines: StreamEntry[]
}

function SharedStreamBox({ lines }: SharedStreamBoxProps) {
  const [collapsed, setCollapsed] = useState(false)
  const [filter, setFilter] = useState<'all' | 'tools' | 'llm'>('all')
  const boxRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (collapsed) return
    const el = boxRef.current
    if (el) el.scrollTop = el.scrollHeight
  }, [lines, collapsed, filter])

  const filteredLines = lines.filter((entry) => {
    if (filter === 'all') return true
    if (filter === 'tools') return entry.kind === 'tool_start' || entry.kind === 'tool_done'
    if (filter === 'llm') return !entry.kind || entry.kind === 'llm'
    return true
  })

  return (
    <div className={`collapse-box ${collapsed ? 'collapsed' : ''}`}>
      <div className="box-label-bar-container">
        <button
          type="button"
          className="box-label-bar"
          aria-expanded={!collapsed}
          onClick={() => setCollapsed((value) => !value)}
        >
          <span className="box-label">Live Reasoning & Execution Feed</span>
          <span className="box-label-meta">{lines.length} events</span>
          <ChevronIcon className="box-chevron" />
        </button>
        {!collapsed && (
          <div className="stream-filter-pills">
            <button
              type="button"
              className={`pill-btn ${filter === 'all' ? 'active' : ''}`}
              onClick={() => setFilter('all')}
            >
              All Events
            </button>
            <button
              type="button"
              className={`pill-btn tools ${filter === 'tools' ? 'active' : ''}`}
              onClick={() => setFilter('tools')}
            >
              🛠 Tools Only
            </button>
            <button
              type="button"
              className={`pill-btn llm ${filter === 'llm' ? 'active' : ''}`}
              onClick={() => setFilter('llm')}
            >
              🧠 LLM Reasoning
            </button>
          </div>
        )}
      </div>

      {!collapsed && (
        <div className="stream-display-box shared" ref={boxRef}>
          {filteredLines.length === 0 ? (
            <div className="stream-line stream-line-empty">Waiting for active reasoning and tool calls…</div>
          ) : (
            filteredLines.map((entry, index) => {
              if (entry.kind === 'tool_start') {
                return (
                  <div className="stream-line stream-tool-start" key={index}>
                    <span className="badge-stream tool">🛠 TOOL INVOKED</span>
                    <span className="stream-line-agent">{entry.agent}</span>
                    <span className="stream-tool-name">[{entry.tool}]</span>
                    <span className="stream-tool-detail">args: {entry.input}</span>
                  </div>
                )
              }
              if (entry.kind === 'tool_done') {
                return (
                  <div className="stream-line stream-tool-done" key={index}>
                    <span className="badge-stream success">✓ TOOL RESULT</span>
                    <span className="stream-line-agent">{entry.agent}</span>
                    <span className="stream-tool-name">[{entry.tool}]</span>
                    <span className="stream-tool-detail">{entry.result_summary}</span>
                  </div>
                )
              }
              return (
                <div className="stream-line stream-llm" key={index}>
                  <span className="badge-stream llm">🧠 LLM</span>
                  <span className="stream-line-agent">{entry.agent}</span>
                  <span className="stream-llm-text">{entry.line}</span>
                </div>
              )
            })
          )}
        </div>
      )}
    </div>
  )
}

export default SharedStreamBox
