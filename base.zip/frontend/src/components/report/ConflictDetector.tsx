import type { SchemeConflictReport } from '../../api'

interface ConflictDetectorProps {
  data?: SchemeConflictReport
}

function ConflictDetector({ data }: ConflictDetectorProps) {
  if (!data || !data.detectedConflicts || data.detectedConflicts.length === 0) {
    return (
      <div className="panel conflict-panel">
        <div className="panel-header">
          <h2>Cross-Scheme Policy Friction & Coherence</h2>
          <span className="badge success">Optimal Alignment</span>
        </div>
        <p className="conflict-empty">
          No systemic incentive distortions, statutory contradictions, or duplicate fiscal coverage
          detected with concurrent Central or State programs.
        </p>
      </div>
    )
  }

  const { detectedConflicts, coherenceScore = 80, summary } = data

  const getSeverityBadgeClass = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'high':
        return 'danger'
      case 'medium':
        return 'warning'
      default:
        return 'success'
    }
  }

  return (
    <div className="panel conflict-panel">
      <div className="panel-header">
        <div>
          <h2>Cross-Scheme Policy Friction & Coherence</h2>
          <span className="panel-subtitle">
            Systemic contradictions, perverse economic incentives, and overlapping beneficiary coverage
          </span>
        </div>
        <div className="coherence-score-badge">
          <span className="coherence-label">Coherence Index</span>
          <strong className="coherence-value">{coherenceScore}/100</strong>
        </div>
      </div>

      {summary && <div className="conflict-summary-callout">{summary}</div>}

      <div className="conflicts-grid">
        {detectedConflicts.map((c, idx) => (
          <div className={`conflict-card severity-${c.severity.toLowerCase()}`} key={idx}>
            <div className="conflict-card-head">
              <span className={`badge ${getSeverityBadgeClass(c.severity)}`}>
                {c.severity} Severity
              </span>
              <span className="conflict-type-tag">{c.conflict_type}</span>
            </div>
            <div className="conflict-scheme-title">
              <strong>Collision Target:</strong> {c.conflicting_scheme}
            </div>
            <div className="conflict-ministry">{c.ministry}</div>

            <div className="conflict-section">
              <span className="conflict-section-label">Operational Mechanism & Friction:</span>
              <p className="conflict-mechanism">{c.mechanism}</p>
            </div>

            {c.resolution && (
              <div className="conflict-section resolution">
                <span className="conflict-section-label">Convergence / Alignment Pathway:</span>
                <p className="conflict-resolution">{c.resolution}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

export default ConflictDetector
