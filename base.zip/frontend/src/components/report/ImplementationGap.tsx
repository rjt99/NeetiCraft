import type { ImplementationGapReport } from '../../api'

interface ImplementationGapProps {
  data?: ImplementationGapReport
}

function ImplementationGap({ data }: ImplementationGapProps) {
  if (!data) return null

  const {
    overallDeliveryScore = 50,
    failureBreakdown = { design_pct: 25, funding_pct: 25, delivery_pct: 25, awareness_pct: 25 },
    statePerformance = [],
    rootCauseDiagnosis,
  } = data

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'top':
        return 'positive'
      case 'middle':
        return 'warning'
      default:
        return 'danger'
    }
  }

  return (
    <div className="panel implementation-gap-panel">
      <div className="panel-header">
        <div>
          <h2>Implementation Gap & Delivery Saturation</h2>
          <span className="panel-subtitle">
            Ground-level operational breakdown across State units and institutional delivery tiers
          </span>
        </div>
        <div className="delivery-score-pill">
          <span className="delivery-pill-label">National Saturation</span>
          <strong className="delivery-pill-val">{overallDeliveryScore}/100</strong>
        </div>
      </div>

      <div className="failure-breakdown-section">
        <h3 className="subheading">Root Cause Decomposition of Execution Gap</h3>
        <div className="failure-meter-row">
          <div className="failure-metric-card design">
            <span className="failure-card-title">Design Flaw</span>
            <strong className="failure-card-pct">{failureBreakdown.design_pct ?? 0}%</strong>
            <p>Eligibility complexity & tech mandates</p>
          </div>
          <div className="failure-metric-card funding">
            <span className="failure-card-title">Fiscal Friction</span>
            <strong className="failure-card-pct">{failureBreakdown.funding_pct ?? 0}%</strong>
            <p>Center-State matching delays</p>
          </div>
          <div className="failure-metric-card delivery">
            <span className="failure-card-title">Delivery Deficit</span>
            <strong className="failure-card-pct">{failureBreakdown.delivery_pct ?? 0}%</strong>
            <p>Field manpower & administrative voids</p>
          </div>
          <div className="failure-metric-card awareness">
            <span className="failure-card-title">Information Asymmetry</span>
            <strong className="failure-card-pct">{failureBreakdown.awareness_pct ?? 0}%</strong>
            <p>Excluded eligible beneficiaries</p>
          </div>
        </div>
      </div>

      {statePerformance.length > 0 && (
        <div className="state-performance-section">
          <h3 className="subheading">State-by-State Implementation Asymmetry</h3>
          <div className="state-table-wrapper">
            <table className="state-performance-table">
              <thead>
                <tr>
                  <th>State / UT</th>
                  <th>Target Mandate</th>
                  <th>Ground Achieved</th>
                  <th>Execution Gap</th>
                  <th>Primary Constraint</th>
                  <th>Performance Tier</th>
                </tr>
              </thead>
              <tbody>
                {statePerformance.map((row, idx) => (
                  <tr key={idx}>
                    <td className="state-name-cell">
                      <span className={`status-indicator-dot ${getStatusColor(row.status)}`} />
                      <strong>{row.state}</strong>
                    </td>
                    <td>{row.target}</td>
                    <td>{row.achieved}</td>
                    <td className="gap-cell">{row.gap_pct}</td>
                    <td className="constraint-cell">{row.primary_failure}</td>
                    <td>
                      <span className={`badge ${getStatusColor(row.status)}`}>
                        {row.status.toUpperCase()}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {rootCauseDiagnosis && (
        <div className="diagnosis-box">
          <span className="diagnosis-label">Core Institutional Diagnosis:</span>
          <p>{rootCauseDiagnosis}</p>
        </div>
      )}
    </div>
  )
}

export default ImplementationGap
