import type { BudgetUtilizationReport } from '../../api'

interface BudgetUtilizationProps {
  data?: BudgetUtilizationReport
}

function BudgetUtilization({ data }: BudgetUtilizationProps) {
  if (!data) return null

  const {
    fiscalYear = 'FY 2024-25',
    allocatedCr = 0,
    spentCr = 0,
    utilizationPct = 0,
    unspentCr = 0,
    lapsingRisk = 'medium',
    lapsingSummary,
    historicalTrend = [],
    rootCause,
  } = data

  const getRiskBadgeClass = (risk: string) => {
    switch (risk.toLowerCase()) {
      case 'high':
        return 'danger'
      case 'medium':
        return 'warning'
      default:
        return 'success'
    }
  }

  return (
    <div className="panel budget-utilization-panel">
      <div className="panel-header">
        <div>
          <h2>Public Finance & Fiscal Absorption Audit</h2>
          <span className="panel-subtitle">
            Budget estimates vs actual expenditure, lapsing funds risk, and absorption velocity
          </span>
        </div>
        <div className="budget-year-pill">
          <span>{fiscalYear}</span>
        </div>
      </div>

      <div className="budget-summary-grid">
        <div className="budget-card">
          <span className="budget-card-label">Budget Allocation</span>
          <strong className="budget-card-num">₹{allocatedCr.toLocaleString()} Cr</strong>
          <small>Approved Outlay</small>
        </div>
        <div className="budget-card">
          <span className="budget-card-label">Actual Expenditure</span>
          <strong className="budget-card-num accent">₹{spentCr.toLocaleString()} Cr</strong>
          <small>Disbursed via PFMS</small>
        </div>
        <div className="budget-card">
          <span className="budget-card-label">Unspent Balance</span>
          <strong className="budget-card-num warning">₹{unspentCr.toLocaleString()} Cr</strong>
          <small>At risk of parking</small>
        </div>
        <div className="budget-card">
          <span className="budget-card-label">Fiscal Lapsing Risk</span>
          <span className={`badge ${getRiskBadgeClass(lapsingRisk)} large`}>
            {lapsingRisk.toUpperCase()} RISK
          </span>
          <small>Consolidated Fund Return</small>
        </div>
      </div>

      <div className="budget-progress-section">
        <div className="budget-progress-header">
          <span>Overall Fiscal Absorption Rate</span>
          <strong>{utilizationPct}% Absorbed</strong>
        </div>
        <div className="budget-progress-track">
          <div
            className={`budget-progress-fill ${
              utilizationPct >= 75 ? 'good' : utilizationPct >= 45 ? 'fair' : 'critical'
            }`}
            style={{ width: `${Math.min(utilizationPct, 100)}%` }}
          />
        </div>
      </div>

      {historicalTrend.length > 0 && (
        <div className="historical-trend-section">
          <h3 className="subheading">Historical Multi-Year Absorption Cadence</h3>
          <div className="historical-trend-bars">
            {historicalTrend.map((t, idx) => (
              <div className="trend-bar-col" key={idx}>
                <div className="trend-bar-wrapper">
                  <div
                    className="trend-bar-fill"
                    style={{ height: `${Math.min(t.utilization_pct, 100)}%` }}
                  />
                </div>
                <span className="trend-year">{t.year}</span>
                <span className="trend-pct">{t.utilization_pct}%</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {lapsingSummary && (
        <div className="lapsing-alert-banner">
          <span className="alert-icon">⚠️</span>
          <div>
            <strong>Fiscal Year-End Lapsing Alert:</strong>
            <p>{lapsingSummary}</p>
          </div>
        </div>
      )}

      {rootCause && (
        <div className="budget-root-cause">
          <span className="root-cause-label">Fiscal Bottleneck Diagnosis:</span>
          <p>{rootCause}</p>
        </div>
      )}
    </div>
  )
}

export default BudgetUtilization
