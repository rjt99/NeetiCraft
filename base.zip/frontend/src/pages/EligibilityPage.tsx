import { useState } from 'react'
import { checkEligibility, type CitizenProfile, type SchemeMatch } from '../api'
import { useSession } from '../session'

const OCCUPATION_OPTIONS = [
  { value: 'farmer', label: 'Farmer / Cultivator' },
  { value: 'labour', label: 'Agricultural / Daily Wage Labour' },
  { value: 'artisan', label: 'Traditional Artisan / Craftsperson' },
  { value: 'street vendor', label: 'Street Vendor / Urban Hawker' },
  { value: 'entrepreneur', label: 'Small Business / MSME Entrepreneur' },
  { value: 'student', label: 'Student / Youth Aspirant' },
  { value: 'unemployed', label: 'Unemployed / Seeking Livelihood' },
  { value: 'other', label: 'Other Informal / Formal Worker' },
]

const CASTE_OPTIONS = [
  { value: 'general', label: 'General Category' },
  { value: 'obc', label: 'Other Backward Class (OBC)' },
  { value: 'sc', label: 'Scheduled Caste (SC)' },
  { value: 'st', label: 'Scheduled Tribe (ST)' },
  { value: 'ews', label: 'Economically Weaker Section (EWS)' },
]

function EligibilityPage() {
  const { user, onLogout } = useSession()

  const [profile, setProfile] = useState<CitizenProfile>({
    state: 'Maharashtra',
    district: '',
    occupation: 'farmer',
    annual_income: 120000,
    land_acres: 2.5,
    caste: 'general',
    gender: 'all',
    age: 32,
    has_bpl: true,
    has_disability: false,
  })

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [results, setResults] = useState<SchemeMatch[] | null>(null)
  const [expandedScheme, setExpandedScheme] = useState<string | null>(null)

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      const matches = await checkEligibility(profile, user.token)
      setResults(matches)
      if (matches.length > 0) {
        setExpandedScheme(matches[0].scheme_id)
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to evaluate eligibility'
      if (msg === 'unauthorized') {
        onLogout()
        return
      }
      setError(msg)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="eligibility-page">
      <div className="eligibility-header">
        <h1>Citizen Scheme Eligibility Diagnostic</h1>
        <p>
          Match your household, demographic, and agricultural parameters against statutory gates
          for all Indian Central and State welfare programs.
        </p>
      </div>

      <div className="eligibility-container">
        {/* Left Form Column */}
        <form className="eligibility-form-card" onSubmit={handleSearch}>
          <h2>Citizen & Household Profile</h2>

          <div className="form-group">
            <label htmlFor="state">State / Union Territory</label>
            <input
              id="state"
              type="text"
              value={profile.state}
              onChange={(e) => setProfile({ ...profile, state: e.target.value })}
              placeholder="e.g. Uttar Pradesh, Maharashtra"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="district">District (Optional)</label>
            <input
              id="district"
              type="text"
              value={profile.district || ''}
              onChange={(e) => setProfile({ ...profile, district: e.target.value })}
              placeholder="e.g. Gorakhpur, Varanasi"
            />
          </div>

          <div className="form-group">
            <label htmlFor="occupation">Primary Occupation</label>
            <select
              id="occupation"
              value={profile.occupation}
              onChange={(e) => setProfile({ ...profile, occupation: e.target.value })}
            >
              {OCCUPATION_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="income">Annual Household Income (₹)</label>
              <input
                id="income"
                type="number"
                value={profile.annual_income ?? ''}
                onChange={(e) =>
                  setProfile({
                    ...profile,
                    annual_income: e.target.value ? Number(e.target.value) : null,
                  })
                }
                placeholder="e.g. 150000"
              />
            </div>

            <div className="form-group">
              <label htmlFor="land">Landholding (Acres)</label>
              <input
                id="land"
                type="number"
                step="0.1"
                value={profile.land_acres ?? ''}
                onChange={(e) =>
                  setProfile({
                    ...profile,
                    land_acres: e.target.value ? Number(e.target.value) : null,
                  })
                }
                placeholder="e.g. 2.5 (0 if landless)"
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="caste">Social Category (Caste)</label>
              <select
                id="caste"
                value={profile.caste}
                onChange={(e) => setProfile({ ...profile, caste: e.target.value })}
              >
                {CASTE_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label htmlFor="gender">Gender</label>
              <select
                id="gender"
                value={profile.gender}
                onChange={(e) => setProfile({ ...profile, gender: e.target.value })}
              >
                <option value="all">Any / Prefer not to specify</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Transgender / Non-binary</option>
              </select>
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="age">Age</label>
              <input
                id="age"
                type="number"
                value={profile.age}
                onChange={(e) => setProfile({ ...profile, age: Number(e.target.value) })}
                required
              />
            </div>
            <div className="form-checkboxes">
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={profile.has_bpl}
                  onChange={(e) => setProfile({ ...profile, has_bpl: e.target.checked })}
                />
                Holds BPL / Ration Card
              </label>
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={profile.has_disability}
                  onChange={(e) => setProfile({ ...profile, has_disability: e.target.checked })}
                />
                Person with Disability (PwD)
              </label>
            </div>
          </div>

          <button type="submit" className="find-schemes-btn" disabled={loading}>
            {loading ? 'Evaluating National Eligibility Gates…' : 'Find My Schemes ⚡'}
          </button>
        </form>

        {/* Right Results Column */}
        <div className="eligibility-results-column">
          {error && <div className="analysis-error">{error}</div>}

          {!results && !loading && (
            <div className="empty-results-state">
              <div className="empty-icon">🏛️</div>
              <h3>Discover All Schemes You Qualify For</h3>
              <p>
                India has hundreds of welfare programs, but millions of eligible citizens miss out
                due to lack of unified criteria visibility. Complete your profile to audit your
                entitlements.
              </p>
            </div>
          )}

          {loading && (
            <div className="loading-results-state">
              <span className="loading-bubbles large">
                <i />
                <i />
                <i />
              </span>
              <p>Evaluating national statutory rules, caste quotas, and income caps…</p>
            </div>
          )}

          {results && (
            <div className="results-list">
              <div className="results-header-bar">
                <h3>Matched Statutory Entitlements</h3>
                <span className="badge success">{results.length} Schemes Verified</span>
              </div>

              {results.length === 0 ? (
                <div className="empty-results-state">
                  <p>No schemes matched this exact profile combination.</p>
                </div>
              ) : (
                results.map((scheme) => {
                  const isExpanded = expandedScheme === scheme.scheme_id

                  return (
                    <div
                      key={scheme.scheme_id}
                      className={`scheme-match-card ${isExpanded ? 'expanded' : ''}`}
                    >
                      <div
                        className="scheme-card-header"
                        onClick={() =>
                          setExpandedScheme(isExpanded ? null : scheme.scheme_id)
                        }
                      >
                        <div className="scheme-title-block">
                          <span className="scheme-category-badge">{scheme.category}</span>
                          <h4>{scheme.name}</h4>
                          <span className="scheme-ministry">{scheme.ministry}</span>
                        </div>
                        <div className="scheme-score-block">
                          <div className="fit-meter">
                            <span className="fit-score">{scheme.fit_score}%</span>
                            <span className="fit-label">Eligibility Fit</span>
                          </div>
                          <span className="expand-chevron">{isExpanded ? '▲' : '▼'}</span>
                        </div>
                      </div>

                      <div className="scheme-benefit-strip">
                        <span className="benefit-icon">🎁</span>
                        <div className="benefit-text">
                          <strong>Direct Entitlement:</strong> {scheme.benefit}
                        </div>
                      </div>

                      {isExpanded && (
                        <div className="scheme-expanded-details">
                          <div className="detail-section">
                            <h5>Why You Qualify:</h5>
                            <ul className="reasons-list">
                              {scheme.match_reasons.map((r, i) => (
                                <li key={i}>{r}</li>
                              ))}
                            </ul>
                          </div>

                          <div className="detail-section">
                            <h5>Official Application Pathway:</h5>
                            <ol className="steps-list">
                              {scheme.application_steps.map((s, i) => (
                                <li key={i}>{s}</li>
                              ))}
                            </ol>
                          </div>

                          {scheme.exclusions.length > 0 && (
                            <div className="detail-section exclusions">
                              <h5>Key Exclusions to Note:</h5>
                              <ul className="exclusions-list">
                                {scheme.exclusions.map((ex, i) => (
                                  <li key={i}>{ex}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )
                })
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default EligibilityPage
