# NeetiCraft — Feature Checklist

> **Key distinction:** An **Agent** = LLM backbone + reasoning loop (created via `create_agent`).  
> A **Tool** = A Python function decorated with `@tool` that an agent can *invoke* (e.g., `web_search`, `fetch_page`).  
> Never call a tool an "agent". The Research stage has *one agent* that uses *two tools*.

---

## ✅ Features Already Built

### Core Pipeline (Multi-Agent)
- [x] **Intake Agent** — Extracts policy metadata: name, ministry, enactment date, provisions, status
- [x] **Research Agent** — Uses `web_search` + `fetch_page` tools to retrieve public sources
- [x] **Causality Agent** — Reconstructs origin story, trigger events, deeper causal chain
- [x] **Impact Agent** — Scores economic, environmental, political, social impact (0–100 bars + traffic lights)
- [x] **Comparators Agent** — Benchmarks against global structural analogs
- [x] **Forecast Agent** — Generates optimistic/baseline/adverse scenario projections
- [x] **Stakeholders Agent** — Maps stakeholder landscape, positions, flashpoints
- [x] **Alternatives Agent** — Weighs policy reform options with feasibility scores
- [x] **Red-team Agent** — Stress-tests objections, weakness identification, robustness verdict

### Infrastructure
- [x] **SSE Streaming** — Token-by-token agent progress streamed to UI via Server-Sent Events
- [x] **Resumable Jobs** — Failed stages resume from cached outputs (not from scratch)
- [x] **Job Persistence** — SQLite-backed job history; stage outputs on disk under `jobs/<job_id>/`
- [x] **Citation Verification** — Fabricated URLs never retrieved by tools are auto-dropped
- [x] **Per-Job Chat Agent** — Ask follow-up questions scoped to a completed job's report files
- [x] **JWT Auth** — Login, role-based access (admin/analyst), login history
- [x] **Model Picker** — Switch between OpenRouter models or Claude per analysis run
- [x] **Transient Error Retry** — Rate limits and timeouts auto-retry with backoff + jitter

### Report Sections (Frontend)
- [x] Policy Anatomy panel
- [x] Policy Timeline (horizontal, visual)
- [x] Causal Story (surface rationale vs deeper cause chain)
- [x] Cause Flow (visual chain diagram)
- [x] Impact Bars (scored dimensions with traffic lights)
- [x] Impact Detail (per-dimension prose)
- [x] Health Breakdown (scored dimensions)
- [x] Curve Position (evaluative placement on historical curve)
- [x] Global Comparators (country-level benchmarks)
- [x] Structural Factors (demographic, geographic, market, political)
- [x] Forecast Curve (projection chart with confidence bands)
- [x] Scenario Matrix (optimistic/base/adverse)
- [x] Trigger Watchlist
- [x] Assumptions Register
- [x] Stakeholder Map
- [x] Alternatives Panel
- [x] Red Team objections
- [x] Related Policies (supports / depends on / in tension with / predecessor)
- [x] Key Facts + Sources + Conflicting Evidence + Evidence Gaps

---

## 🚧 Features In Development (This Sprint)

### Feature 1 — Scheme Eligibility Mapper
**Type:** New agent + new API endpoint + new page  
**What it does:** Given a citizen profile (state, income, land, caste, occupation, gender, age),
finds all central + state schemes they qualify for and shows exact application steps.

- [ ] Backend: `EligibilityAgent` — LLM agent that reasons over profile + policy corpus
- [ ] Backend: `scheme_lookup` tool — queries a structured eligibility database
- [ ] Backend: `POST /eligibility/check` endpoint (streamed)
- [ ] Backend: Eligibility data config (`backend/app/data_config/eligibility.py`)
- [ ] Frontend: `/eligibility` route + `EligibilityPage.tsx`
- [ ] Frontend: Profile intake form (state, income, land, caste, occupation, age, gender)
- [ ] Frontend: Results panel — matched schemes with eligibility reason + application steps
- [ ] CSS: Eligibility form styles, scheme match cards

### Feature 2 — Cross-Scheme Conflict Detector
**Type:** New agent (runs after Intake) + new report section  
**What it does:** For any analyzed policy, finds other schemes targeting the same population
with conflicting incentives or duplicate coverage.

- [ ] Backend: `ConflictAgent` — LLM agent consuming intake output + scheme corpus
- [ ] Backend: Prompt file `conflict.txt`
- [ ] Backend: Conflict output added to `_assemble_report()` in `agents.py`
- [ ] Backend: `conflict` stage added to `_STAGES` pipeline
- [ ] Frontend: `ConflictDetector.tsx` report panel
- [ ] Frontend: Conflict cards (conflict type badge, scheme pair, mechanism, severity)
- [ ] CSS: Conflict panel styles
- [ ] Types: `SchemeConflict` interface in `api.ts`

### Feature 3 — Implementation Gap Analyzer
**Type:** New agent + new report section + new data tools  
**What it does:** For any scheme, shows target vs actual achievement broken down by state,
clusters failures by type (design/funding/delivery/awareness).

- [ ] Backend: `ImplementationAgent` — LLM agent using web research tools for state-level data
- [ ] Backend: Prompt file `implementation.txt`
- [ ] Backend: Implementation output added to `_assemble_report()`
- [ ] Backend: `implementation` stage added to `_STAGES` pipeline (uses_tools=True)
- [ ] Frontend: `ImplementationGap.tsx` report panel
- [ ] Frontend: State performance table (sortable), failure-type clustering
- [ ] CSS: Implementation panel styles, state table styles
- [ ] Types: `ImplementationGap` interface in `api.ts`

### Feature 4 — Budget Utilization Intelligence
**Type:** New agent + new report section  
**What it does:** Tracks allocation vs expenditure vs physical progress, identifies chronic
under-utilisation and lapsing funds risk.

- [ ] Backend: `BudgetAgent` — LLM agent using web research tools for PFMS/budget data
- [ ] Backend: Prompt file `budget.txt`
- [ ] Backend: Budget output added to `_assemble_report()`
- [ ] Backend: `budget` stage added to `_STAGES` pipeline (uses_tools=True)
- [ ] Frontend: `BudgetUtilization.tsx` report panel
- [ ] Frontend: Utilization bars, lapsing risk indicator, year-over-year trend
- [ ] CSS: Budget panel styles, utilization bar styles
- [ ] Types: `BudgetData` interface in `api.ts`

---

## 🔭 Potential Downstream Features

### High Impact, Buildable Next
- [ ] **Beneficiary Journey Mapper** — Maps the citizen's actual experience of accessing a scheme
  (offices, documents, days, friction score) vs the designed process
- [ ] **Scheme Sunset Advisor** — Evaluates whether a scheme has achieved/failed its mandate
  and should be wound up, merged, or redesigned
- [ ] **Scheme Design Advisor** — Co-pilot for drafting new schemes; checks for duplication,
  surfaces global analogs, flags design risks before first draft
- [ ] **RTI Intelligence Layer** — Aggregates RTI filings on a scheme; reveals what agencies
  don't want known (refusal patterns) vs official performance claims

### Complex but Transformative
- [ ] **Regional Disparity Tracker** — Multi-scheme deprivation index: identifies districts in
  the bottom quartile across 5+ schemes simultaneously, with common root-cause diagnosis
- [ ] **Impact Attribution Engine** — When outcomes improve, which scheme gets credit?
  Causal attribution across concurrent multi-scheme, multi-year settings
- [ ] **Policy Coherence Score** — Does a state's scheme portfolio reinforce or undermine
  the central mandate? Coherence/redundancy/conflict scoring at the state level
- [ ] **Announcement-Delivery Lag Tracker** — Tracks announcement → first fund release →
  physical delivery → target completion; builds ministry-level lag profiles
- [ ] **Budget Optimization Advisor** — Given fixed resources, which schemes deliver the
  highest outcome per rupee? Cross-scheme ROI comparison
- [ ] **State-Level Adaptation Advisor** — How should a state customize a central scheme
  for its specific demographics, geography, and administrative capacity?

---

## Agent vs Tool Reference

| Name | Type | Purpose |
|---|---|---|
| `IntakeAgent` | **Agent** | LLM reasoning over policy identity and structure |
| `ResearchAgent` | **Agent** | LLM reasoning loop that invokes tools to gather evidence |
| `web_search` | **Tool** | Function: runs DuckDuckGo/Tavily/Brave search, returns results |
| `fetch_page` | **Tool** | Function: fetches and reads a public web page |
| `CausalityAgent` | **Agent** | LLM reasoning over intake + research to build causal chain |
| `ImpactAgent` | **Agent** | LLM reasoning over intake + research to score impact dimensions |
| `ComparatorsAgent` | **Agent** | LLM reasoning over intake + research to find global analogs |
| `ForecastAgent` | **Agent** | LLM reasoning over all prior outputs to generate scenarios |
| `StakeholdersAgent` | **Agent** | LLM reasoning over intake + research + causality + impact |
| `AlternativesAgent` | **Agent** | LLM reasoning over all prior outputs to weigh reform options |
| `RedTeamAgent` | **Agent** | LLM reasoning over all prior outputs to stress-test objections |
| `ConflictAgent` *(new)* | **Agent** | LLM reasoning over intake to detect cross-scheme conflicts |
| `ImplementationAgent` *(new)* | **Agent** | LLM + tools to map state-level implementation gaps |
| `BudgetAgent` *(new)* | **Agent** | LLM + tools to analyze budget utilization vs targets |
| `EligibilityAgent` *(new)* | **Agent** | LLM reasoning over profile + scheme corpus for eligibility |
| `scheme_lookup` *(new)* | **Tool** | Function: queries structured eligibility criteria database |
| `ChatAgent` | **Agent** | LLM reasoning scoped to one job's output files |
