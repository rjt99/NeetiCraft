"""National Schemes & Eligibility Rules Database for India.

Contains authoritative structured metadata, criteria rules, target demographics,
and application pathways for Centrally Sponsored and Central Sector Schemes.
"""
from typing import Any

SCHEMES_DB: list[dict[str, Any]] = [
    {
        "id": "pm-kisan",
        "name": "PM-KISAN (Pradhan Mantri Kisan Samman Nidhi)",
        "ministry": "Ministry of Agriculture & Farmers Welfare",
        "category": "Agriculture",
        "benefit": "₹6,000 per year directly transferred in three equal 4-monthly installments into bank accounts.",
        "description": "Income support scheme for all landholding farmers' families having cultivable land holding in their names.",
        "target_occupations": ["farmer", "agriculturalist", "cultivator"],
        "max_income": None,  # no formal cap, but exclusions for income-tax payers/constitutional posts
        "max_land_acres": None,  # initially 2 hectares (5 acres), now covers all landholding sizes
        "target_gender": "all",
        "target_castes": ["all"],
        "min_age": 18,
        "application_steps": [
            "Visit PM-KISAN Portal (pmkisan.gov.in) or your local Common Service Centre (CSC).",
            "Select 'New Farmer Registration' and authenticate using your Aadhaar number and mobile OTP.",
            "Upload state land record (Khata/Khasra/ROR document) showing ownership.",
            "Submit bank account details linked to Aadhaar for Direct Benefit Transfer (DBT).",
            "Verification is carried out by District Agriculture Officer / Revenue Department."
        ],
        "exclusions": [
            "Institutional land holders",
            "Farmer families holding constitutional posts or retired/serving govt officers",
            "Income tax payers in last assessment year",
            "Professionals like Doctors, Engineers, Lawyers, CAs"
        ]
    },
    {
        "id": "ayushman-bharat",
        "name": "Ayushman Bharat - PMJAY (Pradhan Mantri Jan Arogya Yojana)",
        "ministry": "Ministry of Health & Family Welfare",
        "category": "Health & Social Protection",
        "benefit": "Cashless health coverage up to ₹5 Lakh per family per year for secondary and tertiary hospitalization.",
        "description": "World's largest government-funded healthcare assurance scheme targeting bottom 40% vulnerable population.",
        "target_occupations": ["labour", "informal worker", "unemployed", "farmer", "artisan", "domestic worker", "street vendor", "other"],
        "max_income": 250000,
        "max_land_acres": None,
        "target_gender": "all",
        "target_castes": ["all"],
        "min_age": 0,
        "requires_bpl_or_secc": True,
        "application_steps": [
            "Check eligibility on mera.pmjay.gov.in using Mobile Number or Ration Card Number.",
            "Visit nearest empaneled public/private hospital or CSC with Aadhaar and Ration Card.",
            "Ayushman Mitra executes biometric e-KYC on the portal.",
            "Receive Ayushman Golden Card instantly for cashless hospitalization across India."
        ],
        "exclusions": ["Households owning 3/4-wheeler motorized vehicles or mechanized 3/4-wheeler agricultural equipment", "Govt servants"]
    },
    {
        "id": "pm-awas-gramin",
        "name": "PMAY-G (Pradhan Mantri Awas Yojana - Gramin)",
        "ministry": "Ministry of Rural Development",
        "category": "Housing & Infrastructure",
        "benefit": "Financial assistance of ₹1.20 Lakh in plains and ₹1.30 Lakh in hilly/difficult states for construction of pucca house, plus 90-95 days of MGNREGA unskilled labour wages.",
        "description": "Provides pucca houses with basic amenities to all houseless households and households living in kutcha or dilapidated houses in rural areas.",
        "target_occupations": ["farmer", "labour", "artisan", "unemployed", "other"],
        "max_income": 180000,
        "max_land_acres": None,
        "target_gender": "all",
        "target_castes": ["all"],
        "min_age": 18,
        "requires_bpl_or_secc": True,
        "application_steps": [
            "Gram Sabha prioritizes eligible beneficiaries from permanent waiting list (SECC / Awas+).",
            "Geo-tagging of existing kutcha house by village Panchayat secretary.",
            "Beneficiary registers bank details and Aadhaar at Block Development Office.",
            "Funds released in 3 geo-tagged construction stages directly into Aadhaar-seeded bank account."
        ],
        "exclusions": ["Families owning pucca house anywhere in India", "Motorized vehicle owners", "Govt employees"]
    },
    {
        "id": "pm-mudra",
        "name": "PMMY (Pradhan Mantri MUDRA Yojana)",
        "ministry": "Ministry of Finance",
        "category": "Enterprise & Finance",
        "benefit": "Collateral-free institutional micro-credit up to ₹20 Lakh: Shishu (up to ₹50k), Kishore (₹50k-₹5L), Tarun (₹5L-₹10L), Tarun Plus (₹10L-₹20L).",
        "description": "Funds non-corporate, non-farm small/micro enterprises for manufacturing, trading, processing, and services.",
        "target_occupations": ["artisan", "trader", "shopkeeper", "entrepreneur", "informal worker", "unemployed", "other"],
        "max_income": None,
        "max_land_acres": None,
        "target_gender": "all",
        "target_castes": ["all"],
        "min_age": 18,
        "application_steps": [
            "Prepare a basic business plan, quotation for machinery, and proof of enterprise identity.",
            "Apply via Udyamimitra portal (udyamimitra.in) or visit any scheduled commercial bank/RRB/MFI.",
            "Submit KYC documents (Aadhaar, PAN, voter card) and proof of business premises.",
            "Sanction and disbursal without collateral within 14-21 working days directly into current account."
        ],
        "exclusions": ["Large corporate entities", "Defaulted borrowers from existing formal banks"]
    },
    {
        "id": "pm-vishwakarma",
        "name": "PM Vishwakarma Scheme",
        "ministry": "Ministry of Micro, Small and Medium Enterprises",
        "category": "Artisans & Crafts",
        "benefit": "Collateral-free enterprise loans up to ₹3 Lakh at 5% concessional interest rate, ₹15,000 tool-kit incentive, and skill stipend of ₹500/day during training.",
        "description": "Holistic support for traditional artisans and craftspersons working with hands and tools across 18 designated trades.",
        "target_occupations": ["artisan", "carpenter", "blacksmith", "potter", "weaver", "sculptor", "cobbler", "mason", "tailor", "barber"],
        "max_income": None,
        "max_land_acres": None,
        "target_gender": "all",
        "target_castes": ["all"],
        "min_age": 18,
        "application_steps": [
            "Visit nearest Common Service Centre (CSC) with Aadhaar and bank passbook.",
            "Select registered trade (carpenter, blacksmith, goldsmith, potter, mason, tailor, etc.).",
            "Three-stage verification: Gram Panchayat / ULB -> District Implementation Committee -> Screening Committee.",
            "Attend 5-7 days basic skill training at designated ITI/training center to receive e-Voucher and loan eligibility."
        ],
        "exclusions": ["Family members of regular government employees", "Availed PMEGP/PM-SVANidhi loans currently in default"]
    },
    {
        "id": "pm-svanidhi",
        "name": "PM SVANidhi (Street Vendor's AtmaNirbhar Nidhi)",
        "ministry": "Ministry of Housing & Urban Affairs",
        "category": "Urban Livelihoods",
        "benefit": "Working capital micro-loans starting at ₹10,000 (1st tranche), ₹20,000 (2nd tranche), up to ₹50,000 (3rd tranche) with 7% interest subsidy and cashback on digital transactions.",
        "description": "Special micro-credit facility empowering urban and peri-urban street vendors to resume livelihoods.",
        "target_occupations": ["street vendor", "hawker", "informal worker", "trader"],
        "max_income": None,
        "max_land_acres": None,
        "target_gender": "all",
        "target_castes": ["all"],
        "min_age": 18,
        "application_steps": [
            "Procure Certificate of Vending / ID card issued by Urban Local Body (ULB) / Town Vending Committee (TVC).",
            "Apply online via PMSVANidhi portal (pmsvanidhi.mohua.gov.in) or mobile app.",
            "Upload Aadhaar, bank details, and Letter of Recommendation (LoR) if TVC ID is pending.",
            "Instant sanction by participating public/private banks."
        ],
        "exclusions": ["Non-street vending businesses", "Rural residents vending outside notified municipal limits"]
    },
    {
        "id": "stand-up-india",
        "name": "Stand-Up India Scheme",
        "ministry": "Ministry of Finance",
        "category": "Enterprise & Affirmative Action",
        "benefit": "Bank loans between ₹10 Lakh and ₹1 Crore for setting up greenfield enterprises in manufacturing, services, agri-allied, or trading.",
        "description": "Promotes entrepreneurship among Women, Scheduled Caste (SC), and Scheduled Tribe (ST) communities.",
        "target_occupations": ["entrepreneur", "artisan", "trader", "other"],
        "max_income": None,
        "max_land_acres": None,
        "target_gender": "female",  # female OR SC/ST
        "target_castes": ["sc", "st"],
        "min_age": 18,
        "application_steps": [
            "Register on standupmitra.in portal.",
            "Submit Detailed Project Report (DPR) for a greenfield enterprise.",
            "Borrower equity must be at least 15% of project cost (or combined with state/central subsidies).",
            "Handholding support assigned via SIDBI / Lead District Manager (LDM) leading to formal branch appraisal."
        ],
        "exclusions": ["Existing running businesses (must be greenfield)", "Borrowers in default to any formal financial institution"]
    },
    {
        "id": "mgnrega",
        "name": "MGNREGA (Mahatma Gandhi National Rural Employment Guarantee)",
        "ministry": "Ministry of Rural Development",
        "category": "Social & Rural Employment",
        "benefit": "Legal guarantee of 100 days of unskilled wage employment per financial year to adult members of rural households.",
        "description": "Statutory social safety net ensuring livelihood security and rural durable community asset creation.",
        "target_occupations": ["labour", "farmer", "unemployed", "informal worker", "other"],
        "max_income": None,
        "max_land_acres": None,
        "target_gender": "all",
        "target_castes": ["all"],
        "min_age": 18,
        "application_steps": [
            "Submit application for Job Card to Gram Panchayat with photo, family names, and Aadhaar.",
            "Gram Panchayat issues Job Card within 15 days of application.",
            "Submit dated written application requesting work for minimum 14 consecutive days.",
            "Employment provided within 5 km radius within 15 days, or unemployment allowance is legally mandated."
        ],
        "exclusions": ["Urban residents", "Children under 18 years"]
    }
]


def match_schemes_for_citizen(profile: dict[str, Any]) -> list[dict[str, Any]]:
    """Evaluates citizen parameters against statutory eligibility gates."""
    matches = []
    
    user_state = str(profile.get("state", "")).strip().lower()
    user_occ = str(profile.get("occupation", "")).strip().lower()
    user_income = profile.get("annual_income")
    user_land = profile.get("land_acres")
    user_caste = str(profile.get("caste", "general")).strip().lower()
    user_gender = str(profile.get("gender", "all")).strip().lower()
    user_age = profile.get("age", 25)
    has_bpl = profile.get("has_bpl", False)
    has_disability = profile.get("has_disability", False)

    for scheme in SCHEMES_DB:
        match_score = 0
        reasons = []

        # 1. Age check
        if scheme["min_age"] and user_age and user_age < scheme["min_age"]:
            continue

        # 2. Occupation check
        target_occs = [o.lower() for o in scheme["target_occupations"]]
        if user_occ:
            if any(occ in user_occ for occ in target_occs) or "other" in target_occs:
                match_score += 30
                reasons.append(f"Occupation matches designated profile: {user_occ.capitalize()}")
            else:
                # If specific trade like PM Vishwakarma and user is not an artisan, continue
                if scheme["id"] in ["pm-vishwakarma", "pm-svanidhi"]:
                    continue

        # 3. Income check
        if scheme["max_income"] is not None:
            if user_income is not None and user_income <= scheme["max_income"]:
                match_score += 25
                reasons.append(f"Annual household income (₹{user_income:,}) within statutory cap (₹{scheme['max_income']:,})")
            elif user_income is not None and user_income > scheme["max_income"]:
                continue
        else:
            match_score += 15

        # 4. Land holding check
        if scheme["max_land_acres"] is not None:
            if user_land is not None and user_land <= scheme["max_land_acres"]:
                match_score += 20
                reasons.append(f"Land holding ({user_land} acres) qualifies within smallholder cap")
            elif user_land is not None and user_land > scheme["max_land_acres"]:
                continue
        elif user_occ in ["farmer", "agriculturalist"] and scheme["id"] == "pm-kisan":
            match_score += 25
            reasons.append("Landholding cultivator qualifies for direct DBT income support")

        # 5. Caste / Gender affirmative action check
        caste_match = False
        gender_match = False
        if "all" in scheme["target_castes"] or user_caste in scheme["target_castes"]:
            caste_match = True
        if scheme["target_gender"] == "all" or user_gender == scheme["target_gender"]:
            gender_match = True

        if scheme["id"] == "stand-up-india":
            # Requires female OR SC/ST
            if not (user_gender == "female" or user_caste in ["sc", "st"]):
                continue
            reasons.append(f"Qualifies under priority entrepreneurship framework ({'Women' if user_gender == 'female' else user_caste.upper()})")
            match_score += 30

        # 6. BPL card weighting
        if scheme.get("requires_bpl_or_secc") and has_bpl:
            match_score += 25
            reasons.append("BPL / Ration card holder prioritized for national welfare coverage")

        matches.append({
            "scheme_id": scheme["id"],
            "name": scheme["name"],
            "ministry": scheme["ministry"],
            "category": scheme["category"],
            "benefit": scheme["benefit"],
            "description": scheme["description"],
            "fit_score": min(match_score, 100),
            "match_reasons": reasons,
            "application_steps": scheme["application_steps"],
            "exclusions": scheme.get("exclusions", [])
        })

    matches.sort(key=lambda x: x["fit_score"], reverse=True)
    return matches
