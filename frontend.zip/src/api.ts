const API_BASE = import.meta.env.VITE_API_BASE ?? 'http://localhost:8000'

export interface AuthUser {
  username: string
  role: string
  token: string
}

const STORAGE_KEY = 'policy360_auth'

export function loadAuth(): AuthUser | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? (JSON.parse(raw) as AuthUser) : null
  } catch {
    return null
  }
}

export function saveAuth(user: AuthUser) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(user))
}

export function clearAuth() {
  localStorage.removeItem(STORAGE_KEY)
}

export async function login(username: string, password: string): Promise<AuthUser> {
  const res = await fetch(`${API_BASE}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
  })
  if (!res.ok) {
    const detail = await res.json().catch(() => null)
    throw new Error(detail?.detail ?? 'Login failed')
  }
  const data = await res.json()
  const user: AuthUser = { username: data.username, role: data.role, token: data.access_token }
  saveAuth(user)
  return user
}

export async function apiGet<T>(path: string, token: string): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { Authorization: `Bearer ${token}` },
  })
  if (res.status === 401) throw new Error('unauthorized')
  if (!res.ok) throw new Error(`Request failed: ${res.status}`)
  return res.json() as Promise<T>
}

// ---------- Server config (surfaced in the topbar) ----------

export interface ServerConfig {
  model: string
}

export async function getServerConfig(): Promise<ServerConfig> {
  const res = await fetch(`${API_BASE}/config`)
  if (!res.ok) throw new Error(`Request failed: ${res.status}`)
  return res.json() as Promise<ServerConfig>
}

// ---------- Selectable models (model_config.json) ----------

export interface ModelOption {
  id: string
  label: string
  provider: string
  note?: string
}

export interface ModelConfig {
  default: string
  models: ModelOption[]
}

export async function getModels(): Promise<ModelConfig> {
  const res = await fetch(`${API_BASE}/models`)
  if (!res.ok) throw new Error(`Request failed: ${res.status}`)
  return res.json() as Promise<ModelConfig>
}

const MODEL_KEY = 'policy360_model'

/** The model the user picked on the home page, applied to the next run. */
export function loadSelectedModel(): string {
  try {
    return localStorage.getItem(MODEL_KEY) ?? ''
  } catch {
    return ''
  }
}

export function saveSelectedModel(modelId: string) {
  try {
    localStorage.setItem(MODEL_KEY, modelId)
  } catch {
    // ignore storage errors — the run just falls back to the server default
  }
}

// ---------- Landing-page policy list ----------

export interface PolicyCardData {
  name: string
  category: string
  ministry: string
  enacted: number
  health: number
  stat: string
}

export async function getPolicies(token: string): Promise<PolicyCardData[]> {
  return apiGet<PolicyCardData[]>('/policies', token)
}

// ---------- Jobs history ----------

export interface JobSummary {
  job_id: string
  policy_query: string
  policy_name: string | null
  category: string | null
  status: string
  current_stage: string | null
  folder_path: string
  error_message: string | null
  created_at: string
  updated_at: string
}

export async function getJobs(token: string): Promise<JobSummary[]> {
  return apiGet<JobSummary[]>('/jobs', token)
}

export async function getJobReport(jobId: string, token: string): Promise<Report> {
  return apiGet<Report>(`/jobs/${jobId}/report`, token)
}

// ---------- Analysis stream ----------

export interface ReportPolicy {
  name: string
  category: string
  ministry: string
  documentReference?: string | null
  firstEnacted: number | null
  lastAmended: number | null
  status: string
  analysisDate: string
  depth: string
  horizon: string
  healthScore: number
  healthLabel: string
  summary: string
  coreObjectives?: string[]
  keyProvisions?: string[]
  administeringBodies?: string[]
  enforcementMechanism?: string
}

export interface CausalStory {
  surfaceRationale: string
  deeperCauseChain: string
  triggerEvents: string[]
  politicalContext: string
  stakeholderPressures: string[]
  priorAttempts: string[]
  confidence: string
}

/** A citation from the Research stage. `url` is the public page the agent
 *  actually retrieved; null means the fact came from the model's own
 *  knowledge rather than a source, and the UI must not imply otherwise.
 *  Reports produced before citations existed carry plain strings. */
export interface SourceRef {
  title: string
  publisher?: string
  url?: string | null
  date?: string | null
  supports?: string
}

export type ReportSource = string | SourceRef

export interface HealthDimension {
  dimension: string
  score: number
  rationale: string
}

export type TrafficState = 'performing' | 'mixed' | 'underperforming'

export interface CurvePosition {
  phase?: string
  maturityPct?: number
  momentum?: string
  nearestAnalog?: string
  similarityPct?: number
  inflectionAhead?: string
  inflectionTrigger?: string
}

export interface ProjectionPoint {
  year: number
  base: number
  low: number
  high: number
}

export interface Projection {
  metric?: string
  unit?: string
  points?: ProjectionPoint[]
}

export interface Scenario {
  conditions: string
  outcome: string
  probability: string
}

export interface Comparator {
  country: string
  launchContext?: string
  indiaOverlap?: string
  outcome: string
  shortfalls?: string
  unintendedConsequences?: string
  currentPosition?: string
  lesson: string
}

export interface RelatedPolicies {
  supports?: string[]
  dependsOn?: string[]
  inTensionWith?: string[]
  predecessor?: string[]
}

export interface StructuralFactors {
  demographic?: string
  geographic?: string
  market?: string
  political?: string
}

// ---- Deliberative layer (stakeholders / alternatives / red-team) ----

export type Sentiment = 'positive' | 'negative' | 'neutral'
export type Trend = 'up' | 'down' | 'flat'

/** A single attention-worthy figure, tagged with the sentiment it carries. */
export interface StatHighlight {
  value: string
  label: string
  sentiment?: Sentiment
  trend?: Trend
}

export interface Stakeholder {
  name: string
  category?: string
  stance: 'supportive' | 'opposed' | 'mixed' | 'neutral'
  influence: 'high' | 'medium' | 'low'
  interest?: string
  position?: string
  keyConcern?: string
  leverage?: string
  stakeStat?: StatHighlight | null
}

export interface StakeholderMap {
  stakeholders?: Stakeholder[]
  consensus?: string
  flashpoints?: string[]
  summary?: string
}

export interface Alternative {
  name: string
  approach?: string
  overlapWithCurrent?: string
  divergence?: string
  pros?: string[]
  cons?: string[]
  feasibility?: 'high' | 'medium' | 'low'
  estimatedCost?: string
  netAssessment?: 'favorable' | 'mixed' | 'unfavorable'
  keyStat?: StatHighlight | null
}

export interface Alternatives {
  options?: Alternative[]
  recommendedOption?: string
  recommendation?: string
}

export interface Objection {
  objection: string
  angle?: string
  severity: 'high' | 'medium' | 'low'
  evidence?: string
  counter?: string
  counterStrength?: 'strong' | 'moderate' | 'weak'
  residualRisk?: string
}

export interface RedTeam {
  objections?: Objection[]
  weakestPoint?: string
  robustness?: string
  verdict?: string
}

export interface Report {
  policy: ReportPolicy
  // Retrospective
  causeFlow: string[]
  timeline: { year: string; title: string }[]
  causalStory?: CausalStory
  // Evaluative
  impactBars: { label: string; value: number }[]
  impactDetail?: Record<string, string>
  /** Derived from impactBars on the server, not generated by the model. */
  trafficLight?: Record<string, TrafficState>
  impactReasons?: Record<string, string>
  healthBreakdown?: HealthDimension[]
  curvePosition?: CurvePosition
  comparators: Comparator[]
  comparatorSynthesis?: string
  structuralFactors?: StructuralFactors
  // Predictive
  projection?: Projection
  scenarios?: { optimistic?: Scenario; baseCase?: Scenario; adverse?: Scenario }
  watchlist: { name: string; impact: string; note: string }[]
  assumptions?: string[]
  relatedPolicies?: RelatedPolicies
  // Deliberative (consultation)
  stakeholderMap?: StakeholderMap
  alternatives?: Alternatives
  redTeam?: RedTeam
  // Evidence
  keyFacts: string[]
  sources: ReportSource[]
  conflictingEvidence?: string[]
  evidenceGaps?: string[]
}

export type AnalysisEvent =
  | { type: 'job_created'; job_id: string }
  | { type: 'step_start'; agent: string }
  | {
      type: 'step_done'
      agent: string
      summary: string
      seconds: number
      tokens: number
      result: Record<string, unknown>
    }
  | { type: 'stream'; agent: string; line: string }
  | { type: 'report'; report: Report; job_id?: string }
  | { type: 'error'; message: string }

// ---------- Chat over a job's folder ----------

export interface ChatTurn {
  role: 'user' | 'assistant'
  content: string
}

/** Ask a question about one job. The server keeps no chat state, so the full
 *  prior transcript rides along with every request. */
export async function chatWithJob(
  jobId: string,
  message: string,
  history: ChatTurn[],
  token: string,
): Promise<string> {
  const res = await fetch(`${API_BASE}/jobs/${encodeURIComponent(jobId)}/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ message, history }),
  })
  if (res.status === 401) throw new Error('unauthorized')
  if (!res.ok) {
    const detail = await res.json().catch(() => null)
    throw new Error(detail?.detail ?? `Chat failed (${res.status})`)
  }
  const data = await res.json()
  return data.reply as string
}

// ---------- Analysis stream ----------

export interface StreamOptions {
  /** Model id to run this analysis on (from getModels). */
  model?: string
  /** Resume an existing job, reusing its completed stages (retry-from-failed). */
  resumeJobId?: string
}

export async function streamAnalysis(
  policy: string,
  token: string,
  onEvent: (event: AnalysisEvent) => void,
  signal?: AbortSignal,
  options: StreamOptions = {},
): Promise<void> {
  const res = await fetch(`${API_BASE}/analysis/stream`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      policy,
      ...(options.model ? { model: options.model } : {}),
      ...(options.resumeJobId ? { job_id: options.resumeJobId } : {}),
    }),
    signal,
  })
  if (res.status === 401) throw new Error('unauthorized')
  if (!res.ok || !res.body) throw new Error(`Analysis failed to start (${res.status})`)

  const reader = res.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''

  for (;;) {
    const { done, value } = await reader.read()
    if (done) break
    buffer += decoder.decode(value, { stream: true })

    const chunks = buffer.split('\n\n')
    buffer = chunks.pop() ?? ''
    for (const chunk of chunks) {
      const line = chunk.trim()
      if (!line.startsWith('data: ')) continue
      try {
        onEvent(JSON.parse(line.slice(6)) as AnalysisEvent)
      } catch {
        // ignore malformed chunk
      }
    }
  }
}
