import { useEffect, useRef, useState } from 'react'
import { loadSelectedModel, streamAnalysis, type Report } from '../api'
import type { StreamEntry } from '../components/SharedStreamBox'
import type { StepState } from '../types'

export interface AnalysisRun {
  /** Backend job id for this run, e.g. "Job-07-24 06-08-2026". Empty until
   *  the server has created the job and sent its `job_created` event. */
  jobId: string
  steps: StepState[]
  streamLines: StreamEntry[]
  agentResults: Record<string, Record<string, unknown>>
  report: Report | null
  error: string
  /** Tokens billed so far, summed across every stage that has finished. */
  totalTokens: number
  running: boolean
  /** True once the user has stopped the run (agents aborted). */
  stopped: boolean
  /** Retry from the agent that failed, reusing completed stages. */
  retry: () => void
  /** Re-run the whole pipeline from the first agent (a fresh job). */
  rerun: () => void
  /** Abort the in-flight run — stops the agents and the loading state. */
  stop: () => void
}

/** Own one policy analysis run: open the SSE stream, fold its events into
 *  state, and tear the stream down when the policy changes or the page
 *  unmounts. A 401 anywhere calls `onUnauthorized` instead of surfacing an
 *  error, so an expired token drops the user back to the login route. */
export function useAnalysisRun(
  policy: string,
  token: string,
  onUnauthorized: () => void,
): AnalysisRun {
  const [jobId, setJobId] = useState('')
  const [steps, setSteps] = useState<StepState[]>([])
  const [streamLines, setStreamLines] = useState<StreamEntry[]>([])
  const [agentResults, setAgentResults] = useState<Record<string, Record<string, unknown>>>({})
  const [report, setReport] = useState<Report | null>(null)
  const [error, setError] = useState('')
  const [stopped, setStopped] = useState(false)
  const [runNonce, setRunNonce] = useState(0)
  const abortRef = useRef<AbortController | null>(null)
  // Holds the job id to resume on the next run — set by retry(), cleared for a
  // from-scratch rerun() or a fresh policy navigation.
  const resumeJobIdRef = useRef<string | null>(null)
  const jobIdRef = useRef('')
  jobIdRef.current = jobId

  // `onUnauthorized` comes from the router layout and is a fresh closure on
  // every render — keep it in a ref so it can't retrigger the run.
  const unauthorizedRef = useRef(onUnauthorized)
  unauthorizedRef.current = onUnauthorized

  useEffect(() => {
    if (!policy || !token) return

    const controller = new AbortController()
    abortRef.current?.abort()
    abortRef.current = controller
    // Capture-and-clear the resume target so it applies to this run only.
    const resumeJobId = resumeJobIdRef.current
    resumeJobIdRef.current = null
    setJobId('')
    setSteps([])
    setStreamLines([])
    setAgentResults({})
    setReport(null)
    setError('')
    setStopped(false)

    streamAnalysis(
      policy,
      token,
      (event) => {
        if (event.type === 'job_created') {
          setJobId(event.job_id)
        } else if (event.type === 'step_start') {
          setSteps((prev) => [...prev, { name: event.agent, status: 'running' }])
        } else if (event.type === 'stream') {
          setStreamLines((prev) => [...prev, { agent: event.agent, line: event.line }])
        } else if (event.type === 'step_done') {
          setSteps((prev) =>
            prev.map((step) =>
              step.name === event.agent
                ? { ...step, status: 'done', seconds: event.seconds, tokens: event.tokens }
                : step,
            ),
          )
          setAgentResults((prev) => ({ ...prev, [event.agent]: event.result }))
        } else if (event.type === 'report') {
          setReport(event.report)
          if (event.job_id) setJobId(event.job_id)
        } else if (event.type === 'error') {
          setError(event.message)
        }
      },
      controller.signal,
      { model: loadSelectedModel() || undefined, resumeJobId: resumeJobId || undefined },
    ).catch((err: unknown) => {
      if (controller.signal.aborted) return
      const message = err instanceof Error ? err.message : 'Analysis failed'
      if (message === 'unauthorized') {
        unauthorizedRef.current()
        return
      }
      setError(message)
    })

    return () => controller.abort()
  }, [policy, token, runNonce])

  return {
    jobId,
    steps,
    streamLines,
    agentResults,
    report,
    error,
    stopped,
    totalTokens: steps.reduce((sum, step) => sum + (step.tokens ?? 0), 0),
    running: Boolean(policy) && !report && !error && !stopped,
    // Retry from where it failed: resume the same job so completed stages are
    // replayed from cache and the run picks up at the failed agent.
    retry: () => {
      resumeJobIdRef.current = jobIdRef.current || null
      setRunNonce((n) => n + 1)
    },
    // Re-run the whole pipeline from the first agent in a fresh job.
    rerun: () => {
      resumeJobIdRef.current = null
      setRunNonce((n) => n + 1)
    },
    // Abort the in-flight stream: agents stop and every loading indicator
    // clears (the running step's spinner is reset, not left spinning).
    stop: () => {
      abortRef.current?.abort()
      setStopped(true)
      setSteps((prev) =>
        prev.map((step) => (step.status === 'running' ? { ...step, status: 'pending' } : step)),
      )
      setStreamLines((prev) => [...prev, { agent: 'system', line: 'Run stopped by user.' }])
    },
  }
}
