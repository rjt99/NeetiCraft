import { useEffect, useState } from 'react'
import { getServerConfig } from '../api'

/** The model the backend runs every agent stage on, from GET /config.
 *  Purely informational — a failure resolves to '' and the caller hides it. */
export function useServerModel(): string {
  const [model, setModel] = useState('')

  useEffect(() => {
    let cancelled = false
    getServerConfig()
      .then((config) => {
        if (!cancelled) setModel(config.model)
      })
      .catch(() => {})
    return () => {
      cancelled = true
    }
  }, [])

  return model
}
