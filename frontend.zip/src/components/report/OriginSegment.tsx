import type { CausalStory } from '../../api'

interface Props {
  causeFlow: string[]
  timeline: { year: string; title: string }[]
  story?: CausalStory
}

function OriginSegment({ causeFlow, timeline, story }: Props) {
  const hasChain = causeFlow.length > 0
  const hasTimeline = timeline.length > 0
  if (!hasChain && !hasTimeline && !story) return null

  const surfaceRationale = story?.surfaceRationale
  const deeperCauseChain = story?.deeperCauseChain
  const politicalContext = story?.politicalContext
  const confidence = story?.confidence
  const triggers = story?.triggerEvents ?? []
  const stakeholders = story?.stakeholderPressures ?? []
  const priors = story?.priorAttempts ?? []
  const hasContext = triggers.length > 0 || stakeholders.length > 0 || priors.length > 0

  return (
    <section className="panel wide">
      <div className="panel-header">
        <h2>Origin &amp; Causal Chain</h2>
        {confidence && (
          <span className={`badge confidence ${confidence.toLowerCase()}`}>{confidence} confidence</span>
        )}
      </div>

      {surfaceRationale && (
        <div className="story-block">
          <span className="story-label">Stated rationale</span>
          <p>{surfaceRationale}</p>
        </div>
      )}
      {deeperCauseChain && (
        <div className="story-block">
          <span className="story-label accent">The deeper cause chain</span>
          <p>{deeperCauseChain}</p>
        </div>
      )}

      <div className="origin-split">
        {hasChain && (
          <div className="origin-side">
            <span className="story-label">Causal chain</span>
            <ol className="cause-chain">
              {causeFlow.map((node, i) => {
                const first = i === 0
                const last = i === causeFlow.length - 1
                return (
                  <li className={`cause-step ${last ? 'final' : ''}`} key={`${i}-${node}`}>
                    <div className="cause-rail">
                      <span className="cause-index">{i + 1}</span>
                    </div>
                    <div className="cause-node">
                      {first && <span className="cause-tag">Root cause</span>}
                      {last && !first && <span className="cause-tag accent">Leads to this policy</span>}
                      <p>{node}</p>
                    </div>
                  </li>
                )
              })}
            </ol>
          </div>
        )}

        {hasTimeline && (
          <div className="origin-side">
            <span className="story-label">Policy timeline</span>
            <ol className="mini-timeline">
              {timeline.map((item, i) => (
                <li className="mini-milestone" key={`${item.year}-${i}`}>
                  <span className="mini-year">{item.year}</span>
                  <p>{item.title}</p>
                </li>
              ))}
            </ol>
          </div>
        )}
      </div>

      {hasContext && (
        <div className="story-cols origin-context">
          {triggers.length > 0 && (
            <div className="story-col">
              <span className="story-label">Trigger events</span>
              <ul className="chip-list">
                {triggers.map((t) => (
                  <li key={t}>{t}</li>
                ))}
              </ul>
            </div>
          )}
          {stakeholders.length > 0 && (
            <div className="story-col">
              <span className="story-label">Stakeholder pressures</span>
              <ul className="chip-list">
                {stakeholders.map((t) => (
                  <li key={t}>{t}</li>
                ))}
              </ul>
            </div>
          )}
          {priors.length > 0 && (
            <div className="story-col">
              <span className="story-label">What was tried before</span>
              <ul className="fact-list tight">
                {priors.map((t) => (
                  <li key={t}>{t}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {politicalContext && (
        <div className="story-block">
          <span className="story-label">Political context at passage</span>
          <p>{politicalContext}</p>
        </div>
      )}
    </section>
  )
}

export default OriginSegment
