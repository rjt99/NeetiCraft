import type { ReportPolicy } from '../../api'

function PolicyAnatomy({ policy }: { policy: ReportPolicy }) {
  return (
    <section className="panel wide">
      <div className="panel-header">
        <h2>Policy Anatomy</h2>
        <span className="badge">{policy.category}</span>
      </div>

      <div className="metric-grid">
        <div className="metric-card">
          <span>Ministry</span>
          <strong>{policy.ministry}</strong>
        </div>
        <div className="metric-card">
          <span>Status</span>
          <strong>{policy.status}</strong>
        </div>
        <div className="metric-card">
          <span>Enacted</span>
          <strong>{policy.firstEnacted ?? '—'}</strong>
        </div>
        <div className="metric-card">
          <span>Last amended</span>
          <strong>{policy.lastAmended ?? '—'}</strong>
        </div>
        <div className="metric-card">
          <span>Health</span>
          <strong>{policy.healthScore}/100</strong>
        </div>
      </div>

      {policy.summary && <p className="policy-summary">{policy.summary}</p>}

      <div className="anatomy-cols">
        {policy.coreObjectives && policy.coreObjectives.length > 0 && (
          <div className="anatomy-col">
            <span className="story-label">Core objectives</span>
            <ul className="fact-list tight">
              {policy.coreObjectives.map((o) => (
                <li key={o}>{o}</li>
              ))}
            </ul>
          </div>
        )}
        {policy.keyProvisions && policy.keyProvisions.length > 0 && (
          <div className="anatomy-col">
            <span className="story-label">Key provisions & targets</span>
            <ul className="fact-list tight">
              {policy.keyProvisions.map((p) => (
                <li key={p}>{p}</li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {(policy.enforcementMechanism || policy.documentReference) && (
        <div className="anatomy-foot">
          {policy.documentReference && (
            <span>
              <b>Reference:</b> {policy.documentReference}
            </span>
          )}
          {policy.enforcementMechanism && (
            <span>
              <b>Enforcement:</b> {policy.enforcementMechanism}
            </span>
          )}
        </div>
      )}
    </section>
  )
}

export default PolicyAnatomy
