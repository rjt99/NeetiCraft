import type { CurvePosition as CurvePositionData } from '../../api'

const PHASES = ['Pre-inflection', 'Scaling', 'Maturity', 'Plateau', 'Decline']

function CurvePosition({ data }: { data?: CurvePositionData }) {
  if (!data || (!data.phase && data.maturityPct == null)) return null

  const maturity = Math.max(0, Math.min(100, data.maturityPct ?? 0))
  const similarity = Math.max(0, Math.min(100, data.similarityPct ?? 0))
  const activePhase = data.phase ? PHASES.findIndex((p) => p.toLowerCase() === data.phase!.toLowerCase()) : -1

  return (
    <section className="panel">
      <div className="panel-header">
        <h2>Position on the Curve</h2>
        <span className="badge accent">Evaluative</span>
      </div>

      <div className="curvepos-headline">
        <div className="curvepos-phase">{data.phase ?? '—'}</div>
        {data.momentum && <span className={`momentum ${data.momentum.toLowerCase()}`}>{data.momentum}</span>}
      </div>

      {/* phase track */}
      <div className="phase-track">
        {PHASES.map((p, i) => (
          <div key={p} className={`phase-step ${i === activePhase ? 'active' : ''} ${i < activePhase ? 'past' : ''}`}>
            <span>{p}</span>
          </div>
        ))}
      </div>

      {/* maturity meter */}
      <div className="meter-block">
        <div className="meter-label">
          <span>Maturity — launch to full scale</span>
          <strong>{maturity}%</strong>
        </div>
        <div className="meter"><i style={{ width: `${maturity}%` }} /></div>
      </div>

      {/* nearest analog + structural similarity */}
      {data.nearestAnalog && (
        <div className="meter-block">
          <div className="meter-label">
            <span>Closest historical analog</span>
            <strong>{similarity}% match</strong>
          </div>
          <div className="meter cyan"><i style={{ width: `${similarity}%` }} /></div>
          <p className="curvepos-analog">{data.nearestAnalog}</p>
        </div>
      )}

      {data.inflectionAhead && (
        <div className="inflection-note">
          <strong>Next inflection</strong>
          <p>{data.inflectionAhead}</p>
          {data.inflectionTrigger && <small>Trigger: {data.inflectionTrigger}</small>}
        </div>
      )}
    </section>
  )
}

export default CurvePosition
