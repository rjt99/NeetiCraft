import type {
  CurvePosition as CurvePositionData,
  HealthDimension,
  TrafficState,
} from '../../api'

const PHASES = ['Pre-inflection', 'Scaling', 'Maturity', 'Plateau', 'Decline']
const IMPACT_TONE: Record<TrafficState, string> = {
  performing: 'good',
  mixed: 'mixed',
  underperforming: 'bad',
}

function healthTone(score: number): string {
  if (score >= 7) return 'good'
  if (score >= 4) return 'mixed'
  return 'bad'
}

interface Props {
  bars: { label: string; value: number }[]
  reasons?: Record<string, string>
  trafficLight?: Record<string, TrafficState>
  curve?: CurvePositionData
  healthScore: number
  healthLabel: string
  breakdown?: HealthDimension[]
}

function EvaluativeSnapshot({
  bars,
  reasons,
  trafficLight,
  curve,
  healthScore,
  healthLabel,
  breakdown,
}: Props) {
  const maturity = Math.max(0, Math.min(100, curve?.maturityPct ?? 0))
  const similarity = Math.max(0, Math.min(100, curve?.similarityPct ?? 0))
  const activePhase = curve?.phase
    ? PHASES.findIndex((p) => p.toLowerCase() === curve.phase!.toLowerCase())
    : -1

  return (
    <section className="panel wide">
      <div className="panel-header">
        <h2>Where It Stands Today</h2>
        <span className="badge accent">Evaluative</span>
      </div>

      <div className="triptych">
        {/* ---- Part 1: Impact assessment ---- */}
        <div className="tript-col">
          <h3 className="tript-title">Impact Assessment</h3>
          <div className="impact-items">
            {bars.map((bar) => {
              const state = trafficLight?.[bar.label.toLowerCase()]
              const tone = state ? IMPACT_TONE[state] : 'base'
              const reason = reasons?.[bar.label.toLowerCase()]
              return (
                <div className="impact-item" key={bar.label}>
                  <div className="impact-item-head">
                    <span>{bar.label}</span>
                    <em>{bar.value}</em>
                  </div>
                  <div className={`meter ${tone}`}>
                    <i style={{ width: `${bar.value}%` }} />
                  </div>
                  {reason && <p className="impact-reason">{reason}</p>}
                </div>
              )
            })}
          </div>
        </div>

        {/* ---- Part 2: Position on the curve ---- */}
        <div className="tript-col">
          <h3 className="tript-title">Position on the Curve</h3>
          {curve && (curve.phase || curve.maturityPct != null) ? (
            <>
              <div className="curvepos-headline">
                <div className="curvepos-phase">{curve.phase ?? '—'}</div>
                {curve.momentum && (
                  <span className={`momentum ${curve.momentum.toLowerCase()}`}>{curve.momentum}</span>
                )}
              </div>
              <div className="phase-track">
                {PHASES.map((p, i) => (
                  <div
                    key={p}
                    className={`phase-step ${i === activePhase ? 'active' : ''} ${i < activePhase ? 'past' : ''}`}
                  >
                    <span>{p}</span>
                  </div>
                ))}
              </div>
              <div className="meter-block">
                <div className="meter-label">
                  <span>Maturity — launch to full scale</span>
                  <strong>{maturity}%</strong>
                </div>
                <div className="meter"><i style={{ width: `${maturity}%` }} /></div>
              </div>
              {curve.nearestAnalog && (
                <div className="meter-block">
                  <div className="meter-label">
                    <span>Closest analog</span>
                    <strong>{similarity}% match</strong>
                  </div>
                  <div className="meter cyan"><i style={{ width: `${similarity}%` }} /></div>
                  <p className="curvepos-analog">{curve.nearestAnalog}</p>
                </div>
              )}
              {curve.inflectionAhead && (
                <div className="inflection-note">
                  <strong>Next inflection</strong>
                  <p>{curve.inflectionAhead}</p>
                  {curve.inflectionTrigger && <small>Trigger: {curve.inflectionTrigger}</small>}
                </div>
              )}
            </>
          ) : (
            <p className="tript-empty">Positioning not available for this policy.</p>
          )}
        </div>

        {/* ---- Part 3: Health score ---- */}
        <div className="tript-col">
          <h3 className="tript-title">Health Score</h3>
          <div className="health-score-big">
            {healthScore}
            <span>/100</span>
          </div>
          {healthLabel && <p className="health-score-label">{healthLabel}</p>}
          {breakdown && breakdown.length > 0 && (
            <div className="health-list">
              {breakdown.map((d) => (
                <div className="health-row" key={d.dimension}>
                  <div className="health-row-head">
                    <span>{d.dimension}</span>
                    <strong className={healthTone(d.score)}>{d.score}/10</strong>
                  </div>
                  <div className={`meter ${healthTone(d.score)}`}>
                    <i style={{ width: `${d.score * 10}%` }} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  )
}

export default EvaluativeSnapshot
