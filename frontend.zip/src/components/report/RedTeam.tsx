import type { RedTeam as RedTeamData } from '../../api'
import { Pill, toneOf } from './Signals'

const SEVERITY_RANK: Record<string, number> = { high: 0, medium: 1, low: 2 }

function RedTeam({ data }: { data?: RedTeamData }) {
  const objections = data?.objections ?? []
  if (objections.length === 0) return null

  // Most severe objections first — that's where the consultation risk lives.
  const ordered = [...objections].sort(
    (a, b) => (SEVERITY_RANK[a.severity] ?? 3) - (SEVERITY_RANK[b.severity] ?? 3),
  )

  return (
    <section className="panel wide">
      <div className="panel-header">
        <h2>Objections & Red-Team</h2>
        {data?.robustness && <Pill tone={toneOf(data.robustness, 'warn')}>{data.robustness}</Pill>}
      </div>

      {data?.verdict && <p className="policy-summary">{data.verdict}</p>}

      {data?.weakestPoint && (
        <div className="weakest-callout">
          <span className="story-label attn-label">Weakest point</span>
          <p>{data.weakestPoint}</p>
        </div>
      )}

      <div className="objection-list">
        {ordered.map((o) => (
          <div className={`objection-card sev-${toneOf(o.severity)}`} key={o.objection}>
            <div className="obj-head">
              <strong>{o.objection}</strong>
              <Pill tone={toneOf(o.severity)}>{o.severity} severity</Pill>
            </div>
            {o.angle && <span className="obj-angle">Raised by: {o.angle}</span>}
            {o.evidence && <p className="obj-evidence"><b>Evidence:</b> {o.evidence}</p>}

            <div className="counter-block">
              <div className="counter-head">
                <span className="story-label">Counter</span>
                {o.counterStrength && <Pill tone={toneOf(o.counterStrength)}>{o.counterStrength}</Pill>}
              </div>
              {o.counter && <p>{o.counter}</p>}
              {o.residualRisk && <small className="residual"><b>Residual risk:</b> {o.residualRisk}</small>}
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

export default RedTeam
