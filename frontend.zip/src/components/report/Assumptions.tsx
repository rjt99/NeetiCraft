function Assumptions({ assumptions }: { assumptions?: string[] }) {
  if (!assumptions || assumptions.length === 0) return null

  return (
    <section className="panel">
      <div className="panel-header">
        <h2>Assumptions the Forecast Rests On</h2>
        <span className="badge">{assumptions.length}</span>
      </div>
      <ul className="assumption-list">
        {assumptions.map((a) => (
          <li key={a}>{a}</li>
        ))}
      </ul>
    </section>
  )
}

export default Assumptions
