function CauseFlow({ nodes }: { nodes: string[] }) {
  if (!nodes || nodes.length === 0) return null

  return (
    <section className="panel">
      <div className="panel-header">
        <h2>Cause Flow</h2>
        <span className="badge">Causal chain</span>
      </div>

      <ol className="cause-chain">
        {nodes.map((node, i) => {
          const first = i === 0
          const last = i === nodes.length - 1
          return (
            <li className={`cause-step ${last ? 'final' : ''}`} key={`${i}-${node}`}>
              <div className="cause-rail">
                <span className="cause-index">{i + 1}</span>
              </div>
              <div className="cause-node">
                {first && <span className="cause-tag">Root cause</span>}
                {last && !first && <span className="cause-tag accent">Leads to this policy</span>}
                <p>{node}</p>
              </div>
            </li>
          )
        })}
      </ol>
    </section>
  )
}

export default CauseFlow
