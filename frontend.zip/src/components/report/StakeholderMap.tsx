import type { StakeholderMap as StakeholderMapData } from '../../api'
import { Pill, StatCallout, toneOf } from './Signals'

const INFLUENCE_RANK: Record<string, number> = { high: 0, medium: 1, low: 2 }
const STANCE_RANK: Record<string, number> = { opposed: 0, mixed: 1, neutral: 2, supportive: 3 }

function StakeholderMap({ data }: { data?: StakeholderMapData }) {
  const list = data?.stakeholders ?? []
  if (list.length === 0) return null

  // Surface the highest-attention actors first: high influence, then opposition.
  const ordered = [...list].sort(
    (a, b) =>
      (INFLUENCE_RANK[a.influence] ?? 3) - (INFLUENCE_RANK[b.influence] ?? 3) ||
      (STANCE_RANK[a.stance] ?? 4) - (STANCE_RANK[b.stance] ?? 4),
  )

  return (
    <section className="panel wide">
      <div className="panel-header">
        <h2>Stakeholder Map</h2>
        {data?.consensus && <Pill tone={toneOf(data.consensus, 'warn')}>{data.consensus}</Pill>}
      </div>

      {data?.summary && <p className="policy-summary">{data.summary}</p>}

      {data?.flashpoints && data.flashpoints.length > 0 && (
        <div className="flashpoints">
          <span className="story-label attn-label">⚠ Flashpoints</span>
          <div className="flashpoint-chips">
            {data.flashpoints.map((f) => (
              <span className="flashpoint" key={f}>{f}</span>
            ))}
          </div>
        </div>
      )}

      <div className="stakeholder-grid">
        {ordered.map((s) => {
          const attention = s.influence === 'high' && s.stance === 'opposed'
          return (
            <div className={`stakeholder-card ${attention ? 'attention' : ''}`} key={s.name}>
              <div className="sh-head">
                <div className="sh-title">
                  <strong>{s.name}</strong>
                  {s.category && <span className="sh-category">{s.category}</span>}
                </div>
                <div className="sh-tags">
                  <Pill tone={toneOf(s.stance)}>{s.stance}</Pill>
                  <Pill tone={toneOf(s.influence)}>{s.influence} influence</Pill>
                </div>
              </div>

              {s.interest && (
                <p className="sh-line"><b>Wants:</b> {s.interest}</p>
              )}
              {s.keyConcern && (
                <p className="sh-line"><b>Concern:</b> {s.keyConcern}</p>
              )}
              {s.leverage && (
                <p className="sh-line"><b>Leverage:</b> {s.leverage}</p>
              )}

              <StatCallout stat={s.stakeStat} />
            </div>
          )
        })}
      </div>
    </section>
  )
}

export default StakeholderMap
