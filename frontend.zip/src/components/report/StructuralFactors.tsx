import type { StructuralFactors as StructuralFactorsData } from '../../api'

const FIELDS: { key: keyof StructuralFactorsData; label: string }[] = [
  { key: 'demographic', label: 'Demographic' },
  { key: 'geographic', label: 'Geographic' },
  { key: 'market', label: 'Market' },
  { key: 'political', label: 'Political' },
]

function StructuralFactors({ factors }: { factors?: StructuralFactorsData }) {
  if (!factors || !FIELDS.some(({ key }) => factors[key])) return null

  return (
    <section className="panel">
      <div className="panel-header">
        <h2>Structural Factors</h2>
        <span className="badge">India-specific</span>
      </div>
      <div className="factor-grid">
        {FIELDS.map(({ key, label }) =>
          factors[key] ? (
            <div className="factor-card" key={key}>
              <span>{label}</span>
              <p>{factors[key]}</p>
            </div>
          ) : null,
        )}
      </div>
    </section>
  )
}

export default StructuralFactors
