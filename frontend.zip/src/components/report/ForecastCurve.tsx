import type { Projection } from '../../api'

/**
 * The predictive curve — the report's headline output. Renders the base-case
 * trajectory as a line through a shaded confidence band (adverse low → optimistic
 * high). Pure SVG with a viewBox so it scales fluidly; no chart library.
 */
function ForecastCurve({ projection }: { projection?: Projection }) {
  const points = (projection?.points ?? []).slice().sort((a, b) => a.year - b.year)
  if (points.length < 2) return null

  const W = 720
  const H = 320
  const padL = 52
  const padR = 20
  const padT = 20
  const padB = 40

  const years = points.map((p) => p.year)
  const minYear = Math.min(...years)
  const maxYear = Math.max(...years)
  const lows = points.map((p) => p.low)
  const highs = points.map((p) => p.high)
  const rawMin = Math.min(...lows)
  const rawMax = Math.max(...highs)
  const span = rawMax - rawMin || 1
  const yMin = rawMin - span * 0.12
  const yMax = rawMax + span * 0.12

  const x = (year: number) =>
    maxYear === minYear
      ? padL
      : padL + ((year - minYear) / (maxYear - minYear)) * (W - padL - padR)
  const y = (val: number) => padT + (1 - (val - yMin) / (yMax - yMin)) * (H - padT - padB)

  const line = (key: 'base' | 'low' | 'high') =>
    points.map((p) => `${x(p.year)},${y(p[key])}`).join(' ')

  // Band polygon: high edge left→right, then low edge right→left
  const band =
    points.map((p) => `${x(p.year)},${y(p.high)}`).join(' ') +
    ' ' +
    points
      .slice()
      .reverse()
      .map((p) => `${x(p.year)},${y(p.low)}`)
      .join(' ')

  const yTicks = [yMin + span * 0.12, (yMin + yMax) / 2, yMax - span * 0.12]
  const fmt = (n: number) => (Math.abs(n) >= 100 ? Math.round(n) : Math.round(n * 10) / 10)
  const unit = projection?.unit ?? ''

  return (
    <section className="panel wide">
      <div className="panel-header">
        <h2>Predictive Curve</h2>
        <span className="badge accent">{projection?.metric ?? 'Projection'}{unit ? ` · ${unit}` : ''}</span>
      </div>

      <div className="curve-wrap">
        <svg className="forecast-curve" viewBox={`0 0 ${W} ${H}`} role="img" preserveAspectRatio="xMidYMid meet">
          <defs>
            <linearGradient id="curveStroke" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#3b6ff2" />
              <stop offset="55%" stopColor="#7d63ea" />
              <stop offset="100%" stopColor="#f2823c" />
            </linearGradient>
            <linearGradient id="curveBand" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#3b6ff2" stopOpacity="0.20" />
              <stop offset="100%" stopColor="#f2823c" stopOpacity="0.20" />
            </linearGradient>
          </defs>
          {/* horizontal gridlines + y labels */}
          {yTicks.map((t, i) => (
            <g key={i}>
              <line x1={padL} x2={W - padR} y1={y(t)} y2={y(t)} className="curve-grid" />
              <text x={padL - 8} y={y(t) + 3} className="curve-ylabel" textAnchor="end">
                {fmt(t)}
              </text>
            </g>
          ))}

          {/* confidence band */}
          <polygon points={band} className="curve-band" />
          {/* optimistic / adverse edges */}
          <polyline points={line('high')} className="curve-edge" />
          <polyline points={line('low')} className="curve-edge" />
          {/* base-case trajectory */}
          <polyline points={line('base')} className="curve-base" />

          {/* base-case markers + year labels */}
          {points.map((p) => (
            <g key={p.year}>
              <circle cx={x(p.year)} cy={y(p.base)} r={3.5} className="curve-dot" />
              <text x={x(p.year)} y={H - padB + 20} className="curve-xlabel" textAnchor="middle">
                {p.year}
              </text>
            </g>
          ))}
        </svg>
      </div>

      <div className="curve-legend">
        <span className="legend-item"><i className="swatch base" />Base case</span>
        <span className="legend-item"><i className="swatch band" />Confidence band (adverse–optimistic)</span>
      </div>
    </section>
  )
}

export default ForecastCurve
