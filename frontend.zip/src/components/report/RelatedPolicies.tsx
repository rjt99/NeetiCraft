import type { RelatedPolicies as RelatedPoliciesData } from '../../api'

const GROUPS: { key: keyof RelatedPoliciesData; label: string; tone: string }[] = [
  { key: 'supports', label: 'Supports', tone: 'good' },
  { key: 'dependsOn', label: 'Depends on', tone: 'cyan' },
  { key: 'inTensionWith', label: 'In tension with', tone: 'bad' },
  { key: 'predecessor', label: 'Predecessor', tone: 'muted' },
]

function RelatedPolicies({ related }: { related?: RelatedPoliciesData }) {
  if (!related || !GROUPS.some(({ key }) => related[key]?.length)) return null

  return (
    <section className="panel">
      <div className="panel-header">
        <h2>Related Policy Threads</h2>
        <span className="badge">Linkages</span>
      </div>
      <div className="related-groups">
        {GROUPS.map(({ key, label, tone }) => {
          const items = related[key]
          if (!items?.length) return null
          return (
            <div className="related-group" key={key}>
              <span className={`related-label ${tone}`}>{label}</span>
              <div className="related-chips">
                {items.map((item) => (
                  <span className={`policy-chip ${tone}`} key={item}>
                    {item}
                  </span>
                ))}
              </div>
            </div>
          )
        })}
      </div>
    </section>
  )
}

export default RelatedPolicies
