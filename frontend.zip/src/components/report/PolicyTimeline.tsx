function PolicyTimeline({ items }: { items: { year: string; title: string }[] }) {
  return (
    <section className="panel wide">
      <div className="panel-header">
        <h2>Policy Timeline</h2>
        <span className="badge">Milestones</span>
      </div>
      <div className="timeline">
        {items.map((item, index) => (
          <div className="timeline-item" key={`${item.year}-${item.title}`}>
            <div className="timeline-dot" />
            {index < items.length - 1 && <div className="timeline-line" />}
            <div className="timeline-card">
              <strong>{item.year}</strong>
              <p>{item.title}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

export default PolicyTimeline
