import type { HealthDimension } from '../../api'

function tone(score: number): string {
  if (score >= 7) return 'good'
  if (score >= 4) return 'mixed'
  return 'bad'
}

function HealthBreakdown({
  dimensions,
  score,
  label,
}: {
  dimensions?: HealthDimension[]
  score: number
  label: string
}) {
  if (!dimensions || dimensions.length === 0) return null

  return (
    <section className="panel">
      <div className="panel-header">
        <h2>Policy Health Score</h2>
        <span className="badge accent">{score}/100</span>
      </div>

      {label && <p className="policy-summary">{label}</p>}

      <div className="health-list">
        {dimensions.map((d) => (
          <div className="health-row" key={d.dimension}>
            <div className="health-row-head">
              <span>{d.dimension}</span>
              <strong className={tone(d.score)}>{d.score}/10</strong>
            </div>
            <div className={`meter ${tone(d.score)}`}><i style={{ width: `${d.score * 10}%` }} /></div>
            {d.rationale && <p className="health-rationale">{d.rationale}</p>}
          </div>
        ))}
      </div>
    </section>
  )
}

export default HealthBreakdown
