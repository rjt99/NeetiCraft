import type { ReactNode } from 'react'
import type { Report } from '../../api'
import Alternatives from './Alternatives'
import Assumptions from './Assumptions'
import EvaluativeSnapshot from './EvaluativeSnapshot'
import ForecastCurve from './ForecastCurve'
import GlobalComparators from './GlobalComparators'
import KeyFacts from './KeyFacts'
import OriginSegment from './OriginSegment'
import PolicyAnatomy from './PolicyAnatomy'
import RedTeam from './RedTeam'
import RelatedPolicies from './RelatedPolicies'
import ScenarioMatrix from './ScenarioMatrix'
import StakeholderMap from './StakeholderMap'
import StructuralFactors from './StructuralFactors'
import TriggerWatchlist from './TriggerWatchlist'

function ReportSection({
  eyebrow,
  title,
  subtitle,
  children,
}: {
  eyebrow: string
  title: string
  subtitle: string
  children: ReactNode
}) {
  return (
    <section className="report-section">
      <header className="report-section-head">
        <span className="report-eyebrow">{eyebrow}</span>
        <h2>{title}</h2>
        <p>{subtitle}</p>
      </header>
      <div className="content-grid">{children}</div>
    </section>
  )
}

function ReportView({ report }: { report: Report }) {
  return (
    <div className="report">
      <ReportSection
        eyebrow="01 · Retrospective"
        title="What caused this"
        subtitle="The upstream decisions, pressures and events that produced today's policy."
      >
        <PolicyAnatomy policy={report.policy} />
        <OriginSegment
          causeFlow={report.causeFlow}
          timeline={report.timeline}
          story={report.causalStory}
        />
        <StructuralFactors factors={report.structuralFactors} />
      </ReportSection>

      <ReportSection
        eyebrow="02 · Evaluative"
        title="Where it sits today"
        subtitle="The policy's current impact, its position on the adoption curve, and its overall health — side by side."
      >
        <EvaluativeSnapshot
          bars={report.impactBars}
          reasons={report.impactReasons}
          trafficLight={report.trafficLight}
          curve={report.curvePosition}
          healthScore={report.policy.healthScore}
          healthLabel={report.policy.healthLabel}
          breakdown={report.healthBreakdown}
        />
        <GlobalComparators items={report.comparators} synthesis={report.comparatorSynthesis} />
      </ReportSection>

      <ReportSection
        eyebrow="03 · Predictive"
        title="What typically follows"
        subtitle="The forward trajectory with a confidence band, scenarios, triggers and the assumptions beneath them."
      >
        <ForecastCurve projection={report.projection} />
        <ScenarioMatrix scenarios={report.scenarios} />
        <TriggerWatchlist items={report.watchlist} />
        <RelatedPolicies related={report.relatedPolicies} />
        <Assumptions assumptions={report.assumptions} />
      </ReportSection>

      <ReportSection
        eyebrow="04 · Deliberative"
        title="Stakes, options & scrutiny"
        subtitle="Who is affected and how hard they'll push, the credible alternatives, and where the policy is most vulnerable under attack."
      >
        <StakeholderMap data={report.stakeholderMap} />
        <Alternatives data={report.alternatives} />
        <RedTeam data={report.redTeam} />
      </ReportSection>

      <ReportSection
        eyebrow="Evidence"
        title="Grounding & sources"
        subtitle="The facts this analysis rests on, where accounts conflict, and what remains uncertain."
      >
        <KeyFacts
          facts={report.keyFacts}
          sources={report.sources}
          conflicts={report.conflictingEvidence}
          gaps={report.evidenceGaps}
        />
      </ReportSection>
    </div>
  )
}

export default ReportView
