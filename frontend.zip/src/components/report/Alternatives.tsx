import type { Alternatives as AlternativesData } from '../../api'
import { Pill, StatCallout, toneOf } from './Signals'

function Alternatives({ data }: { data?: AlternativesData }) {
  const options = data?.options ?? []
  if (options.length === 0) return null

  return (
    <section className="panel wide">
      <div className="panel-header">
        <h2>Policy Alternatives</h2>
        <span className="badge">{options.length} options</span>
      </div>

      {data?.recommendation && (
        <div className="recommendation-banner">
          <span className="story-label accent">Recommended</span>
          {data.recommendedOption && <strong>{data.recommendedOption}</strong>}
          <p>{data.recommendation}</p>
        </div>
      )}

      <div className="alt-grid">
        {options.map((o) => {
          const recommended =
            !!data?.recommendedOption &&
            o.name.toLowerCase() === data.recommendedOption.toLowerCase()
          return (
            <div className={`alt-card ${recommended ? 'recommended' : ''}`} key={o.name}>
              <div className="alt-head">
                <strong>{o.name}</strong>
                <div className="alt-tags">
                  {o.netAssessment && <Pill tone={toneOf(o.netAssessment)}>{o.netAssessment}</Pill>}
                  {o.feasibility && <Pill tone={toneOf(o.feasibility)}>{o.feasibility} feasibility</Pill>}
                </div>
              </div>

              {o.approach && <p className="alt-approach">{o.approach}</p>}

              {(o.overlapWithCurrent || o.divergence) && (
                <div className="alt-overlap">
                  {o.overlapWithCurrent && (
                    <p><b>Overlaps:</b> {o.overlapWithCurrent}</p>
                  )}
                  {o.divergence && (
                    <p><b>Diverges:</b> {o.divergence}</p>
                  )}
                </div>
              )}

              <div className="pros-cons">
                {o.pros && o.pros.length > 0 && (
                  <ul className="pros">
                    {o.pros.map((p) => <li key={p}>{p}</li>)}
                  </ul>
                )}
                {o.cons && o.cons.length > 0 && (
                  <ul className="cons">
                    {o.cons.map((c) => <li key={c}>{c}</li>)}
                  </ul>
                )}
              </div>

              <div className="alt-foot">
                {o.estimatedCost && <span className="alt-cost"><b>Cost:</b> {o.estimatedCost}</span>}
                <StatCallout stat={o.keyStat} />
              </div>
            </div>
          )
        })}
      </div>
    </section>
  )
}

export default Alternatives
