import type { TrafficState } from '../../api'

const TONE: Record<TrafficState, string> = {
  performing: 'good',
  mixed: 'mixed',
  underperforming: 'bad',
}

function ImpactBars({
  bars,
  trafficLight,
}: {
  bars: { label: string; value: number }[]
  trafficLight?: Record<string, TrafficState>
}) {
  return (
    <section className="panel">
      <div className="panel-header">
        <h2>Impact Assessment</h2>
        <span className="badge">4 dimensions</span>
      </div>
      <div className="bar-chart">
        {bars.map((bar) => {
          const state = trafficLight?.[bar.label.toLowerCase()]
          const tone = state ? TONE[state] : 'base'
          return (
            <div className="bar-row" key={bar.label}>
              <span>{bar.label}</span>
              <div className={`bar ${tone}`}>
                <i style={{ width: `${bar.value}%` }} />
              </div>
              <em className="bar-value">{bar.value}</em>
            </div>
          )
        })}
      </div>
    </section>
  )
}

export default ImpactBars
