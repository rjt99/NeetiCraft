import type { ReactNode } from 'react'
import type { StatHighlight, Trend } from '../../api'

/**
 * Shared emphasis primitives so positive/negative sentiment, trends, and
 * attention-worthy numbers read consistently across the deliberative panels.
 * Tone vocabulary: good (green) · bad (red) · warn (amber) · attn (orange,
 * "needs attention") · info (blue) · muted.
 */
export type Tone = 'good' | 'bad' | 'warn' | 'attn' | 'info' | 'muted'

const TONE: Record<string, Tone> = {
  // stance
  supportive: 'good', opposed: 'bad', mixed: 'warn', neutral: 'info',
  // influence / severity
  high: 'attn', medium: 'warn', low: 'muted',
  // counter strength / feasibility
  strong: 'good', moderate: 'warn', weak: 'bad',
  // net assessment
  favorable: 'good', unfavorable: 'bad',
  // robustness
  robust: 'good', defensible: 'warn', fragile: 'bad',
  // consensus
  'broad support': 'good', divided: 'warn', 'strong opposition': 'bad',
  // sentiment
  positive: 'good', negative: 'bad',
}

/** Map a raw enum value (stance, severity, sentiment, …) to a display tone. */
export function toneOf(value?: string, fallback: Tone = 'muted'): Tone {
  if (!value) return fallback
  return TONE[value.toLowerCase()] ?? fallback
}

export function Pill({ tone, children }: { tone: Tone; children: ReactNode }) {
  return <span className={`pill ${tone}`}>{children}</span>
}

/** Colored pill whose tone is derived from the value itself. */
export function ValuePill({ value, prefix }: { value?: string; prefix?: string }) {
  if (!value) return null
  return <Pill tone={toneOf(value)}>{prefix ? `${prefix} ` : ''}{value}</Pill>
}

function TrendArrow({ trend }: { trend?: Trend }) {
  if (!trend) return null
  const glyph = trend === 'up' ? '▲' : trend === 'down' ? '▼' : '▶'
  return <span className={`trend-arrow ${trend}`} aria-hidden>{glyph}</span>
}

/** A big, attention-drawing figure tagged by sentiment (+ optional trend). */
export function StatCallout({ stat }: { stat?: StatHighlight | null }) {
  if (!stat?.value) return null
  const tone = toneOf(stat.sentiment, 'attn')
  return (
    <div className={`stat-callout ${tone}`}>
      <strong className="stat-value">
        {stat.value}
        <TrendArrow trend={stat.trend} />
      </strong>
      {stat.label && <span className="stat-label">{stat.label}</span>}
    </div>
  )
}
