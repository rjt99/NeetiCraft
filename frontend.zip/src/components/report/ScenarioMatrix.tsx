import type { Scenario } from '../../api'

type Scenarios = { optimistic?: Scenario; baseCase?: Scenario; adverse?: Scenario }

const ORDER: { key: keyof Scenarios; label: string; tone: string }[] = [
  { key: 'optimistic', label: 'Optimistic', tone: 'good' },
  { key: 'baseCase', label: 'Base case', tone: 'base' },
  { key: 'adverse', label: 'Adverse', tone: 'bad' },
]

/** Pull the first number out of a probability string like "50% (…)" → 50. */
function pct(probability?: string): number | null {
  if (!probability) return null
  const m = probability.match(/(\d+(?:\.\d+)?)\s*%/)
  return m ? Number(m[1]) : null
}

function ScenarioMatrix({ scenarios }: { scenarios?: Scenarios }) {
  if (!scenarios || !ORDER.some(({ key }) => scenarios[key])) return null

  return (
    <section className="panel wide">
      <div className="panel-header">
        <h2>Forecast Scenarios</h2>
        <span className="badge">Probability-weighted</span>
      </div>

      <div className="scenario-grid">
        {ORDER.map(({ key, label, tone }) => {
          const s = scenarios[key]
          if (!s) return null
          const p = pct(s.probability)
          return (
            <div className={`scenario-card ${tone}`} key={key}>
              <div className="scenario-head">
                <strong>{label}</strong>
                {p != null && <span className="scenario-prob">{p}%</span>}
              </div>
              {p != null && (
                <div className={`meter ${tone}`}><i style={{ width: `${p}%` }} /></div>
              )}
              <p className="scenario-outcome">{s.outcome}</p>
              {s.conditions && <small className="scenario-cond">Requires: {s.conditions}</small>}
            </div>
          )
        })}
      </div>
    </section>
  )
}

export default ScenarioMatrix
