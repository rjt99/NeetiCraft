function TriggerWatchlist({ items }: { items: { name: string; impact: string; note: string }[] }) {
  return (
    <section className="panel">
      <div className="panel-header">
        <h2>Trigger Watchlist</h2>
        <span className="badge">Signals</span>
      </div>
      <div className="watchlist">
        {items.map((item) => (
          <div className="watch-card" key={item.name}>
            <div className="watch-head">
              <strong>{item.name}</strong>
              <span>{item.impact}</span>
            </div>
            <p>{item.note}</p>
          </div>
        ))}
      </div>
    </section>
  )
}

export default TriggerWatchlist
