import type { CausalStory as CausalStoryData } from '../../api'

function CausalStory({ story }: { story?: CausalStoryData }) {
  if (!story || (!story.deeperCauseChain && !story.surfaceRationale)) return null

  return (
    <section className="panel wide">
      <div className="panel-header">
        <h2>Origin Story</h2>
        {story.confidence && (
          <span className={`badge confidence ${story.confidence.toLowerCase()}`}>
            {story.confidence} confidence
          </span>
        )}
      </div>

      {story.surfaceRationale && (
        <div className="story-block">
          <span className="story-label">Stated rationale</span>
          <p>{story.surfaceRationale}</p>
        </div>
      )}

      {story.deeperCauseChain && (
        <div className="story-block">
          <span className="story-label accent">The deeper cause chain</span>
          <p>{story.deeperCauseChain}</p>
        </div>
      )}

      <div className="story-cols">
        {story.triggerEvents?.length > 0 && (
          <div className="story-col">
            <span className="story-label">Trigger events</span>
            <ul className="chip-list">
              {story.triggerEvents.map((t) => (
                <li key={t}>{t}</li>
              ))}
            </ul>
          </div>
        )}
        {story.priorAttempts?.length > 0 && (
          <div className="story-col">
            <span className="story-label">What was tried before</span>
            <ul className="fact-list tight">
              {story.priorAttempts.map((t) => (
                <li key={t}>{t}</li>
              ))}
            </ul>
          </div>
        )}
        {story.stakeholderPressures?.length > 0 && (
          <div className="story-col">
            <span className="story-label">Stakeholder pressures</span>
            <ul className="chip-list">
              {story.stakeholderPressures.map((t) => (
                <li key={t}>{t}</li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {story.politicalContext && (
        <div className="story-block">
          <span className="story-label">Political context at passage</span>
          <p>{story.politicalContext}</p>
        </div>
      )}
    </section>
  )
}

export default CausalStory
