import type { ReportSource, SourceRef } from '../../api'

/** Older reports stored sources as bare strings; newer ones carry a retrieved
 *  URL. Normalise both into one shape so a stored report never fails to render. */
function toRef(source: ReportSource): SourceRef {
  return typeof source === 'string' ? { title: source } : source
}

function SourceItem({ source }: { source: SourceRef }) {
  const meta = [source.publisher, source.date].filter(Boolean).join(' · ')

  return (
    <li>
      {source.url ? (
        <a href={source.url} target="_blank" rel="noopener noreferrer">
          {source.title}
        </a>
      ) : (
        // No URL means the agent stated this from its own knowledge rather
        // than retrieving it — label it instead of dressing it up as a source.
        <span className="source-unsourced">
          {source.title} <em>· not retrieved</em>
        </span>
      )}
      {meta && <span className="source-meta">{meta}</span>}
      {source.supports && <span className="source-supports">{source.supports}</span>}
    </li>
  )
}

function KeyFacts({
  facts,
  sources,
  conflicts,
  gaps,
}: {
  facts: string[]
  sources: ReportSource[]
  conflicts?: string[]
  gaps?: string[]
}) {
  if (facts.length === 0) return null

  const refs = sources.map(toRef)
  const retrieved = refs.filter((ref) => ref.url).length

  return (
    <section className="panel wide">
      <div className="panel-header">
        <h2>Evidence Base</h2>
        <span className="badge">
          {refs.length ? `${refs.length} sources · ${retrieved} retrieved` : 'Research'}
        </span>
      </div>

      <ul className="fact-list">
        {facts.map((fact) => (
          <li key={fact}>{fact}</li>
        ))}
      </ul>

      {refs.length > 0 && (
        <div className="source-block">
          <span className="story-label">Sources</span>
          <ul className="source-list">
            {refs.map((ref, index) => (
              <SourceItem key={`${ref.title}-${index}`} source={ref} />
            ))}
          </ul>
        </div>
      )}

      {(conflicts?.length || gaps?.length) ? (
        <div className="evidence-cols">
          {conflicts && conflicts.length > 0 && (
            <div className="evidence-col conflicts">
              <span className="story-label">Conflicting evidence</span>
              <ul className="fact-list tight">
                {conflicts.map((c) => (
                  <li key={c}>{c}</li>
                ))}
              </ul>
            </div>
          )}
          {gaps && gaps.length > 0 && (
            <div className="evidence-col gaps">
              <span className="story-label">Evidence gaps</span>
              <ul className="fact-list tight">
                {gaps.map((g) => (
                  <li key={g}>{g}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      ) : null}
    </section>
  )
}

export default KeyFacts
