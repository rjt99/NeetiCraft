import type { Comparator } from '../../api'

function GlobalComparators({ items, synthesis }: { items: Comparator[]; synthesis?: string }) {
  if (!items || items.length === 0) return null

  return (
    <section className="panel wide">
      <div className="panel-header">
        <h2>Global Comparators</h2>
        <span className="badge">{items.length} cases</span>
      </div>

      {synthesis && <p className="policy-summary">{synthesis}</p>}

      <div className="comparator-grid">
        {items.map((item) => (
          <div className="comparator-card" key={item.country}>
            <strong className="comparator-country">{item.country}</strong>
            <p className="comparator-outcome">{item.outcome}</p>

            {item.indiaOverlap && (
              <div className="comparator-overlap">
                <span className="overlap-label">Overlap with India</span>
                <p>{item.indiaOverlap}</p>
              </div>
            )}

            <dl className="comparator-detail">
              {item.launchContext && (
                <div>
                  <dt>Launch context</dt>
                  <dd>{item.launchContext}</dd>
                </div>
              )}
              {item.shortfalls && (
                <div>
                  <dt>Shortfalls</dt>
                  <dd>{item.shortfalls}</dd>
                </div>
              )}
              {item.unintendedConsequences && (
                <div>
                  <dt>Unintended consequences</dt>
                  <dd>{item.unintendedConsequences}</dd>
                </div>
              )}
              {item.currentPosition && (
                <div>
                  <dt>Where they are now</dt>
                  <dd>{item.currentPosition}</dd>
                </div>
              )}
            </dl>

            {item.lesson && <small className="comparator-lesson">Lesson for India: {item.lesson}</small>}
          </div>
        ))}
      </div>
    </section>
  )
}

export default GlobalComparators
