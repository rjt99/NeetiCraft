import type { PolicyCardData } from '../api'

interface PolicyCardProps {
  card: PolicyCardData
  onSelect: (name: string) => void
}

function PolicyCard({ card, onSelect }: PolicyCardProps) {
  return (
    <button type="button" className="flashcard" onClick={() => onSelect(card.name)}>
      <div className="flashcard-head">
        <span className="flashcard-category">{card.category}</span>
        <div className="flashcard-health">
          <span className="flashcard-health-value">{card.health}</span>
          <span className="flashcard-health-label">/100 health</span>
        </div>
      </div>
      <div className="flashcard-body">
        <strong>{card.name}</strong>
        <span className="flashcard-ministry">{card.ministry}</span>
      </div>
      <div className="flashcard-stat">
        <p>{card.stat}</p>
      </div>
      <div className="flashcard-foot">
        <span>Since {card.enacted}</span>
        <span className="flashcard-cta">Run analysis →</span>
      </div>
    </button>
  )
}

export default PolicyCard
