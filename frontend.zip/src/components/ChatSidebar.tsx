import { useEffect, useRef, useState } from 'react'
import { chatWithJob, type ChatTurn } from '../api'
import { CloseIcon, SendIcon } from './icons'

interface ChatSidebarProps {
  jobId: string
  token: string
  onClose: () => void
  onUnauthorized: () => void
}

/** Chat over one job's folder. Every question goes to the backend agent that
 *  can read jobs/<job_id>/ and nothing else, so answers are grounded in this
 *  run's own artifacts. The transcript lives here — the server is stateless
 *  and gets the prior turns with each request. */
function ChatSidebar({ jobId, token, onClose, onUnauthorized }: ChatSidebarProps) {
  const [turns, setTurns] = useState<ChatTurn[]>([])
  const [draft, setDraft] = useState('')
  const [sending, setSending] = useState(false)
  const [error, setError] = useState('')
  const logRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = logRef.current
    if (el) el.scrollTop = el.scrollHeight
  }, [turns, sending])

  const send = async () => {
    const message = draft.trim()
    if (!message || sending) return

    const history = turns
    setTurns([...history, { role: 'user', content: message }])
    setDraft('')
    setSending(true)
    setError('')

    try {
      const reply = await chatWithJob(jobId, message, history, token)
      setTurns((prev) => [...prev, { role: 'assistant', content: reply }])
    } catch (err) {
      const detail = err instanceof Error ? err.message : 'Chat failed'
      if (detail === 'unauthorized') {
        onUnauthorized()
        return
      }
      setError(detail)
    } finally {
      setSending(false)
    }
  }

  return (
    <aside className="chat-sidebar" aria-label="Chat about this job">
      <header className="chat-head">
        <div>
          <strong>Ask about this run</strong>
          <span className="chat-scope">{jobId}</span>
        </div>
        <button type="button" className="chat-close" onClick={onClose} aria-label="Close chat">
          <CloseIcon />
        </button>
      </header>

      <div className="chat-log" ref={logRef}>
        {turns.length === 0 && !sending && (
          <p className="chat-empty">
            Grounded in this job's folder only — its state, log, per-stage outputs and
            report. Try “what did the impact stage conclude?” or “which stage was
            slowest?”.
          </p>
        )}
        {turns.map((turn, index) => (
          <div className={`chat-turn ${turn.role}`} key={index}>
            {turn.content}
          </div>
        ))}
        {sending && (
          <div className="chat-turn assistant pending">
            <span className="loading-bubbles" aria-label="Thinking">
              <i />
              <i />
              <i />
            </span>
          </div>
        )}
      </div>

      {error && <div className="chat-error">{error}</div>}

      <div className="chat-composer">
        <textarea
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          placeholder="Ask about this job's files…"
          rows={2}
          onKeyDown={(event) => {
            // Enter sends, Shift+Enter is a newline.
            if (event.key === 'Enter' && !event.shiftKey) {
              event.preventDefault()
              void send()
            }
          }}
        />
        <button type="button" onClick={() => void send()} disabled={sending || !draft.trim()}>
          <SendIcon />
          Send
        </button>
      </div>
    </aside>
  )
}

export default ChatSidebar
