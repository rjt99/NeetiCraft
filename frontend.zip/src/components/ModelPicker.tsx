import { useEffect, useRef, useState } from 'react'
import type { ModelOption } from '../api'
import { ChevronIcon } from './icons'

interface ModelPickerProps {
  models: ModelOption[]
  value: string
  onChange: (id: string) => void
}

/** Custom dropdown so each row can show the model name on the left and its
 *  note faintly on the right — a native <select> can't style option internals. */
function ModelPicker({ models, value, onChange }: ModelPickerProps) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  const current = models.find((model) => model.id === value) ?? models[0]

  useEffect(() => {
    if (!open) return
    const onDocMouseDown = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) setOpen(false)
    }
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false)
    }
    document.addEventListener('mousedown', onDocMouseDown)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', onDocMouseDown)
      document.removeEventListener('keydown', onKey)
    }
  }, [open])

  if (models.length === 0) return null

  return (
    <div className="model-picker" ref={ref}>
      <span className="model-picker-label">Model</span>
      <div className="model-select">
        <button
          type="button"
          className="model-trigger"
          onClick={() => setOpen((isOpen) => !isOpen)}
          aria-haspopup="listbox"
          aria-expanded={open}
        >
          <span className="mp-name">{current?.label}</span>
          {current?.note && <span className="mp-note">{current.note}</span>}
          <ChevronIcon className={`mp-chevron ${open ? 'open' : ''}`} />
        </button>

        {open && (
          <ul className="model-menu" role="listbox">
            {models.map((model) => (
              <li key={model.id}>
                <button
                  type="button"
                  role="option"
                  aria-selected={model.id === value}
                  className={`model-option ${model.id === value ? 'selected' : ''}`}
                  onClick={() => {
                    onChange(model.id)
                    setOpen(false)
                  }}
                >
                  <span className="mp-name">{model.label}</span>
                  {model.note && <span className="mp-note">{model.note}</span>}
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}

export default ModelPicker
