import { useEffect, useRef, useState } from 'react'
import { ChevronIcon } from './icons'

export interface StreamEntry {
  agent: string
  line: string
}

interface SharedStreamBoxProps {
  lines: StreamEntry[]
}

function SharedStreamBox({ lines }: SharedStreamBoxProps) {
  const [collapsed, setCollapsed] = useState(false)
  const boxRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (collapsed) return
    const el = boxRef.current
    if (el) el.scrollTop = el.scrollHeight
  }, [lines, collapsed])

  return (
    <div className={`collapse-box ${collapsed ? 'collapsed' : ''}`}>
      <button
        type="button"
        className="box-label-bar"
        aria-expanded={!collapsed}
        onClick={() => setCollapsed((value) => !value)}
      >
        <span className="box-label">Activity Log</span>
        <span className="box-label-meta">{lines.length} lines</span>
        <ChevronIcon className="box-chevron" />
      </button>
      {!collapsed && (
        <div className="stream-display-box shared" ref={boxRef}>
          {lines.length === 0 ? (
            <div className="stream-line stream-line-empty">Waiting for output…</div>
          ) : (
            lines.map((entry, index) => (
              <div className="stream-line" key={index}>
                <span className="stream-line-agent">{entry.agent}</span>
                {entry.line}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  )
}

export default SharedStreamBox
