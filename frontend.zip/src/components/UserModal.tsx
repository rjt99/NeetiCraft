interface UserModalProps {
  username: string
  role: string
  onClose: () => void
  onSignOut: () => void
}

function UserModal({ username, role, onClose, onSignOut }: UserModalProps) {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-card" onClick={(event) => event.stopPropagation()}>
        <div className="modal-user">
          <span className="user-avatar large">{username.charAt(0).toUpperCase()}</span>
          <div>
            <strong>{username}</strong>
            <span className="modal-role">{role}</span>
          </div>
        </div>
        <button type="button" className="signout-btn" onClick={onSignOut}>Sign out</button>
      </div>
    </div>
  )
}

export default UserModal
