import { useEffect, useRef } from 'react'
import { AGENT_SEQUENCE, type StepState } from '../types'
import { CheckIcon } from './icons'

interface AgentTimelineProps {
  steps: StepState[]
  selectedAgent: string | null
  onSelect: (name: string) => void
}

function AgentTimeline({ steps, selectedAgent, onSelect }: AgentTimelineProps) {
  const agentTimeline: StepState[] = AGENT_SEQUENCE.map(
    (name) => steps.find((step) => step.name === name) ?? { name, status: 'pending' },
  )

  // Keep the agent that's currently processing in view as the pipeline advances
  // into the horizontally-scrolled region on the right.
  const runningName = agentTimeline.find((step) => step.status === 'running')?.name
  const activeRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!runningName) return
    activeRef.current?.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' })
  }, [runningName])

  return (
    <div className="agent-timeline">
      {agentTimeline.map((step, index) => (
        <div
          className="agent-timeline-item"
          key={step.name}
          ref={step.name === runningName ? activeRef : undefined}
        >
          <div className={`agent-dot ${step.status}`}>
            <span className="agent-dot-num">{index + 1}</span>
            {step.status === 'done' && (
              <span className="agent-dot-tick" aria-label="done">
                <CheckIcon />
              </span>
            )}
          </div>
          {index < agentTimeline.length - 1 && (
            <div className={`agent-timeline-line ${step.status === 'done' ? 'drawn' : ''}`} />
          )}
          <button
            type="button"
            className={`pipeline-node ${step.status} ${selectedAgent === step.name ? 'selected' : ''}`}
            disabled={step.status !== 'done'}
            onClick={() => onSelect(step.name)}
          >
            <strong>{step.name}</strong>
            {step.status === 'done' ? (
              <span>{step.seconds} sec • {step.tokens} tokens</span>
            ) : step.status === 'running' ? (
              <span className="loading-bubbles" aria-label="Processing">
                <i />
                <i />
                <i />
              </span>
            ) : (
              <span>Pending</span>
            )}
          </button>
        </div>
      ))}
    </div>
  )
}

export default AgentTimeline
