import { useState } from 'react'
import { Outlet, useLocation, useNavigate } from 'react-router-dom'
import type { Session } from '../session'
import { BackIcon } from './icons'
import Topbar from './Topbar'
import UserModal from './UserModal'

/** Chrome shared by every authenticated route: the topbar, the user modal,
 *  and the session handed down to the routed page via outlet context. */
function AppLayout({ user, onLogout }: Session) {
  const [showUserModal, setShowUserModal] = useState(false)
  const navigate = useNavigate()
  const location = useLocation()

  // A back control on every authenticated page except the home explorer
  // (login isn't rendered inside this layout, so it's excluded already).
  const showBack = location.pathname !== '/'

  return (
    <div className="app-shell">
      <Topbar username={user.username} onUserClick={() => setShowUserModal(true)} />

      {showUserModal && (
        <UserModal
          username={user.username}
          role={user.role}
          onClose={() => setShowUserModal(false)}
          onSignOut={onLogout}
        />
      )}

      {showBack && (
        <button type="button" className="back-link" onClick={() => navigate('/')}>
          <BackIcon />
          Back to home
        </button>
      )}

      <Outlet context={{ user, onLogout } satisfies Session} />
    </div>
  )
}

export default AppLayout
