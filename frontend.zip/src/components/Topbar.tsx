import { useEffect, useState } from 'react'
import { useMatch, useNavigate } from 'react-router-dom'
import { analysisPath } from '../session'
import { JobsIcon } from './icons'

interface TopbarProps {
  username: string
  onUserClick: () => void
}

function Topbar({ username, onUserClick }: TopbarProps) {
  const navigate = useNavigate()
  const match = useMatch('/analysis/:policy')
  const routePolicy = match?.params.policy ? decodeURIComponent(match.params.policy) : ''

  // The URL owns the policy being analysed; the input is a draft of the next
  // one, re-seeded whenever the route changes (including via back/forward).
  const [query, setQuery] = useState(routePolicy)
  useEffect(() => setQuery(routePolicy), [routePolicy])

  const submit = () => {
    const term = query.trim()
    if (term) navigate(analysisPath(term))
  }

  return (
    <header className="topbar">
      <button type="button" className="brand-block" onClick={() => navigate('/')}>
        <div className="brand-icon">P</div>
        <div>
          <div className="brand-name">Policy 360</div>
          <div className="brand-subtitle">Causal policy seek</div>
        </div>
      </button>

      <div className="topbar-search">
        <div className="search-bar">
          <svg className="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <circle cx="11" cy="11" r="7" />
            <line x1="16.5" y1="16.5" x2="21" y2="21" />
          </svg>
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search any policy..."
            onKeyDown={(event) => {
              if (event.key === 'Enter') submit()
            }}
          />
          <button type="button" onClick={submit}>Search</button>
        </div>
      </div>

      <button
        type="button"
        className="jobs-btn"
        onClick={() => navigate('/jobs')}
        title="Completed jobs"
        aria-label="Completed jobs"
      >
        <JobsIcon />
      </button>

      <button type="button" className="user-icon-block" onClick={onUserClick}>
        <span className="user-avatar">{username.charAt(0).toUpperCase()}</span>
      </button>
    </header>
  )
}

export default Topbar
