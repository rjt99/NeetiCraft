import { useState } from 'react'
import { ChevronIcon } from './icons'

interface AgentResultPanelProps {
  selectedAgent: string | null
  result: Record<string, unknown> | undefined
}

function AgentResultPanel({ selectedAgent, result }: AgentResultPanelProps) {
  const [collapsed, setCollapsed] = useState(false)

  return (
    <div className={`collapse-box ${collapsed ? 'collapsed' : ''}`}>
      <button
        type="button"
        className="box-label-bar"
        aria-expanded={!collapsed}
        onClick={() => setCollapsed((value) => !value)}
      >
        <span className="box-label">Agent Output</span>
        {selectedAgent && <span className="box-label-meta">{selectedAgent}</span>}
        <ChevronIcon className="box-chevron" />
      </button>
      {!collapsed && (
        <div className="agent-result-box">
          {selectedAgent && result ? (
            <>
              <div className="agent-result-title">{selectedAgent} output</div>
              <pre className="agent-result-json">{JSON.stringify(result, null, 2)}</pre>
            </>
          ) : (
            <div className="agent-result-empty">Select a completed agent above to view its output.</div>
          )}
        </div>
      )}
    </div>
  )
}

export default AgentResultPanel
