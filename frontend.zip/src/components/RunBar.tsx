import { ChatIcon, RetryIcon, StopIcon } from './icons'

interface RunBarProps {
  policyName: string
  jobId: string
  model: string
  agentCount: number
  agentsDone: number
  totalTokens: number
  chatOpen: boolean
  onToggleChat: () => void
  /** Present only on a live run — omitted on the read-only job view. */
  running?: boolean
  onStop?: () => void
  onRerun?: () => void
}

function RunFact({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="run-fact" title={`${label}: ${value}`}>
      <span className="run-fact-label">{label}</span>
      <span className={`run-fact-value ${mono ? 'mono' : ''}`}>{value}</span>
    </div>
  )
}

/** The run's identity strip, directly under the topbar: what is being
 *  analysed, which job folder and model it runs in, how far through the
 *  agent sequence it is, what it has cost so far — and the way into the
 *  chat over this job's artifacts. */
function RunBar({
  policyName,
  jobId,
  model,
  agentCount,
  agentsDone,
  totalTokens,
  chatOpen,
  onToggleChat,
  running,
  onStop,
  onRerun,
}: RunBarProps) {
  return (
    <div className="run-bar">
      <div className="run-bar-policy" title={policyName}>
        <span className="run-fact-label">Policy</span>
        <strong>{policyName}</strong>
      </div>

      <div className="run-bar-facts">
        <RunFact label="Job" value={jobId || 'starting…'} mono />
        <RunFact label="Model" value={model || '—'} mono />
        <RunFact label="Agents" value={`${agentsDone} / ${agentCount}`} />
        <div className="run-fact run-fact-tokens" title={`Tokens used so far: ${totalTokens}`}>
          <span className="run-fact-label">Tokens</span>
          <span className="run-fact-value accent">{totalTokens.toLocaleString()}</span>
        </div>
      </div>

      <div className="run-actions">
        <button
          type="button"
          className={`chat-toggle ${chatOpen ? 'active' : ''}`}
          onClick={onToggleChat}
          disabled={!jobId}
          aria-expanded={chatOpen}
          title={jobId ? `Chat with the files in ${jobId}` : 'Available once the job is created'}
        >
          <ChatIcon />
          Chat
        </button>

        {onStop && (
          <button
            type="button"
            className="run-action-btn stop"
            onClick={onStop}
            disabled={!running}
            title="Stop the running agents"
          >
            <StopIcon />
            Stop
          </button>
        )}

        {onRerun && (
          <button
            type="button"
            className="run-action-btn rerun"
            onClick={onRerun}
            title="Re-run the whole pipeline from the first agent"
          >
            <RetryIcon />
            Rerun
          </button>
        )}
      </div>
    </div>
  )
}

export default RunBar
