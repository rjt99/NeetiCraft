export const AGENT_SEQUENCE = [
  'Intake',
  'Research',
  'Causality',
  'Impact',
  'Comparators',
  'Forecast',
  'Stakeholders',
  'Alternatives',
  'Red-team',
]

export interface StepState {
  name: string
  status: 'pending' | 'running' | 'done'
  seconds?: number
  tokens?: number
}
