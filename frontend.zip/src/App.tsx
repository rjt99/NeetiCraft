import { useState } from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import './App.css'
import { clearAuth, loadAuth, type AuthUser } from './api'
import AppLayout from './components/AppLayout'
import AnalysisPage from './pages/AnalysisPage'
import HomePage from './pages/HomePage'
import JobReportPage from './pages/JobReportPage'
import JobsPage from './pages/JobsPage'
import LoginPage from './pages/LoginPage'

/** Routes:
 *    /login            sign in (redirects to / when already signed in)
 *    /                 policy explorer
 *    /analysis/:policy one analysis run, the policy carried in the URL
 *    /jobs             history of completed jobs
 *    /jobs/:jobId      stored report for one completed job
 *  Everything except /login sits behind the auth guard on the layout route. */
function App() {
  const [user, setUser] = useState<AuthUser | null>(() => loadAuth())

  const handleLogout = () => {
    clearAuth()
    setUser(null)
  }

  return (
    <Routes>
      <Route
        path="/login"
        element={user ? <Navigate to="/" replace /> : <LoginPage onLogin={setUser} />}
      />

      <Route
        element={
          user ? <AppLayout user={user} onLogout={handleLogout} /> : <Navigate to="/login" replace />
        }
      >
        <Route path="/" element={<HomePage />} />
        <Route path="/analysis/:policy" element={<AnalysisPage />} />
        <Route path="/jobs" element={<JobsPage />} />
        <Route path="/jobs/:jobId" element={<JobReportPage />} />
      </Route>

      <Route path="*" element={<Navigate to={user ? '/' : '/login'} replace />} />
    </Routes>
  )
}

export default App
