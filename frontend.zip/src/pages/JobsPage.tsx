import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getJobs, type JobSummary } from '../api'
import { ViewIcon } from '../components/icons'
import { useSession } from '../session'

function formatStarted(iso: string): string {
  const date = new Date(iso)
  if (Number.isNaN(date.getTime())) return iso
  return date.toLocaleString(undefined, {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  })
}

function JobsPage() {
  const { user, onLogout } = useSession()
  const navigate = useNavigate()
  const [jobs, setJobs] = useState<JobSummary[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    let cancelled = false
    setLoading(true)
    setError('')

    getJobs(user.token)
      .then((data) => {
        if (!cancelled) setJobs(data)
      })
      .catch((err: unknown) => {
        if (cancelled) return
        const message = err instanceof Error ? err.message : 'Failed to load jobs'
        if (message === 'unauthorized') {
          onLogout()
          return
        }
        setError(message)
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })

    return () => {
      cancelled = true
    }
  }, [user.token, onLogout])

  return (
    <section className="jobs-page">
      <div className="home-heading">
        <h1>Jobs</h1>
        <p>Every analysis you've run. Open a completed one to see its full report.</p>
      </div>

      {loading && <p className="policy-summary">Loading jobs…</p>}
      {error && <div className="analysis-error"><span>{error}</span></div>}

      {!loading && !error && jobs.length === 0 && (
        <p className="policy-summary">No jobs yet. Run an analysis and it will appear here.</p>
      )}

      {!loading && !error && jobs.length > 0 && (
        <div className="jobs-table-wrap">
          <table className="jobs-table">
            <thead>
              <tr>
                <th className="col-index">#</th>
                <th>Job ID</th>
                <th>Policy</th>
                <th>Started</th>
                <th>Status</th>
                <th className="col-action">Report</th>
              </tr>
            </thead>
            <tbody>
              {jobs.map((job, index) => {
                const status = job.status.toLowerCase()
                const statusTone =
                  status === 'completed' ? 'completed' : status === 'failed' ? 'failed' : 'running'
                return (
                  <tr key={job.job_id}>
                    <td className="col-index">{index + 1}</td>
                    <td className="col-jobid">{job.job_id}</td>
                    <td className="col-policy">{job.policy_name ?? job.policy_query}</td>
                    <td className="col-started">{formatStarted(job.created_at)}</td>
                    <td className="col-status">
                      <span className={`job-status ${statusTone}`}>{job.status}</span>
                    </td>
                    <td className="col-action">
                      {status === 'completed' && (
                        <button
                          type="button"
                          className="view-btn"
                          onClick={() => navigate(`/jobs/${encodeURIComponent(job.job_id)}`)}
                        >
                          <ViewIcon />
                          View
                        </button>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  )
}

export default JobsPage
