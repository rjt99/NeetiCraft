import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { getJobReport, type Report } from '../api'
import ChatSidebar from '../components/ChatSidebar'
import ReportView from '../components/report/ReportView'
import RunBar from '../components/RunBar'
import { useServerModel } from '../hooks/useServerModel'
import { useSession } from '../session'
import { AGENT_SEQUENCE } from '../types'

/** Read-only view of a finished job's report — the same ReportView the analysis
 *  page shows once a run completes, loaded from the stored job artifact. */
function JobReportPage() {
  const { user, onLogout } = useSession()
  const { jobId: encoded } = useParams()
  const jobId = decodeURIComponent(encoded ?? '')
  const model = useServerModel()

  const [report, setReport] = useState<Report | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [chatOpen, setChatOpen] = useState(false)

  useEffect(() => {
    let cancelled = false
    setLoading(true)
    setError('')
    setChatOpen(false)

    getJobReport(jobId, user.token)
      .then((data) => {
        if (!cancelled) setReport(data)
      })
      .catch((err: unknown) => {
        if (cancelled) return
        const message = err instanceof Error ? err.message : 'Failed to load report'
        if (message === 'unauthorized') {
          onLogout()
          return
        }
        setError(message)
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })

    return () => {
      cancelled = true
    }
  }, [jobId, user.token, onLogout])

  return (
    <div className={`analysis-layout ${chatOpen ? 'with-chat' : ''}`}>
      <div className="analysis-main">
        {report && (
          <RunBar
            policyName={report.policy.name}
            jobId={jobId}
            model={model}
            agentCount={AGENT_SEQUENCE.length}
            agentsDone={AGENT_SEQUENCE.length}
            totalTokens={0}
            chatOpen={chatOpen}
            onToggleChat={() => setChatOpen((open) => !open)}
          />
        )}

        {loading && <p className="policy-summary">Loading report…</p>}
        {error && <div className="analysis-error"><span>{error}</span></div>}

        {report && <ReportView report={report} />}
      </div>

      {chatOpen && (
        <ChatSidebar
          jobId={jobId}
          token={user.token}
          onClose={() => setChatOpen(false)}
          onUnauthorized={onLogout}
        />
      )}
    </div>
  )
}

export default JobReportPage
