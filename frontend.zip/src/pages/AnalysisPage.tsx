import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import AgentResultPanel from '../components/AgentResultPanel'
import AgentTimeline from '../components/AgentTimeline'
import ChatSidebar from '../components/ChatSidebar'
import { RetryIcon } from '../components/icons'
import ReportView from '../components/report/ReportView'
import RunBar from '../components/RunBar'
import SharedStreamBox from '../components/SharedStreamBox'
import { loadSelectedModel } from '../api'
import { useAnalysisRun } from '../hooks/useAnalysisRun'
import { useServerModel } from '../hooks/useServerModel'
import { useSession } from '../session'
import { AGENT_SEQUENCE } from '../types'

function AnalysisPage() {
  const { user, onLogout } = useSession()
  const { policy: encoded } = useParams()
  const policy = decodeURIComponent(encoded ?? '')

  const run = useAnalysisRun(policy, user.token, onLogout)
  const serverModel = useServerModel()
  // Show the model this run actually uses — the one picked on the home page,
  // falling back to the server default when nothing was chosen.
  const model = loadSelectedModel() || serverModel
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null)
  const [chatOpen, setChatOpen] = useState(false)

  // Navigating to a different policy reuses this component — reset the
  // per-run view state that useAnalysisRun doesn't own.
  useEffect(() => {
    setSelectedAgent(null)
    setChatOpen(false)
  }, [policy])

  const agentsDone = run.steps.filter((step) => step.status === 'done').length

  return (
    <div className={`analysis-layout ${chatOpen ? 'with-chat' : ''}`}>
      <div className="analysis-main">
        <RunBar
          policyName={run.report?.policy.name ?? policy}
          jobId={run.jobId}
          model={model}
          agentCount={AGENT_SEQUENCE.length}
          agentsDone={agentsDone}
          totalTokens={run.totalTokens}
          chatOpen={chatOpen}
          onToggleChat={() => setChatOpen((open) => !open)}
          running={run.running}
          onStop={run.stop}
          onRerun={run.rerun}
        />

        <section className="agent-run">
          {run.error && (
            <div className="analysis-error">
              <span>{run.error}</span>
              <button type="button" className="retry-btn" onClick={run.retry}>
                <RetryIcon />
                Retry
              </button>
            </div>
          )}
          <AgentTimeline
            steps={run.steps}
            selectedAgent={selectedAgent}
            onSelect={setSelectedAgent}
          />
          <div className="agent-run-grid">
            <SharedStreamBox lines={run.streamLines} />
            <AgentResultPanel
              selectedAgent={selectedAgent}
              result={selectedAgent ? run.agentResults[selectedAgent] : undefined}
            />
          </div>
        </section>

        {run.report && <ReportView report={run.report} />}
      </div>

      {chatOpen && run.jobId && (
        <ChatSidebar
          jobId={run.jobId}
          token={user.token}
          onClose={() => setChatOpen(false)}
          onUnauthorized={onLogout}
        />
      )}
    </div>
  )
}

export default AnalysisPage
