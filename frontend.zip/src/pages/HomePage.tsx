import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  getModels,
  getPolicies,
  loadSelectedModel,
  saveSelectedModel,
  type ModelOption,
  type PolicyCardData,
} from '../api'
import ModelPicker from '../components/ModelPicker'
import PolicyCard from '../components/PolicyCard'
import { analysisPath, useSession } from '../session'

function HomePage() {
  const { user, onLogout } = useSession()
  const navigate = useNavigate()
  const [policies, setPolicies] = useState<PolicyCardData[]>([])
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)
  const [models, setModels] = useState<ModelOption[]>([])
  const [selectedModel, setSelectedModel] = useState('')

  // Load the selectable models and settle on the active one (a previously
  // stored choice if still valid, otherwise the server default).
  useEffect(() => {
    let cancelled = false
    getModels()
      .then((config) => {
        if (cancelled) return
        setModels(config.models)
        const stored = loadSelectedModel()
        const valid = config.models.some((m) => m.id === stored)
        const active = valid ? stored : config.default
        setSelectedModel(active)
        saveSelectedModel(active)
      })
      .catch(() => {
        /* selector just won't render; runs fall back to the server default */
      })
    return () => {
      cancelled = true
    }
  }, [])

  const onModelChange = (id: string) => {
    setSelectedModel(id)
    saveSelectedModel(id)
  }

  useEffect(() => {
    let cancelled = false
    setLoading(true)
    setError('')

    getPolicies(user.token)
      .then((data) => {
        if (!cancelled) setPolicies(data)
      })
      .catch((err: unknown) => {
        if (cancelled) return
        const message = err instanceof Error ? err.message : 'Failed to load policies'
        if (message === 'unauthorized') {
          onLogout()
          return
        }
        setError(message)
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })

    return () => {
      cancelled = true
    }
    // onLogout is recreated each render by App — the token is what matters here.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user.token])

  return (
    <>
      <div className="home-heading-row">
        <div className="home-heading">
          <h1>Explore policies</h1>
          <p>Pick a policy to run a full causal analysis, or search for any other.</p>
        </div>
        <ModelPicker models={models} value={selectedModel} onChange={onModelChange} />
      </div>

      {loading && <p className="policy-summary">Loading policies…</p>}
      {error && <div className="analysis-error">{error}</div>}

      {!loading && !error && (
        <section className="flashcard-grid">
          {policies.map((card) => (
            <PolicyCard
              key={card.name}
              card={card}
              onSelect={(name) => navigate(analysisPath(name))}
            />
          ))}
        </section>
      )}
    </>
  )
}

export default HomePage
