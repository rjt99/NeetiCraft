import { useOutletContext } from 'react-router-dom'
import type { AuthUser } from './api'

/** What every authenticated route gets from the layout above it. */
export interface Session {
  user: AuthUser
  /** Clears auth and returns to /login — also the 401 handler for pages. */
  onLogout: () => void
}

export function useSession(): Session {
  return useOutletContext<Session>()
}

/** Route path for a policy analysis run. The policy is the URL, so a run is
 *  shareable, reloadable and back-button friendly. */
export function analysisPath(policy: string): string {
  return `/analysis/${encodeURIComponent(policy)}`
}
